# Technical Implementation Plan

This document describes the **future technical changes** implied by Gap Analysis 2. It is not an implementation patch.

---

# 1. G2-01 — Durable asynchronous ingestion and dispatch

## 1.1 Architectural invariant

Tocyn already chose the correct pattern:

```text
Provider
  -> verified ingress
  -> reserved admission
  -> durable raw envelope + pending journal
  -> Ingress Queue
  -> consumer
  -> canonical conversation mutation
  -> D1 outbox intent (same transaction where applicable)
  -> Outbound Queue
  -> dispatcher
  -> provider
```

The Queue is **transport**, not the only durable record.

D1/R2 journal state must survive Queue expiry or failed publication. D1 outbox state must survive outbound Queue failure. Queue retries/DLQs cannot replace those durability contracts.

## 1.2 Proposed binding names

Use repository-style uppercase binding names:

- `INGRESS_QUEUE`
- `OUTBOUND_QUEUE`

Suggested Cloudflare resource names:

- `tocyn-ingress`
- `tocyn-ingress-dlq`
- `tocyn-outbound`
- `tocyn-outbound-dlq`

Final environment-specific resource names should continue to come from Tocyn's isolated deployment manifests; do not hard-code production resource IDs into source.

## 1.3 Ingress journal

Under #91, introduce the next available D1 migration at implementation time. Do **not** reserve a migration number in this package because other packages may land first.

Suggested table responsibility:

```text
ingress_journal
  id                       stable UUID
  tenant_id                trusted scope owner
  connection_id            verified connection
  provider                 normalized provider key
  config_version           connection authority version
  correlation_id           stable cross-stage correlation
  raw_object_key           tenant-scoped R2 object
  raw_sha256               exact accepted byte digest
  raw_size_bytes            bounded byte size
  receipt_at               edge receipt timestamp
  provider_event_ref       optional safe external reference
  state                    accepted | publish_pending | published |
                           processing | terminal | quarantined
  publish_attempts         integer
  processing_attempts      integer
  next_recovery_at         nullable timestamp
  last_error_code          bounded non-secret code
  terminal_at              nullable timestamp
  created_at / updated_at
```

Rules:

1. tenant identity comes from verified authority, never the payload/path alone;
2. raw bytes are written to a tenant-scoped R2 key before parsing beyond the minimum required for verification/routing;
3. store a SHA-256 digest to detect accidental mutation/corruption;
4. never place credentials or full raw provider content in D1;
5. never delete the only recoverable raw object while journal state is non-terminal;
6. any recovery sweeper must recheck current tenant/connection authority before a canonical mutation;
7. journal cleanup is retention-policy driven and retry-safe.

## 1.4 Initial Queue publication

The Queue message should be a compact pointer, for example:

```ts
interface IngressQueuePointerV1 {
  version: 1;
  journalId: string;
  tenantId: string;       // routing/correlation metadata, not authority
  connectionId: string;
  configVersion: number;
  correlationId: string;
}
```

Consumer behaviour:

- read the authoritative journal row;
- resolve/recheck current connection authority;
- re-check tenant ownership;
- verify schema version;
- deduplicate using provider/event identity;
- fan out provider batches into canonical events;
- preserve provider occurrence, edge receipt and processing times separately;
- write canonical state transactionally;
- update journal state idempotently;
- emit safe operational events.

The consumer must not trust the queue message's `tenantId` by itself.

## 1.5 Retry, DLQ and quarantine

Configure both main Queues with explicit `max_retries` and `dead_letter_queue`.

Cloudflare currently sends messages to a configured DLQ after retry exhaustion; without a DLQ, exhausted messages can be deleted. Therefore production acceptance must prove a configured DLQ and an operator/replay path.

Use two concepts:

- **DLQ:** transport-level exhausted messages;
- **quarantine:** application-level permanently invalid/unsupported records that should not poison a batch.

A DLQ consumer/replay tool must:

- resolve the journal/outbox record;
- recheck current authority;
- preserve idempotency;
- record replay actor/reason;
- consume reserved recovery budget;
- never replay raw arbitrary payload directly into a different tenant.

## 1.6 Outbound outbox

#88 already owns the correct source-of-truth model.

`channel_outbox` (or the existing approved table name selected by #88) should contain stable intent and state, including:

```text
id
tenant_id
connection_id
ticket_id / article_id / canonical_event_id
provider
destination reference
payload/version reference
status
attempt_count
next_attempt_at
last_attempt_at
provider_message_id (nullable)
uncertain_send flag/state
last_error_code
created_at
terminal_at
```

The business mutation and its outbox intent must commit together in D1 where the same transaction boundary applies.

An outbound publisher places only the stable outbox ID plus safe correlation metadata on `OUTBOUND_QUEUE`. The dispatcher loads authoritative intent and connection credentials, rechecks revocation/version/policy immediately before sending, then records the provider result.

Exactly-once external delivery must **not** be claimed.

## 1.7 Existing issue ownership

No new Queue issue.

- #51 — ingress authentication/admission/Queue boundary.
- #91 — durable raw envelope + pending journal + publication recovery.
- #87 — normalization/dedup/canonical conversation write.
- #88 — D1 outbox + outbound Queue + provider dispatch.

---

# 2. G2-02 — Resource budget coordination via Durable Objects

## 2.1 Do not overload realtime

Keep:

- `NotificationDO` — tenant-keyed realtime/presence/notification coordination.

Add under #64:

- `BudgetCoordinatorDO` — durable budget grant/reservation coordination.

This separation prevents a realtime availability incident from becoming the accounting authority and prevents unrelated responsibilities from accumulating in one DO.

## 2.2 Purpose

`BudgetCoordinatorDO` is **not** a billing system and cannot know the exact Cloudflare bill.

It is Tocyn's admission coordinator for the deployment-owner policy defined by #50.

Its job is to prevent Tocyn from intentionally admitting more work than the configured application budget while preserving reserved recovery capacity.

## 2.3 Coordination model

Do not perform a central DO RPC on every warm-path operation.

Recommended model:

```text
D1 CostPolicy / ResourceBudget
        |
        v
BudgetCoordinatorDO
  - policy version
  - resource window
  - total allocatable budget
  - recovery reserve
  - grant ledger
        |
        +---- bounded grant block -> ingress/runtime holder A
        +---- bounded grant block -> holder B
        +---- bounded grant block -> recovery/dispatcher
```

Key DO identity by deployment-owner scope + resource dimension + reset window (or another benchmarked shard key), not by untrusted tenant input.

Each grant carries:

- unique grant ID;
- policy version;
- tenant scope where applicable;
- resource dimension;
- window;
- maximum credits;
- issued/expiry time;
- holder identity;
- reconciliation state.

Lost or uncertain grants must not be immediately reissued. Reconcile/expire them conservatively.

## 2.4 Suggested durable state

```ts
interface BudgetGrant {
  id: string;
  policyVersion: number;
  tenantId?: string;
  dimension: ResourceDimension;
  windowId: string;
  ceiling: number;
  consumedReported: number;
  holder: string;
  issuedAt: string;
  expiresAt: string;
  state: 'active' | 'reconciling' | 'closed' | 'uncertain';
}
```

Resource dimensions should extend #50 to include:

- Worker request/CPU allocation;
- Queue operations;
- D1 reads/writes/storage;
- R2 Class A/Class B/storage;
- Durable Object operations/storage/duration where applicable;
- Workers AI units;
- **Workers observability log/trace events**;
- optional future AI Gateway-specific usage only if `[NEW-AIG]` is adopted.

## 2.5 Failure mode

If the coordinator is unavailable or an allocation cannot be proven:

- discretionary/new work: replenish from authoritative state or reject visibly;
- already accepted work: use reserved recovery budget;
- security/authentication/tenant-isolation controls: never disabled to save budget;
- canonical audit evidence: never sampled or discarded as a cost-saving mechanism;
- diagnostic logs/traces: may follow an approved sampling policy.

---

# 3. G2-03 — Operational observability and SLO foundations

## 3.1 Separate three different concepts

Tocyn currently has three things that must remain distinct:

1. **Canonical audit events** — durable D1 evidence of business/security mutations; owned by existing conversation/audit work.
2. **Runtime observability** — logs, traces, latency/error/resource evidence used by operators.
3. **Tenant/product analytics** — response time, SLA, channel, handoff and QA metrics owned by #85.

Do not collapse them.

## 3.2 Proposed server structure

A small server-local observability layer is preferable to a new general package until another runtime genuinely consumes it:

```text
apps/server/src/observability/
  context.ts
  events.ts
  logger.ts
  redaction.ts
  spans.ts
  slo.ts
```

Public/shared types move to `packages/shared` only if browser or external tooling requires them.

## 3.3 Correlation context

Create one stable request/event correlation context at ingress:

```ts
interface OperationalContext {
  requestId: string;
  correlationId: string;
  tenantRef?: string;      // pseudonymous operational reference
  actorKind?: 'operator' | 'customer' | 'api' | 'provider' | 'system';
  routeTemplate?: string;
  operation: string;
}
```

For provider events, `correlationId` must survive:

`ingress -> journal -> Queue -> canonical event -> outbox -> outbound Queue -> dispatch`.

Never derive authorisation from it.

## 3.4 Safe logging allowlist

Allowed structured fields should be explicit, for example:

- schema version;
- event name;
- severity;
- request/correlation ID;
- pseudonymous tenant reference;
- actor kind;
- route template, not raw URL;
- operation;
- outcome;
- HTTP status;
- bounded error code;
- latency in ms;
- resource/binding category;
- retry/attempt number;
- queue/outbox/journal state;
- model identifier where not secret;
- count/size values.

Default prohibited fields:

- Authorization header;
- cookies/session tokens;
- OTPs/magic links;
- raw query strings containing tokens;
- email addresses;
- ticket/article/message bodies;
- attachment contents;
- arbitrary filenames where they may contain personal data;
- provider raw payloads;
- decrypted channel credentials;
- AI prompts/outputs;
- API keys;
- reset/recovery secrets.

Use a dedicated keyed pseudonym (for example HMAC-SHA-256 over the internal tenant UUID with an observability-only secret) if per-tenant operational grouping is required without putting the raw tenant identifier into logs.

## 3.5 Native Cloudflare observability

Use Workers Logs and Workers Tracing as the initial platform-native layer.

Configuration principles:

- local-only synthetic development: no persisted remote logs required;
- isolated remote/staging: enable logs/traces with synthetic data to establish evidence;
- production: enable only after #42 confirms redaction, access and retention controls;
- sampling: configurable per environment and selected from measured event volume/cost;
- tracing: use native binding/fetch/handler spans, adding custom spans only for Tocyn-specific state transitions;
- third-party OpenTelemetry export: optional future operational choice, not a Tocyn dependency.

Do **not** simply flip the current `observability.enabled` flag on production before the gate is complete.

## 3.6 SLI/SLO model

Define metrics before defining universal numbers.

### Safety invariants — not error-budget SLOs

These remain zero-tolerance release gates:

- zero successful cross-tenant access/mutation;
- zero accepted-event loss in the tested recovery model;
- no security bypass when optional AI/observability fails;
- no secret/customer-content logging in the prohibited-field tests.

### Initial SLIs

- eligible API canonical-mutation success rate;
- authenticated portal/operator request success rate;
- canonical mutation latency;
- D1/R2/DO binding latency/error rate;
- AI-assist latency + deterministic fallback rate;
- ingress durable-acceptance latency;
- queue publication latency;
- queue processing latency;
- oldest pending ingress-journal age;
- ingress DLQ/quarantine count;
- outbox pending age;
- outbound dispatch attempts/failure/uncertain-send count;
- vectorisation workflow completion/failure age;
- budget admission rejection and coordinator replenishment latency.

### Initial SLO policy

- Preserve #51's already-approved measured **50 ms warm-path ingress SLO** as issue-specific evidence.
- Do not copy the reference architecture's 400 ms/20 ms numbers into Tocyn without measurements.
- Establish staging baselines, then ratify numeric targets and regression budgets in the issue completion receipt.
- Record cold and warm paths separately.
- Network/provider latency must not be presented as a universal Tocyn guarantee.

## 3.7 Performance evidence

Create a reproducible evidence harness, not an unstable benchmark embedded blindly in every PR.

Suggested paths:

```text
scripts/performance/
  run-local-load.mjs
  summarize-load.mjs
  fixtures/
docs/evidence/performance/
```

Output machine-readable JSON:

```json
{
  "revision": "...",
  "scenario": "canonical-api-create",
  "runtime": "local|isolated-remote",
  "concurrency": 1000,
  "requests": 10000,
  "p50_ms": 0,
  "p95_ms": 0,
  "p99_ms": 0,
  "error_rate": 0,
  "recorded_at": "..."
}
```

CI should gate deterministic regressions (bundle sizes, test timeouts, no accidental browser code in Worker, schema/redaction tests). Remote latency SLO acceptance belongs to isolated environment evidence where runtime variance can be interpreted.

---

# 4. G2-04 — Data residency and jurisdiction

## 4.1 Core decision

Residency must be a **deployment capability/policy**, not a tenant-supplied routing field.

Tocyn should not add an ordinary tenant setting such as:

```text
tenant.jurisdiction = "eu"
```

and then imply that all processing follows it.

A single shared deployment cannot honestly offer conflicting storage/processing guarantees if its D1, R2, Vectorize, AI, Queue workers and observability are shared.

If two customers require incompatible hard residency guarantees, the safe v1 answer is separate deployments/resources.

## 4.2 Distinguish storage and processing

A residency matrix must track at least:

| Component | Storage jurisdiction | Processing jurisdiction | Creation-time immutable? | Notes |
|---|---|---|---|---|
| D1 | capability-dependent | database operation locality | yes for jurisdiction selection | verify current Cloudflare capability before provisioning |
| R2 | capability-dependent | bucket operation locality | yes | binding must use matching jurisdiction |
| Durable Objects | jurisdiction subnamespace | object runs/persists in jurisdiction | object identity is jurisdiction-specific | Worker caller may run elsewhere |
| Vectorize | no jurisdiction control identified in reviewed docs | globally distributed service | n/a | do not make a strict locality claim from namespace isolation |
| Workers AI | provider/data-usage contract | no Tocyn locality guarantee established by reviewed docs | n/a | privacy/security contract is not equivalent to residency |
| Queues/Cron | durable service | Worker trigger execution not covered by Regional Services | n/a | raw content should remain by-reference where possible |
| Workers Logs/Traces | account/configuration dependent | metadata path depends on Cloudflare features | n/a | Customer Metadata Boundary/enterprise options are separate |
| HTTP Worker execution | Regional Services can constrain custom-domain execution | regionalized for that hostname only | config | does not cover Queue/Cron triggers or all subrequests |

## 4.3 Proposed policy object

```ts
interface DeploymentResidencyPolicy {
  version: 1;
  claim: 'none' | 'storage-constrained' | 'processing-constrained';
  requestedJurisdiction?: string;
  components: Record<string, {
    storage: 'guaranteed' | 'best-effort' | 'unrestricted' | 'unknown';
    processing: 'guaranteed' | 'best-effort' | 'unrestricted' | 'unknown';
    evidenceCheckedAt: string;
    source?: string;
  }>;
  unsupportedFeaturePolicy: 'deny' | 'disable' | 'warn';
}
```

The precise public type can be simplified during implementation. The important rule is **capability evidence before claim**.

## 4.4 Provisioning implications

Before creating any jurisdiction-constrained resource:

1. resolve selected deployment policy;
2. check current provider capabilities;
3. create immutable-jurisdiction D1/R2/DO resources correctly;
4. store resource jurisdiction in the deployment manifest;
5. verify deployed bindings against the manifest;
6. fail provisioning if a claimed guarantee cannot be satisfied;
7. do not silently fall back to unrestricted resources;
8. document migration/re-provisioning requirements if an existing resource cannot acquire a jurisdiction after creation.

## 4.5 Strict-processing limitation

At the review date, current Cloudflare documentation does not establish a simple jurisdiction switch for every service Tocyn uses. In particular, Vectorize is documented as globally distributed, and Regional Services does not apply to Queue/Cron triggers.

Therefore:

- do not advertise full “EU processing residency” merely because D1/R2/DO are EU-constrained;
- if strict processing locality becomes a customer requirement, create a separate capability assessment;
- unsupported derived/AI/async features may need to be disabled or replaced in that deployment;
- the UI/documentation must state the difference between a storage constraint and an end-to-end processing constraint.

This is a **truthfulness and architecture** requirement, not a statement of legal compliance.

---

# 5. G2-05 — Shadow DOM/headless widget

No redesign.

#48/#66/#67 already specify the correct direction.

Keep:

- React application;
- Ark/Zag shared behaviour;
- static compiled CSS;
- `--tocyn-*` public token API;
- multi-instance `<tocyn-helpdesk>`;
- Shadow DOM;
- all overlays/portals rooted within the instance;
- host-pollution browser fixtures;
- lifecycle cleanup.

Do not add:

- iframe;
- Service Worker;
- offline message queue;
- runtime CSS-in-JS.

Minor addition:

- emit non-content operational lifecycle measurements using `[NEW-OBS]` naming where appropriate;
- #48/#67's browser bundle/startup budgets remain their own release gates.

---

# 6. G2-06 — Transactional mail

#18 remains correct.

Add only:

- transport correlation ID;
- safe delivery outcome/error code;
- latency/attempt count;
- no recipient/body/token logging;
- metric compatibility with `[NEW-OBS]`;
- resource-cost integration with #50/#64.

Do not accelerate Resend removal merely because the reference architecture uses a different email arrangement.

---

# 7. G2-07 — AI Gateway evaluation

This is an evaluation, not an architecture migration.

## 7.1 Current default

Continue direct Workers AI until evidence shows a better path.

## 7.2 Evaluate

Measure:

- latency;
- cost/control value;
- model/provider routing;
- provider fallback behaviour;
- schema/tool compatibility;
- privacy/log retention;
- failure modes;
- tenant-scoped cache safety;
- effect on #50/#64 accounting;
- operational visibility.

## 7.3 Non-negotiable security rule

AI Gateway must never become:

- a tenant resolver;
- an authorisation decision;
- a policy-gated action executor;
- a substitute for `VerifiedTenantScope`;
- a substitute for canonical audit.

## 7.4 Semantic caching safety

Caching private/RAG responses is disabled by default unless the cache identity includes every material boundary necessary to prevent cross-tenant or stale-policy reuse.

At minimum evaluate:

- tenant scope;
- knowledge revision;
- prompt/schema version;
- model/version;
- policy/config revision;
- visibility/permission-sensitive context.

If safe equivalence cannot be proven, do not cache the response.

## 7.5 Outcome

`[NEW-AIG]` can close with one of:

- adopt;
- adopt for limited advisory calls only;
- reject/no measurable benefit.

If adoption creates a durable architectural choice, add a separate next-available ADR at that time. Do not pre-write an “AI Gateway accepted” ADR now.

---

# 8. Explicit technical non-changes

The following are deliberate and should be recorded in the final change package as **no change required**:

- `VerifiedTenantScope` remains the tenant-authority pattern.
- Raw D1 access does not become acceptable merely because a Wasm resolver is absent.
- Rust is not introduced as a security talisman.
- React/Vite stays.
- SvelteKit is not introduced.
- canonical conversations stay.
- AI remains bounded/advisory until policy-gated M4 action work.
- no fixed Worker count.
- no iframe security claim.
- no Service Worker offline queue.
- no release-readiness claim from local source tests.
