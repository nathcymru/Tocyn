# Proposed GitHub Issue Bodies

Allocate real issue numbers only when the final combined change package is approved.

---

# `[NEW-OBS]` — Establish operational observability and service-level objectives

## Approved implementation scope — proposed wording

Establish Tocyn's production operational-observability contract without duplicating canonical audit (#63), customer-supplied diagnostic context (#92) or tenant-facing operational analytics (#85). Add versioned privacy-safe runtime event/correlation schemas, redaction/allowlist enforcement, environment-specific Workers Logs/Tracing configuration, initial SLIs/SLO evidence, alert conditions and reproducible performance receipts. Instrument current active paths and define extension points for #51/#91/#87/#88, #18, Workflows, Durable Objects and AI. Production telemetry remains disabled until #42 verifies access, retention, sampling and redaction. Include observability event volume in #50/#64 cost governance.

## Scope boundary

No third-party observability vendor requirement, no copy of ticket/message/provider/AI content into logs, no tenant analytics dashboard replacement, no production deployment, no arbitrary reference-architecture latency promises.

## Acceptance and demonstration

- [ ] Define versioned operational event/context types with request/correlation IDs, safe route/operation/outcome/latency/resource fields and a pseudonymous tenant reference where required.
- [ ] Implement allowlist/redaction tests proving auth headers, cookies, OTP/magic-link data, API keys, channel credentials, raw provider payloads, ticket/article bodies, attachment contents and AI prompts/outputs are absent.
- [ ] Keep canonical D1 audit evidence separate and non-sampled.
- [ ] Provide environment-specific Workers Logs/Tracing configuration: local remote-persistence off; isolated synthetic environment enabled for evidence; production gated by #42.
- [ ] Define initial SLIs for API/auth/canonical mutations, D1/R2/DO, Workflows/AI fallback and future journal/Queue/outbox/dispatch; preserve issue-specific targets such as #51's measured 50 ms warm ingress SLO.
- [ ] Create a reproducible machine-readable performance evidence format and load harness; baseline before ratifying new numeric global thresholds.
- [ ] Define alert/runbook conditions for DLQ/quarantine, oldest pending journal/outbox age, dispatch uncertainty, sustained active-path errors and budget-admission failures.
- [ ] Add Workers Logs/Trace events and sampling/retention assumptions to #50/#64 resource accounting.
- [ ] Demonstrate observability failure/unavailability cannot bypass auth, tenant isolation, durability, approval or recovery.
- [ ] Record exact revision/configuration/tool versions and known limitations. Preserve existing CI/security checks.

## Dependencies and proposed forecast

- Architectural prerequisites: #50 cost-policy contract and existing #63 canonical audit foundation.
- Integration-only sequencing constraints: none; #42 must depend on this issue before production readiness.
- Milestone: `M0.4: Delivery - Production Readiness`
- Proposed baseline effort: **24 hours**; proposed 3× planning effort: **72 hours**.
- Proposed execution grouping: `Hardening Sprint H1 — Production Evidence Foundations`.
- First-beta relevance: **Not a local-beta blocker.**
- Production relevance: **BLOCKER for #42.**

## Delivery boundary

Planning/implementation issue only. No production observability activation, external telemetry destination, production resource provisioning or release is authorised merely by creating/completing this issue.

---

# `[NEW-RES]` — Define deployment residency and jurisdiction boundaries

## Approved implementation scope — proposed wording

Define a truthful deployment-level residency/locality model for Tocyn. Distinguish storage jurisdiction, HTTP Worker processing, Queue/Cron/Workflow execution, Vectorize/Workers AI processing, provider processing and observability metadata. Residency/profile metadata is not tenant authority and cannot be selected by untrusted request/path data. Record a capability matrix and provisioning manifest; fail closed rather than silently creating unrestricted resources where a hard guarantee is claimed. For v1, incompatible hard-residency requirements use separate deployments/resources.

## Scope boundary

No legal-compliance certification, no promise that EU storage equals GDPR compliance, no per-tenant cross-region sharding redesign, no production resource creation/migration.

## Acceptance and demonstration

- [ ] Draft/accept ADR-0017 (or next available ADR number).
- [ ] Define deployment residency policy/capability matrix with separate storage and processing status for D1, R2, Durable Objects, Vectorize, Workers AI, Queues/Cron/Workflows, Worker HTTP execution, logs/traces and external providers.
- [ ] Confirm current Cloudflare capability documentation at implementation time; record `evidenceCheckedAt`/source.
- [ ] Add provisioning-manifest fields for selected/verified jurisdiction and fail when a claimed requirement cannot be met.
- [ ] Document immutable creation-time constraints and migration/re-provisioning consequences for D1/R2/DO where applicable.
- [ ] Prohibit an ordinary tenant/path/payload `jurisdiction` value from selecting resources or granting authority.
- [ ] Define the v1 rule that incompatible hard residency requirements use separate deployments/resources.
- [ ] Demonstrate configuration validation with synthetic unrestricted and constrained fixtures; no real resources required for source acceptance.
- [ ] Document unsupported/global-service behaviour: deny, disable or truthfully narrow the claim; never silently downgrade.
- [ ] Add #42 and future remote #57 gates; update architecture/privacy/deployment docs and Wiki.
- [ ] Record limitations; do not claim legal compliance.

## Dependencies and proposed forecast

- Architectural prerequisites: existing multi-tenant/security architecture (#19).
- Integration-only sequencing constraints: none.
- Milestone: `M0.4: Delivery - Production Readiness`
- Proposed baseline effort: **12 hours**; proposed 3× planning effort: **36 hours**.
- Proposed execution grouping: `Hardening Sprint H1 — Production Evidence Foundations`.
- First-beta relevance: **Not a local-beta blocker.**
- Remote/production relevance: **Policy required before #42 and before any remote environment makes a residency/locality claim.**

## Delivery boundary

No Cloudflare jurisdictional resources are created/migrated by this issue without separate environment/deployment authority.

---

# `[NEW-AIG]` — Evaluate AI inference routing, caching and provider fallback

## Approved implementation scope — proposed wording

Evaluate whether Cloudflare AI Gateway or an equivalent narrow inference-routing layer provides measurable benefit for Tocyn's bounded advisory AI through caching, model/provider routing, fallback, rate/cost controls or operational visibility. Preserve direct Workers AI as the baseline. The gateway cannot resolve tenants, grant authority, execute policy-gated tools or replace canonical audit. Evaluate semantic-cache isolation using tenant/knowledge/prompt/model/policy revisions; caching private/RAG outputs is disabled unless safe equivalence is demonstrated.

## Scope boundary

No mandatory gateway migration, no autonomous customer-backend execution, no provider-account signup, no production AI traffic migration, no cross-tenant semantic cache.

## Acceptance and demonstration

- [ ] Benchmark direct Workers AI against the candidate gateway path using synthetic tenant data.
- [ ] Compare latency, failure behaviour, model compatibility, cost/accounting, logging/privacy controls and provider fallback.
- [ ] Verify model routing cannot affect `VerifiedTenantScope` or M4 action policy.
- [ ] Define semantic-cache identity requirements; prove cross-tenant and stale-knowledge/policy reuse cannot occur before enabling caching.
- [ ] Verify provider fallback preserves schema constraints, deterministic fallback and privacy restrictions.
- [ ] Integrate candidate cost dimensions with #50/#64 evidence.
- [ ] Close with explicit `adopt`, `limited adopt`, or `reject` outcome and evidence.
- [ ] If adoption is architectural, create a separate next-available ADR at that time.
- [ ] Preserve current AI functionality if the gateway is unavailable/rejected.

## Dependencies and proposed forecast

- Architectural prerequisites: #50, #64 and current Workers AI foundation.
- Milestone: `M3.1: Backend - Context & Data Aggregation`
- Proposed baseline effort: **8 hours**; proposed 3× planning effort: **24 hours**.
- First-beta relevance: **Not a blocker.**
- Production relevance: **Not a blocker.**
- Sequencing: defer until the main path reaches M3 work or a measurable inference-cost/reliability need appears.
