# Hardening Sprint H1 — Production Evidence Foundations

**Planning construct only — not a GitHub architectural milestone.**

## Purpose

Insert a bounded hardening step now, while the local private-beta evidence is complete and before broader Queue/provider/remote production implementation makes observability or residency expensive to retrofit.

This sprint does **not** reopen the accepted local beta.

## Entry conditions

- current accepted local-beta evidence remains intact;
- #50 contract work is either complete or sufficiently stable to include observability-event accounting;
- no production deployment is running/authorised;
- all work uses synthetic/local or separately authorised isolated resources.

## Scope

### Workstream A — `[NEW-OBS]`

Deliver:

- ADR-0016 acceptance;
- safe operational event schema;
- redaction allowlist;
- correlation model;
- Workers Logs/Tracing environment policy;
- initial SLI/SLO definitions;
- reproducible performance evidence format/harness;
- alert taxonomy;
- #42 integration requirements;
- #50/#64 observability-budget extensions.

### Workstream B — `[NEW-RES]`

Deliver:

- ADR-0017 acceptance;
- deployment-level residency model;
- storage vs processing matrix;
- provisioning manifest fields;
- false-claim prevention;
- D1/R2/DO immutable-jurisdiction handling;
- Vectorize/Workers AI/Queue/observability limitations;
- #42 and future remote #57 integration requirements.

### Integration lane

- update ADR index;
- update system/deployment/privacy architecture docs;
- update Wiki source/sync pages;
- update issue dependencies;
- reforecast Project 4 using ADR-0014;
- run documentation/link/lint checks;
- no feature-release tag.

## Excluded

- Queue implementation itself (#51/#91/#87/#88 continues on its own path);
- provider adapters;
- production log activation;
- production resource provisioning;
- AI Gateway implementation;
- React/Svelte migration;
- Rust/Wasm;
- iframe widget;
- Service Worker offline queue;
- production cutover.

## Proposed effort

Using Tocyn's current 3× planning convention:

| Work | Baseline | Planning allowance |
|---|---:|---:|
| `[NEW-OBS]` | 24 h | 72 h |
| `[NEW-RES]` | 12 h | 36 h |
| **Total** | **36 h** | **108 h** |

With two bounded workstreams this is suitable for an approximately two-week planning iteration, but **do not invent immutable baseline dates until all change packages are combined and owner-approved**.

## Recommended sequence

```text
Current main
   |
   +-- finish/preserve #50 contract
   |
   +-- H1 / Workstream A: [NEW-OBS] --------+
   |                                        |
   +-- H1 / Workstream B: [NEW-RES] --------+--> integration/ADRs/docs
                                                |
                                                +--> reforecast Project 4
                                                |
                                                +--> return to #91/#64/#51
                                                |
                                                +--> #42 later consumes both
```

## Exit criteria

H1 is complete only when:

- both new issues have reviewed acceptance evidence;
- both ADRs are accepted and indexed;
- current architecture/docs make no unsupported locality claim;
- observability data classification/redaction is testable;
- a production operator can identify the SLIs and evidence required by #42;
- #50/#64 include observability overhead;
- existing beta evidence is unmodified;
- Project 4 forecast reflects H1 without erasing baselines;
- no production resources/releases were changed merely to complete the sprint.
