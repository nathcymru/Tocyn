# Source and Baseline Register

**Review date:** 10 September 2026

This register lets a future conversation verify what this package was based on.

## 1. User-supplied architecture reference

`10/10 Architecture: AI-First B2B Helpdesk on Cloudflare`

Key concepts used for gap comparison:

- deferred widget + Shadow DOM/iframe;
- ChatSession/TenantRateLimiter Durable Objects;
- dedicated inference gateway and AI Gateway;
- Rust/Wasm namespace resolver;
- Rust OAuth installer;
- mandatory tenant-qualified D1;
- Analytics Engine/Server-Timing/SLOs;
- Cloudflare Queues + DLQ;
- GDPR erasure workflow;
- SvelteKit dashboard;
- CI load/performance checks.

This package **does not treat those implementation choices as Tocyn requirements**.

## 2. Tocyn repository baseline

Repository:

https://github.com/nathcymru/Tocyn

Reviewed `main`:

`93de1b975a45edd9d28ca70edd725b60deb6b275`

Commit:

https://github.com/nathcymru/Tocyn/commit/93de1b975a45edd9d28ca70edd725b60deb6b275

Accepted local-beta application revision cited by current readiness evidence:

`049ea82a02571681f834bcd87d43253603edf71f`

## 3. Tocyn architecture/doc sources

- README  
  https://github.com/nathcymru/Tocyn/blob/main/README.md
- System overview  
  https://github.com/nathcymru/Tocyn/blob/main/docs/architecture/system-overview.md
- Data and tenant boundaries  
  https://github.com/nathcymru/Tocyn/blob/main/docs/architecture/data-and-tenant-boundaries.md
- AI and autonomous operations  
  https://github.com/nathcymru/Tocyn/blob/main/docs/architecture/ai-and-autonomous-operations.md
- Privacy architecture  
  https://github.com/nathcymru/Tocyn/blob/main/docs/privacy/privacy-architecture.md
- Roadmap  
  https://github.com/nathcymru/Tocyn/blob/main/docs/roadmap.md
- Private-beta readiness  
  https://github.com/nathcymru/Tocyn/blob/main/docs/private-beta-readiness.md
- ADR index  
  https://github.com/nathcymru/Tocyn/blob/main/docs/adr/README.md
- ADR-0012  
  https://github.com/nathcymru/Tocyn/blob/main/docs/adr/ADR-0012-canonical-conversations-and-channel-adapters.md
- ADR-0014  
  https://github.com/nathcymru/Tocyn/blob/main/docs/adr/ADR-0014-living-delivery-state.md
- Current Worker config  
  https://github.com/nathcymru/Tocyn/blob/main/apps/server/wrangler.json
- Current CI  
  https://github.com/nathcymru/Tocyn/blob/main/.github/workflows/ci.yml

## 4. Existing issue sources

- #18 `Migrate transactional mail to Cloudflare-native delivery`  
  https://github.com/nathcymru/Tocyn/issues/18
- #19 `Complete tenant-isolation acceptance coverage`  
  https://github.com/nathcymru/Tocyn/issues/19
- #42 `Validate production cutover and rollback readiness`  
  https://github.com/nathcymru/Tocyn/issues/42
- #48 `Establish shared headless primitives for standalone Tocyn`  
  https://github.com/nathcymru/Tocyn/issues/48
- #49 `Track delivery of the omnichannel architecture`  
  https://github.com/nathcymru/Tocyn/issues/49
- #50 `Define enforceable cost policies and resource budgets`  
  https://github.com/nathcymru/Tocyn/issues/50
- #51 `Implement authenticated durable webhook ingress`  
  https://github.com/nathcymru/Tocyn/issues/51
- #57 `Establish isolated preview and beta deployments`  
  https://github.com/nathcymru/Tocyn/issues/57
- #64 `Enforce resource budgets across active application paths`  
  https://github.com/nathcymru/Tocyn/issues/64
- #67 `Package isolated helpdesk Web Components`  
  https://github.com/nathcymru/Tocyn/issues/67
- #75 `Enrich intake with authorised operational context`  
  https://github.com/nathcymru/Tocyn/issues/75
- #85 `Report operational performance and quality metrics`  
  https://github.com/nathcymru/Tocyn/issues/85
- #87 `Normalise provider events into reliable conversation state`  
  https://github.com/nathcymru/Tocyn/issues/87
- #88 `Dispatch transactional outbound intents reliably`  
  https://github.com/nathcymru/Tocyn/issues/88
- #91 `Recover accepted payloads through durable storage journals`  
  https://github.com/nathcymru/Tocyn/issues/91
- #92 `Attach bounded telemetry to programmatic support intake`  
  https://github.com/nathcymru/Tocyn/issues/92

## 5. Current Cloudflare technical references checked

### Workers Logs

https://developers.cloudflare.com/workers/observability/logs/workers-logs/

Reviewed facts:

- logs can be enabled in Wrangler;
- head sampling can be configured;
- environments can use different sampling/configuration.

### Workers Tracing

https://developers.cloudflare.com/workers/observability/traces/

Reviewed facts:

- automatic instrumentation covers fetch/binding/handler operations;
- custom spans are available;
- logs/traces can have separate sampling;
- billing/retention must be rechecked when implemented.

### Durable Object data location

https://developers.cloudflare.com/durable-objects/reference/data-location/

Reviewed facts:

- jurisdiction-restricted subnamespaces exist;
- DO jurisdiction constrains the DO's run/persistence location;
- callers may execute elsewhere;
- location hints are best effort and are not jurisdiction guarantees.

### D1 data location

https://developers.cloudflare.com/d1/configuration/data-location/

Reviewed facts:

- jurisdiction can be selected at database creation for supported jurisdictions;
- jurisdiction is not retrofittable to an existing database;
- Worker callers may execute outside the database jurisdiction;
- location hints are not guarantees.

### R2 data location

https://developers.cloudflare.com/r2/reference/data-location/

Reviewed facts:

- jurisdictional restrictions exist;
- Worker bindings for jurisdictional buckets must declare the jurisdiction;
- a bucket jurisdiction cannot be changed after creation;
- location hints are best effort.

### Workers / Regional Services

https://developers.cloudflare.com/data-localization/how-to/workers/

Reviewed facts:

- Regional Services can constrain HTTP Worker execution for configured custom domains;
- it does not apply to Queue or Cron triggers;
- outgoing subrequests have separate limitations.

### Vectorize

https://developers.cloudflare.com/vectorize/

Reviewed fact:

- service is described as globally distributed;
- no equivalent per-index jurisdiction switch was identified in the reviewed docs. Reverify at implementation.

### Workers AI data use

https://developers.cloudflare.com/workers-ai/platform/data-usage/

Reviewed fact:

- data-use protections are documented;
- data-use terms are not treated by this package as proof of a specific processing jurisdiction.

### Cloudflare Queues DLQ

https://developers.cloudflare.com/queues/configuration/dead-letter-queues/

Reviewed facts:

- DLQ is configured on a consumer;
- messages are sent to DLQ after retry limit;
- without a DLQ, exhausted messages can be deleted.

### AI Gateway

https://developers.cloudflare.com/ai-gateway/usage/rest-api/
https://developers.cloudflare.com/ai-gateway/configuration/fallbacks/
https://developers.cloudflare.com/ai-gateway/features/rate-limiting/

Reviewed facts:

- unified model routing is available;
- AI Gateway can provide logging/caching/rate limiting and provider fallback;
- these are operational/inference controls, not Tocyn tenant authorisation.

## 6. Revalidation requirement

Before implementing any provider-specific limit, price, jurisdiction, retention or API configuration:

- re-open the official Cloudflare source;
- record the date/version checked;
- update #50's dated capability/allowance catalogue;
- do not rely on this 10 September 2026 snapshot indefinitely.
