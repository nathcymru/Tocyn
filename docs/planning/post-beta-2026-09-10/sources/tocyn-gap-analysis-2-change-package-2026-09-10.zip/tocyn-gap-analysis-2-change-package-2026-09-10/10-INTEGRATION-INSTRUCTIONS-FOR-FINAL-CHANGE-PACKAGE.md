# Integration Instructions for the Final Change Package

This file is written for the future conversation that will combine Gap Analysis 2 with other Tocyn change packages.

## 1. First action

Re-read `nathcymru/Tocyn` current `main`.

Do not assume baseline `93de1b975a45edd9d28ca70edd725b60deb6b275` is still current.

Compare:

- open/closed issues;
- Project 4 fields;
- milestones;
- migration head;
- ADR head;
- README/system architecture;
- Wrangler/deployment manifests;
- any other supplied package.

## 2. De-duplicate before creating work

Do not create new issues for Queue ingestion, journal, consumer, dispatch, cost policy or headless widget if #51/#91/#87/#88/#50/#64/#48/#67 still own them.

Only allocate new issue numbers for:

- `[NEW-OBS]`
- `[NEW-RES]`
- `[NEW-AIG]` (deferred)

unless another package already creates equivalent ownership.

## 3. ADR number allocation

Reviewed `main` ends at ADR-0015.

This package proposes:

- ADR-0016 — Operational observability and service-level objectives
- ADR-0017 — Deployment residency and jurisdiction boundaries

If another package adds an ADR first:

1. allocate next available numbers;
2. rename files/headings;
3. update all cross-references;
4. preserve historical ADR numbering;
5. do not overwrite another accepted ADR.

## 4. Project scheduling

Follow ADR-0014:

- preserve baseline start/target;
- create new baselines only after owner approval;
- change forecast, not baseline, when H1 displaces work;
- record actual completion already achieved;
- record schedule variance;
- keep progress evidence-based.

Do not use the old September/November planning forecast as a reason to overwrite current actuals.

## 5. Hardening sprint choice

Preferred:

`Hardening Sprint H1 — Production Evidence Foundations`

- `[NEW-OBS]` workstream A
- `[NEW-RES]` workstream B
- integration/reforecast after both

Do not create a new M8 or observability milestone. Use M0.4.

If other packages contain higher-priority security blockers, merge them into the same hardening window and reforecast H1 rather than creating competing sprint structures.

## 6. Issue amendments

Apply the issue changes in `03-ISSUE-PROJECT-MILESTONE-RELEASE-PLAN.md`.

Important:

- edit active scopes/checklists;
- preserve historical `<details>` blocks;
- do not erase old forecasts/evidence;
- #42 active migration range becomes dynamic through deployment candidate, with exact range in receipt.

## 7. Source implementation order after planning approval

Recommended technical order:

1. #50 resource contract includes observability events.
2. `[NEW-OBS]` + `[NEW-RES]` H1.
3. #64 `BudgetCoordinatorDO`.
4. #91 ingress journal.
5. #51 ingress Queue/auth/admission.
6. #87 consumer/canonical processing.
7. #88 outbox/outbound Queue/dispatch.
8. #18/provider channel issues as their roadmap dictates.
9. `[NEW-AIG]` later in M3.1.

Exact ordering may change after all packages are combined, but avoid implementing provider adapters before the shared durable boundaries exist.

## 8. No-change guardrail

The final package should explicitly reject accidental redesigns:

- no SvelteKit migration;
- no Rust/Wasm tenant resolver;
- no Rust OAuth installer;
- no iframe requirement;
- no Service Worker offline queue;
- no fixed Worker count;
- no AI Gateway authority;
- no per-tenant jurisdiction routing;
- no weakening of `VerifiedTenantScope`.

## 9. Deployment/release guardrail

Planning and source changes do not authorise:

- Cloudflare production provisioning;
- DNS/domain changes;
- provider registrations;
- real customer mail/messages;
- production observability activation;
- D1/R2 jurisdiction migration;
- release/tag creation;
- production cutover.

Use #42 and explicit owner authority for production.

## 10. Final package output expected

The later conversation should output one reconciled package containing:

- final issue create/update matrix with allocated numbers;
- Project 4 field changes;
- dependency graph;
- milestone mapping;
- final reforecast;
- accepted/proposed ADR files with final numbers;
- code-level implementation plan;
- documentation/wiki patch plan;
- migration/binding plan;
- test/evidence plan;
- release/cutover impact;
- explicit no-change decisions;
- conflicts/de-duplications between source packages.
