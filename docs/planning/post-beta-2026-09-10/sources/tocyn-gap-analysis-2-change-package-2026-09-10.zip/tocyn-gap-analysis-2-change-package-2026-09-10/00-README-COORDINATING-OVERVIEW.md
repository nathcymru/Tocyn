# Tocyn Gap Analysis 2 — Coordinating Change Package

**Package date:** 10 September 2026  
**Repository reviewed:** `nathcymru/Tocyn`  
**Repository baseline reviewed:** `main` at `93de1b975a45edd9d28ca70edd725b60deb6b275`  
**Accepted local-beta application revision retained for historical evidence:** `049ea82a02571681f834bcd87d43253603edf71f`  
**Package status:** Planning / handover material only  
**Repository modification authority:** **NONE**

> This package does not modify Tocyn, create issues, alter GitHub Projects, change milestones, create releases, provision Cloudflare resources, or authorise production activity. It is designed to be combined with other change packages in a later conversation and reconciled into one final implementation package.

## 1. Executive decision

Do **not** re-architect Tocyn around the supplied “10/10 Architecture: AI-First B2B Helpdesk on Cloudflare” reference.

Tocyn's existing approved direction remains the correct product architecture:

- canonical provider-independent conversations;
- authenticated/verified tenant authority rather than payload-selected tenancy;
- tenant-scoped D1/R2/Vectorize ownership;
- human-led operation first;
- bounded AI assistance;
- policy-gated autonomous actions with human approval/takeover;
- TypeScript/Hono on Cloudflare Workers;
- React/Vite browser applications;
- Workers AI + Vectorize + Cloudflare Workflows;
- Durable Objects for realtime and approved resource-budget coordination;
- Ark/Zag headless primitives with static CSS tokens;
- an optional isolated Shadow DOM Web Component;
- flexible runtime responsibility boundaries rather than a prematurely fixed Worker count.

The reference architecture is useful mainly as a **production-engineering gap check**. It exposes four matters that should be strengthened in Tocyn and two already-planned areas that should be made more explicit.

## 2. Changes proposed by this package

| Package ID | Change | Ownership | Disposition |
|---|---|---|---|
| G2-01 | Durable Queue ingestion / journal / consumer / outbox / dispatch | Existing #51, #91, #87, #88 | **Strengthen existing issues; no duplicate issue** |
| G2-02 | Resource-budget Durable Object coordination | Existing #50, #64 | **Strengthen existing issues; no duplicate issue** |
| G2-03 | Production observability, tracing and SLO contract | **New issue proposed** | **Add** |
| G2-04 | Runtime/performance evidence and regression gates | New observability issue + existing #51/#48/#67 | **Add cross-cutting contract; keep local issue-specific gates** |
| G2-05 | Deployment residency / jurisdiction policy | **New issue proposed** | **Add** |
| G2-06 | Shadow DOM/headless widget completion | Existing #48, #66, #67 | **Keep; minor cross-links only** |
| G2-07 | Resend migration | Existing #18 | **Keep; add observability integration only** |
| G2-08 | AI Gateway / provider-routing evaluation | **New deferred evaluation issue proposed** | **Add later; not a blocker** |
| G2-09 | Rust/Wasm tenant resolver | None | **Explicitly reject / do not add** |
| G2-10 | Rust OAuth installer | None | **Do not add now** |
| G2-11 | SvelteKit dashboard migration | None | **Reject / do not add** |
| G2-12 | iframe inside widget | None | **Do not add absent a demonstrated requirement** |
| G2-13 | widget Service Worker offline message queue | None | **Do not add absent a product requirement** |
| G2-14 | fixed deployment-wide Worker count | None | **Reject; retain responsibility-driven topology** |

## 3. New issue set proposed

Use the next GitHub issue numbers available at the time the final package is applied.

### `[NEW-OBS]` — `Establish operational observability and service-level objectives`

- **Milestone:** `M0.4: Delivery - Production Readiness`
- **Recommended existing labels:** `enhancement`, `security`
- **Proposed baseline effort:** 24 h
- **Proposed 3× planning allowance:** 72 h
- **First local-beta relevance:** not a blocker; the accepted local-only beta remains valid.
- **Production relevance:** blocker before production readiness can be accepted under #42.
- **Purpose:** define privacy-safe structured logs/traces, correlation, infrastructure SLIs/SLOs, alert conditions, runtime evidence and cost-aware sampling without conflating this with canonical audit events or tenant product analytics.

### `[NEW-RES]` — `Define deployment residency and jurisdiction boundaries`

- **Milestone:** `M0.4: Delivery - Production Readiness`
- **Recommended existing labels:** `enhancement`, `security`
- **Proposed baseline effort:** 12 h
- **Proposed 3× planning allowance:** 36 h
- **First local-beta relevance:** not a blocker.
- **Remote/production relevance:** architectural prerequisite before Tocyn makes any residency/locality claim or provisions a remote environment intended to meet one.
- **Purpose:** distinguish storage locality, request-processing locality, AI/vector processing, Queue/Cron execution and observability metadata; make residency a deployment-level capability rather than an untrusted tenant routing selector.

### `[NEW-AIG]` — `Evaluate AI inference routing, caching and provider fallback`

- **Milestone:** `M3.1: Backend - Context & Data Aggregation`
- **Recommended existing labels:** `enhancement`, `security`
- **Proposed baseline effort:** 8 h
- **Proposed 3× planning allowance:** 24 h
- **Relevance:** deferred evaluation only; not a beta or production blocker.
- **Purpose:** test whether Cloudflare AI Gateway materially improves cost control, model routing, caching or resilience without becoming a tenant-authority boundary or weakening privacy isolation.

Full proposed issue bodies are in `08-PROPOSED-ISSUE-BODIES.md`.

## 4. Existing issue changes proposed

The current issue structure is largely sound. Amend rather than duplicate:

- **#49 `Track delivery of the omnichannel architecture`** — add #91, #87 and #88 explicitly to the cross-roadmap delivery checklist; add `[NEW-OBS]` as a cross-cutting operational-readiness link, not as a prerequisite for provider contract design.
- **#50 `Define enforceable cost policies and resource budgets`** — add Workers Logs/Traces event volume and retention to the dated resource catalogue; keep canonical security/audit evidence non-sampleable.
- **#64 `Enforce resource budgets across active application paths`** — make the approved Durable Object budget-coordination design concrete using a separate TypeScript `BudgetCoordinatorDO`; do not overload `NotificationDO`.
- **#51 `Implement authenticated durable webhook ingress`** — make Queue producer/consumer/DLQ bindings and instrumentation explicit while preserving #91/#87/#88 ownership.
- **#91 `Recover accepted payloads through durable storage journals`** — make the ingress-journal state machine, immutable raw-object reference and recovery sweeper contract explicit.
- **#87 `Normalise provider events into reliable conversation state`** — propagate correlation/journal IDs and emit safe processing metrics; no change to canonical conversation semantics.
- **#88 `Dispatch transactional outbound intents reliably`** — make outbound Queue + DLQ/replay instrumentation explicit; retain the D1 outbox as the durable source of truth.
- **#42 `Validate production cutover and rollback readiness`** — add `[NEW-OBS]` and `[NEW-RES]` as prerequisites and update migration coverage from the stale `0014–0023` wording to **“0014 through the deployment candidate's latest migration”**; at the reviewed main this means through `0027`.
- **#57 `Establish isolated preview and beta deployments`** — leave the accepted local-only evidence untouched; make `[NEW-RES]` a prerequisite only for any later remote environment that claims locality/residency.
- **#48/#67** — preserve Ark/Zag and Shadow DOM direction; link their performance measurements to the common SLO evidence format without adding iframe or Service Worker requirements.
- **#18 `Migrate transactional mail to Cloudflare-native delivery`** — preserve scope; add transport metrics/redaction/correlation requirements from `[NEW-OBS]`.
- **#85** — explicitly remain tenant/product operational analytics, not platform observability.
- **#92** — explicitly remain customer-supplied diagnostic/telemetry context, not Tocyn runtime observability.

Detailed amendment text is in `03-ISSUE-PROJECT-MILESTONE-RELEASE-PLAN.md`.

## 5. Hardening sprint

A short detour is justified because observability and residency contracts are cheapest to establish **before** Queue/provider expansion and remote production work.

Proposed planning construct:

**`Hardening Sprint H1 — Production Evidence Foundations`**

This is a Project iteration/planning grouping, **not a new architectural milestone**.

Recommended insertion:

1. complete or preserve current #50 contract work;
2. run `[NEW-OBS]` and `[NEW-RES]` in parallel;
3. integrate the accepted ADRs/documentation;
4. reforecast #42 and later Queue/provider work using ADR-0014 rules;
5. return to the existing M0–M7 delivery path.

See `04-HARDENING-SPRINT-H1.md`.

## 6. ADR package

Two ADRs are drafted:

- `adr-drafts/ADR-0016-operational-observability-and-service-level-objectives.md`
- `adr-drafts/ADR-0017-deployment-residency-and-jurisdiction-boundaries.md`

The numbering is correct against the reviewed repository, whose version-controlled ADR set ends at ADR-0015. **Because this package will be merged with other change packages later, the final integrator must allocate the next available ADR numbers if another package consumes 0016 or 0017 first.**

Existing accepted ADRs should not be rewritten to make history look cleaner. Only related-link/addendum changes are proposed.

## 7. Release decision

**No release/tag change is authorised or required by this package.**

The repository currently records the accepted local-only private-beta outcome and the historical candidate `v0.4.0-beta.1`, but no tag/release/deployment was created. Preserve that evidence.

Do not silently retarget the historical `v0.4.0-beta.1` evidence to a later hardened revision. If the final combined change package later chooses to publish another beta snapshot, select its prerelease number deliberately and record which tested revision it represents.

## 8. What should specifically *not* be imported from the reference architecture

Do not create work for:

- a Rust/Wasm tenant namespace resolver;
- a Rust OAuth installer;
- SvelteKit migration;
- an iframe security boundary inside the widget;
- a browser Service Worker message outbox;
- a fixed count of Workers;
- an AI inference gateway as an authorisation boundary;
- a per-tenant jurisdiction selector that can move data across deployment regions.

Those choices would either duplicate stronger Tocyn controls, introduce unnecessary migration cost, or create misleading security/residency assumptions.

## 9. Package reading order

1. `00-README-COORDINATING-OVERVIEW.md`
2. `01-GAP-DISPOSITION-MATRIX.md`
3. `02-TECHNICAL-IMPLEMENTATION-PLAN.md`
4. `03-ISSUE-PROJECT-MILESTONE-RELEASE-PLAN.md`
5. `04-HARDENING-SPRINT-H1.md`
6. ADR drafts
7. `07-EXISTING-ADR-DOCUMENTATION-WIKI-CHANGE-PLAN.md`
8. `08-PROPOSED-ISSUE-BODIES.md`
9. `09-ACCEPTANCE-TEST-AND-EVIDENCE-MATRIX.md`
10. `10-INTEGRATION-INSTRUCTIONS-FOR-FINAL-CHANGE-PACKAGE.md`
11. `11-SOURCE-AND-BASELINE-REGISTER.md`

## 10. Integration rule for the next conversation

The next conversation should treat this as a **proposal set**, compare it with every other supplied package, de-duplicate issue/ADR ownership, allocate real issue/ADR numbers, re-read current `main`, and only then produce the final authorised change package.

No recommendation here should be applied mechanically if the repository or Project has materially changed after `93de1b975a45edd9d28ca70edd725b60deb6b275`.
