# Existing ADR, Documentation and Wiki Change Plan

## 1. ADR governance rule

The current ADR convention explicitly says accepted historical decisions must not be silently rewritten.

Therefore:

- add the two new ADRs as **Proposed**, then change to **Accepted** only after maintainer approval/review;
- preserve ADR-0001–ADR-0015 history;
- make only related-link/addendum changes to accepted ADRs where useful;
- do not rewrite an old ADR so it appears to have anticipated Gap Analysis 2.

---

# 2. Version-controlled ADR changes

## `docs/adr/README.md`

Add after ADR-0015:

- ADR-0016 — Operational observability and service-level objectives
- ADR-0017 — Deployment residency and jurisdiction boundaries

Use actual final numbers after package de-duplication.

## ADR-0012 — Canonical conversations and channel adapters

**Decision text:** no change.

Optional `Related` additions:

- `[NEW-OBS]` / ADR-0016
- #91 / #87 / #88

Reason: operational correlation should follow the canonical conversation pipeline, but observability does not alter the provider-independent decision.

## ADR-0013 — Email capability boundaries

No decision change.

Optional `Related` addition:

- ADR-0016 / `[NEW-OBS]`

Reason: transactional/support mail outcomes must be observable without merging the two mail capabilities.

## ADR-0014 — Living delivery state

No decision change.

Add `Related` reference to:

- `Hardening Sprint H1 — Production Evidence Foundations`

Clarify in Project documentation, not the ADR decision, that H1 follows the existing baseline/forecast/actual model and does not overwrite baseline dates.

## ADR-0015 — Privacy metadata boundary

No decision change.

Optional `Related` additions:

- ADR-0016 — telemetry data-minimisation boundary;
- ADR-0017 — residency is a deployment property, not access control.

## Wiki ADR-0010 — Policy-gated actions and reference validation

No change now.

If `[NEW-AIG]` later adopts AI Gateway, add an addendum:

> Model routing/gateway infrastructure does not grant authority. Tool execution continues to pass the deployment-owner, tenant, runtime policy, approval and verification gates.

Do not add the addendum before the routing decision exists.

## Wiki ADR-0011 — Architectural milestones and private beta

No decision change.

H1 is a Project planning iteration, not a new architectural milestone.

---

# 3. Repository documentation changes

## `docs/architecture/system-overview.md`

Add two subsections under approved target architecture:

### Operational visibility

State that:

- runtime responsibilities emit privacy-safe structured operational evidence;
- correlation crosses ingress/journal/Queue/core/outbox/dispatch;
- canonical audit is distinct from logs/traces;
- production log/trace activation is gated by #42;
- SLOs are service-specific and evidence-driven.

Add `[NEW-OBS]` to target authority links.

### Residency/locality

State that:

- residency is deployment policy, not tenant/path authority;
- storage and processing guarantees differ;
- D1/R2/DO can have service-specific jurisdiction controls;
- Vectorize/AI/Queue trigger/observability limitations prevent an automatic full-processing-residency claim;
- incompatible hard-residency tenants require separate deployments in v1.

Add `[NEW-RES]` to target authority links.

### Current runtime section

Keep the factual statement that the current Wrangler configuration has observability disabled until the new issue changes it.

Do not say Queues are implemented until #51/#91/#87/#88 actually land.

---

## `docs/architecture/data-and-tenant-boundaries.md`

Add:

> Residency metadata does not establish tenant authority. A jurisdiction/profile field cannot select another tenant or bypass `VerifiedTenantScope`.

Add a short deployment-boundary paragraph:

- tenant security isolation and deployment geography are orthogonal;
- a separate deployment may be required for incompatible locality obligations.

---

## `docs/architecture/ai-and-autonomous-operations.md`

No immediate architecture change.

Add `[NEW-AIG]` under roadmap/evaluation only if the issue is created:

- current direct Workers AI remains default;
- AI Gateway evaluation does not grant tool authority;
- semantic caching of private/tenant-grounded responses is off unless cross-tenant/visibility safety is proven.

Do not imply AI Gateway adoption.

---

## `docs/privacy/privacy-architecture.md`

Add a `Residency and processing-location` section:

- residency does not equal GDPR compliance;
- distinguish D1/R2/DO storage jurisdiction from Vectorize/AI/Queue execution and logs;
- privacy rights cleanup must still cover every store regardless of locality;
- no tenant data should be copied into observability merely to aid debugging;
- jurisdiction claims require the deployment capability matrix.

Add ADR-0016/0017 links.

---

## `docs/deployment.md`

Add pre-provisioning gates:

1. select/record deployment residency policy before creating immutable jurisdictional resources;
2. verify D1/R2/DO configuration;
3. declare unsupported/global services;
4. configure local/staging/production observability separately;
5. production telemetry only after #42 redaction/access/retention evidence;
6. record observability sampling/retention/cost assumptions;
7. no silent unrestricted fallback.

---

## `docs/isolated-environments.md`

Add:

- local environment: no persisted remote logs required;
- remote synthetic environment: logs/traces may be enabled to produce SLO evidence;
- prohibit secrets/customer content in telemetry;
- configuration/evidence must identify environment and revision;
- residency claims on an isolated remote environment require `[NEW-RES]`.

---

## `docs/roadmap.md`

Do not replace M0–M7.

Once new issues are approved:

- add a short note under M0/M0.4 that H1 is a cross-cutting hardening insertion before production readiness;
- link `[NEW-OBS]` and `[NEW-RES]`;
- state that baseline dates remain preserved and Project 4 forecast is authoritative;
- keep the accepted local beta outcome unchanged.

---

## `docs/private-beta-readiness.md`

Historical evidence should remain materially unchanged.

At most, add a future-work link saying `[NEW-OBS]` and `[NEW-RES]` are post-local-beta production-readiness work. Do not edit the accepted test results or make H1 retroactive.

---

## `docs/tasks.md`

This file is still titled `Luminatick Implementation Tasks` and conflicts with the current authoritative roadmap model.

Recommended non-blocking cleanup:

**Preferred:** move to `docs/history/luminatick-implementation-tasks.md` and add a historical/superseded banner.

Alternative: retain the path but add a prominent header:

> Historical upstream implementation inventory. Not the Tocyn delivery plan. Current authority is GitHub Project 4, architectural milestones/issues and the approved roadmap Wiki.

Do not delete historical information solely to make the repository look cleaner.

---

# 4. Wiki change plan

The repository has `docs/wiki-sync/` mirrors. Apply changes through the repository-backed source/sync mechanism used by the project rather than editing Wiki content with divergent text.

## `Architecture-decision-records`

Add ADR-0016 and ADR-0017 after acceptance.

Preserve ADR-0001–0015.

## `System-architecture`

Add:

- operational observability lane;
- correlation through async stages;
- deployment residency policy boundary;
- clear current/target distinction.

Do **not** draw a fixed number of Workers.

## `Architecture-and-tenant-isolation`

Add:

- verified tenant scope remains the security authority;
- jurisdiction/profile is not tenant authority;
- deployment geography cannot compensate for an isolation flaw.

## `Deployment-and-operating-costs`

Add:

- Workers Logs/Tracing event/retention cost;
- observability sampling as a cost-control dimension;
- canonical audit cannot be sampled away;
- jurisdiction-constrained resources may require separate/new provisioning;
- locality features/entitlements vary and must be rechecked.

## `Approved-architectural-roadmap`

Add new issue links under M0.4.

Describe H1 as an inserted delivery iteration, not an M8 or new architecture family.

Do not alter the accepted M0–M7 taxonomy.

## `Roadmap-and-releases`

Add:

- H1 as post-local-beta/pre-production hardening;
- no release/tag is created by H1;
- preserve `v0.4.0-beta.1` as historical candidate language until a separate release decision.

## `AI-and-autonomous-operations`

Only add `[NEW-AIG]` as an evaluation link.

Do not depict AI Gateway as selected.

## `GDPR_COMPLIANCE_USER_GUIDE`

Add:

- storage/data location is not legal compliance;
- strict locality claims must come from deployment evidence;
- derived AI/vector/provider/log systems remain in inventory;
- DSAR/erasure scope is independent of where the data is stored.

## `Home` / `Start-here`

Minimal change only if needed to point to the two new accepted ADRs. Avoid duplicating their content.

---

# 5. README change

Keep README concise.

After implementation/ADR acceptance, add no more than one short production-readiness statement:

> Tocyn does not make a blanket data-residency guarantee. Deployments must use the documented residency capability matrix, and production observability is governed separately from canonical tenant audit data.

Do not turn README into the operational manual.

---

# 6. Documents that should not be rewritten

- accepted local beta evidence;
- historical security review findings;
- prior ADR decisions;
- old issue `<details>` historical bodies;
- merge receipts.

Where active issue scopes are stale, correct the active scope while preserving historical text explicitly as history.
