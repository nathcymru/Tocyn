# Issue, Project, Milestone and Release Plan

## 1. Planning rules

The current roadmap correctly separates:

- **architectural milestones** — capability outcomes;
- **GitHub issues** — implementation ownership;
- **GitHub Project 4 fields** — baseline, forecast, actual, progress and schedule truth;
- **Git tags/releases** — tested snapshots.

ADR-0014 requires immutable approved baseline dates and separately mutable forecast/actual fields. This package therefore supplies **proposed effort and sequencing**, not invented owner-approved baseline dates.

When this package is merged with other packages:

1. allocate actual issue numbers;
2. add the new issues to Project 4;
3. set proposed effort;
4. owner-approve baseline dates once the combined package is known;
5. reforecast dependent issues without erasing their existing baseline.

---

# 2. New issues

| Alias | Exact proposed title | Milestone | Proposed baseline effort | 3× planning allowance | Blocking role |
|---|---|---:|---:|---:|---|
| `[NEW-OBS]` | `Establish operational observability and service-level objectives` | `M0.4: Delivery - Production Readiness` | 24 h | 72 h | Production readiness |
| `[NEW-RES]` | `Define deployment residency and jurisdiction boundaries` | `M0.4: Delivery - Production Readiness` | 12 h | 36 h | Any residency claim / remote constrained provisioning |
| `[NEW-AIG]` | `Evaluate AI inference routing, caching and provider fallback` | `M3.1: Backend - Context & Data Aggregation` | 8 h | 24 h | None; deferred evaluation |

Recommended existing labels only:

- `[NEW-OBS]`: `enhancement`, `security`
- `[NEW-RES]`: `enhancement`, `security`
- `[NEW-AIG]`: `enhancement`, `security`

Do not invent a new label solely for this package unless the final combined plan establishes a wider label taxonomy.

---

# 3. Existing issue amendments

## #49 — `Track delivery of the omnichannel architecture`

**Current role:** cross-roadmap tracker; no architectural milestone.

### Add to cross-roadmap delivery checklist

- #91 — `Recover accepted payloads through durable storage journals`
- #87 — `Normalise provider events into reliable conversation state`
- #88 — `Dispatch transactional outbound intents reliably`
- `[NEW-OBS]` — operational observability/SLO foundation

### Why

#51 already delegates journal/consumer/dispatch implementation to #91/#87/#88, but #49's visible checklist currently jumps from #51 to provider/webhook outcomes. Adding these links makes the real durability chain visible without duplicating implementation.

`[NEW-RES]` does not need to be a #49 prerequisite: unrestricted deployments may still implement omnichannel correctly. Residency is a deployment capability/claim gate, not a canonical conversation dependency.

---

## #50 — `Define enforceable cost policies and resource budgets`

**Milestone:** `M0.2: Platform - Cost & Capacity`

### Add

Extend the resource-dimension catalogue with:

- Workers Logs events;
- Workers Trace spans/events;
- retention/sampling assumptions;
- optional AI Gateway usage only if `[NEW-AIG]` later adopts it.

### Add policy distinction

- canonical business/security audit records are mandatory evidence and **must not be sampled away**;
- diagnostic runtime telemetry may be sampled/degraded under an approved observability policy;
- observability cost itself must be included in representative-flow estimates.

### Do not change

- conservative default;
- 80/20 new-work/recovery allocation;
- no zero-billing promise;
- owner ceiling > tenant restrictions;
- strict admission.

---

## #64 — `Enforce resource budgets across active application paths`

**Milestone:** `M0.2: Platform - Cost & Capacity`

### Add implementation clarification

Use a separate TypeScript `BudgetCoordinatorDO` for durable grant allocation/reconciliation.

Acceptance should prove:

- bounded grants cannot collectively exceed the policy allocation;
- warm-path operations use preallocated grants rather than a DO RPC for every request;
- policy/reset races do not over-allocate;
- uncertain/lost grants are not reissued prematurely;
- already accepted work retains recovery capacity;
- observability event use is included;
- `NotificationDO` remains realtime-only.

No new cost issue is required.

---

## #51 — `Implement authenticated durable webhook ingress`

**Milestone:** `M1.2: Backend - API Intake & Webhooks`

### Add to top-level acceptance

- real `INGRESS_QUEUE` binding in isolated environment;
- explicit `tocyn-ingress-dlq` configuration;
- compact pointer schema with version/correlation/journal ID;
- provider success response only after the issue's existing durable acceptance conditions;
- initial Queue publication failure retains recoverable journal state and follows provider retry semantics;
- instrument durable-acceptance, publish and error timings under `[NEW-OBS]`;
- preserve the issue's approved measured 50 ms warm-path SLO rather than introducing an unrelated global threshold.

### Do not absorb

- journal persistence (#91);
- normalization (#87);
- outbound dispatch (#88).

---

## #91 — `Recover accepted payloads through durable storage journals`

**Milestone:** `M1.2: Backend - API Intake & Webhooks`

### Add

Make explicit:

- `ingress_journal` state machine;
- R2 raw-byte SHA-256 digest;
- immutable tenant/connection/config-version relationship;
- recovery scan/sweeper;
- `next_recovery_at`;
- terminal/quarantine disposition;
- correlation propagation;
- queue-expiry fault injection;
- observability of oldest-pending age and recovery attempts.

Do not number the migration until implementation starts.

---

## #87 — `Normalise provider events into reliable conversation state`

**Milestone:** `M1.1: Backend - Core Data Model`

### Add

- consume/recheck journal-authoritative context;
- propagate `correlation_id`/`journal_id` to canonical event metadata where appropriate;
- emit safe processing latency/outcome metrics;
- record unsupported/quarantine outcome without copying raw content to logs.

Do not alter the canonical conversation model.

---

## #88 — `Dispatch transactional outbound intents reliably`

**Milestone:** `M1.2: Backend - API Intake & Webhooks`

### Add

- real `OUTBOUND_QUEUE` producer/consumer;
- `tocyn-outbound-dlq`;
- outbox publisher recovery when Queue publication fails;
- DLQ/replay path bound to current authority and reserved recovery budget;
- `outbox_pending_age`, attempt result and `uncertain_send` operational events;
- correlation continuity from canonical mutation through dispatch.

D1 outbox remains source of truth; Queue state is not sufficient evidence of business delivery.

---

## #42 — `Validate production cutover and rollback readiness`

**Milestone:** `M0.4: Delivery - Production Readiness`

### Change dependencies

Add:

- `[NEW-OBS]`
- `[NEW-RES]`

Keep #65/accepted-beta evidence as existing foundation.

### Correct stale migration wording

Current issue text names migrations `0014–0023`.

At the reviewed baseline, migrations exist through `0027`.

Replace the fixed historic range in the active scope with:

> Rehearse migrations `0014` through the deployment candidate's latest migration, with the exact range recorded in the readiness receipt.

The current reviewed candidate inventory therefore includes at least:

- 0024 canonical intake facts;
- 0025 ticket mutation receipts;
- 0026 conversation events;
- 0027 local beta admission.

Historical detail blocks may retain old wording as historical evidence.

### Add production gates

- logs/traces configuration matches ADR-0016;
- prohibited log fields verified absent;
- retention/access/sampling recorded;
- SLO evidence attached for active production surfaces;
- resource budget includes observability overhead;
- deployment residency manifest matches ADR-0017;
- no residency claim exceeds actual service capabilities;
- if constrained storage is used, D1/R2/DO resource jurisdiction is verified;
- unsupported global/derived services are disclosed/disabled according to policy;
- exact production revision/configuration recorded.

No production execution is authorised by this amendment.

---

## #57 — `Establish isolated preview and beta deployments`

### Preserve

Do not alter the accepted local-only synthetic evidence.

### Add to future remote portion only

Before creating a remote environment that makes a locality/residency claim:

- depend on `[NEW-RES]`;
- select/record deployment residency policy;
- provision immutable resources accordingly;
- verify no silent unrestricted fallback.

This does not retroactively invalidate the accepted local test boundary.

---

## #48 — `Establish shared headless primitives for standalone Tocyn`

### Keep

No architecture change.

### Add cross-link only

Its bundle/startup/edge measurements should use the common evidence metadata from `[NEW-OBS]` where practical:

- revision;
- scenario;
- environment;
- tool/version;
- measured p50/p95/p99 or bundle size;
- threshold/baseline;
- result.

Do not replace #48's own UI performance acceptance with an infrastructure SLO.

---

## #67 — `Package isolated helpdesk Web Components`

### Keep

No iframe. No Service Worker requirement.

### Add cross-link only

Record widget lifecycle/load measurements in the shared evidence format. Keep polluted-host browser acceptance and Shadow DOM isolation as the authoritative UI requirements.

---

## #18 — `Migrate transactional mail to Cloudflare-native delivery`

### Keep

Do not accelerate or re-scope the migration.

### Add

- correlation ID;
- send latency;
- attempt count;
- safe provider error class;
- delivery outcome;
- no recipient/body/auth-token logging;
- observability resource accounting;
- rollback evidence.

---

## #85 — `Report operational performance and quality metrics`

No implementation change required.

Add documentation sentence:

> This issue owns tenant-visible helpdesk/service performance and quality analytics. Platform/runtime observability, infrastructure SLOs, logs and traces are owned by `[NEW-OBS]` and must not be exposed as cross-tenant operational data through this feature.

---

## #92 — `Attach bounded telemetry to programmatic support intake`

No implementation change required.

Add documentation sentence:

> This issue concerns customer-supplied diagnostic context attached to support intake. It does not configure Tocyn's own Worker logs/traces or platform SLO monitoring, which are owned by `[NEW-OBS]`.

---

# 4. Project 4 changes

## Add cards

Add `[NEW-OBS]`, `[NEW-RES]`, `[NEW-AIG]`.

Recommended initial fields:

| Field | `[NEW-OBS]` | `[NEW-RES]` | `[NEW-AIG]` |
|---|---|---|---|
| Status | Todo | Todo | Todo |
| Progress % | 0 | 0 | 0 |
| Milestone | M0.4 | M0.4 | M3.1 |
| Baseline effort | proposed 24 h | proposed 12 h | proposed 8 h |
| Planning allowance | proposed 72 h | proposed 36 h | proposed 24 h |
| Baseline start/target | owner sets after combined package approval | same | same |
| Forecast | insert in H1 | insert in H1 | defer to M3.1 |
| First-beta blocker | No | No | No |
| Production-readiness blocker | Yes | Conditional on any residency claim; policy itself should be complete before production | No |

If Project 4 has an Iteration/Sprint field, assign `[NEW-OBS]` and `[NEW-RES]` to `Hardening Sprint H1 — Production Evidence Foundations`. Otherwise do not create a faux milestone; record H1 in Project notes/forecast only.

## Dependency changes

- #42 gains `[NEW-OBS]` and `[NEW-RES]`.
- remote/locality-claim portion of #57 gains `[NEW-RES]`.
- `[NEW-AIG]` depends on #50/#64 and current AI foundation; it does not block #75/#76 unless the maintainer later makes that decision.
- #49 adds `[NEW-OBS]` as a tracked cross-cutting outcome, not a strict architectural prerequisite for its early contracts.

## Reforecasting

After issue allocation:

1. preserve all approved baseline dates;
2. add actual completion already recorded for local beta;
3. forecast H1;
4. move only forecast dates of work actually displaced by H1;
5. record schedule variance rather than overwriting history.

---

# 5. Milestones

## New milestones

**None.**

The current model already has the right homes:

- observability/residency policy -> `M0.4: Delivery - Production Readiness`;
- AI routing evaluation -> `M3.1: Backend - Context & Data Aggregation`;
- Queue backbone -> existing M1.1/M1.2;
- widget -> M2.4;
- cost coordination -> M0.2.

Creating a separate “observability milestone” would fragment the owner-approved architecture.

## Milestone deletions/renames

**None.**

---

# 6. Releases/tags

## Current evidence

The reviewed documentation states:

- accepted local-only private-beta testing boundary completed 9 September 2026;
- historical candidate `v0.4.0-beta.1`;
- no tag, GitHub release, remote deployment or production deployment was created.

## Package recommendation

- **Do not create, rename or delete a release/tag as part of Gap Analysis 2.**
- Preserve `v0.4.0-beta.1` references as historical candidate/evidence.
- Do not silently retarget its evidence to a later revision.
- If the combined future package decides to publish a later beta, choose the next prerelease deliberately after reconciling all packages and test evidence.
- Do not establish a production release/date before #42 is accepted and separately authorised.

---

# 7. Optional documentation hygiene

`docs/tasks.md` still presents a legacy “Luminatick Implementation Tasks” plan while `docs/roadmap.md` correctly says current GitHub milestones/issues/Project/Wiki are authoritative.

This package recommends **not deleting history**, but after the final package is reconciled:

- move it to `docs/history/luminatick-implementation-tasks.md`, or
- clearly mark it at the top as historical/superseded and remove it from active navigation.

This is non-blocking documentation hygiene, not part of the production hardening sprint.
