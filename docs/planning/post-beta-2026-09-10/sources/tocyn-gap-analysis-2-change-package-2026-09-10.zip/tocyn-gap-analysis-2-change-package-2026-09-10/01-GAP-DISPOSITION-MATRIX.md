# Gap Disposition Matrix

## Legend

- **KEEP** — current Tocyn choice is preferred.
- **STRENGTHEN** — architecture is correct; implementation/acceptance should become more explicit.
- **ADD** — genuine cross-cutting capability is missing.
- **DEFER** — potentially useful, but not currently justified as a blocker.
- **REJECT** — do not introduce the reference design choice.

| Reference decision / gap | Tocyn end-state disposition | Technical action | Issue / plan owner |
|---|---|---|---|
| Canonical conversation core | **KEEP** | Preserve provider-independent ticket/article/conversation state and adapter boundary. | ADR-0012; #49, #59, #87 |
| AI-first product core | **REJECT** | AI remains advisory/enrichment and later policy-gated actor; it must not become the primary persistence or authority model. | #75, #76, M4 issues; ADR-0010 |
| Human-first beta | **KEEP** | Preserve accepted local beta evidence; autonomous actions remain later. | #65 evidence; ADR-0011 |
| Policy-gated autonomous authority | **KEEP** | Preserve owner ceiling → tenant restriction → runtime decision → allow/approval/deny → verification → audit/takeover. | ADR-0010; M4 |
| Rust/Wasm tenant namespace resolver | **REJECT** | Do not add. Continue `VerifiedTenantScope`/trusted resolver + scoped repository/storage boundaries. | #19 security model |
| Tenant-qualified D1/R2/Vectorize | **KEEP** | Continue composite ownership, scoped external state and cleanup manifests. | #19; data-boundary docs |
| TypeScript application runtime | **KEEP** | No Rust introduction merely for perceived safety/performance. | Existing architecture |
| React/Vite dashboard | **KEEP** | Do not migrate to SvelteKit. | #48 headless migration builds on current React |
| Workers AI + Vectorize | **KEEP** | Maintain bounded advisory/RAG use; preserve deterministic fallback. | #76 and knowledge issues |
| Cloudflare Workflows for vectorisation | **KEEP** | Preserve durable vectorisation workflow; instrument it. | Existing workflow; `[NEW-OBS]` |
| Realtime Durable Object | **KEEP** | Keep `NotificationDO` tenant-keyed realtime responsibility. | Current runtime |
| Budget/quota Durable Object | **STRENGTHEN** | Add a distinct `BudgetCoordinatorDO` under #64 for bounded grant allocation/reconciliation. | #50/#64 |
| Shadow DOM widget | **KEEP / STRENGTHEN** | Continue multi-instance Web Component and host-style isolation. | #48/#66/#67 |
| iframe inside Shadow DOM | **REJECT FOR NOW** | Do not add without an evidenced hostile-host security requirement; Shadow DOM is styling isolation, not a JS security boundary. | No issue |
| Ark/Zag headless primitives | **KEEP** | Continue planned migration and static CSS token API. | #48/#66 |
| Fixed Worker count/topology | **REJECT** | Keep logical responsibilities explicit; split Workers only when operational evidence justifies it. | System architecture |
| Queue ingress | **STRENGTHEN** | Add real Queue bindings, DLQ, retry/quarantine and correlation while retaining durable journal. | #51/#91/#87 |
| Queue outbound dispatch | **STRENGTHEN** | Add Queue/DLQ publisher/consumer around D1 outbox source of truth. | #88 |
| Observability disabled | **ADD** | Privacy-safe Workers Logs/Traces, structured event schema, correlation, redaction, alerts and evidence. | `[NEW-OBS]`, #42 |
| SLO/performance gates | **ADD / STRENGTHEN** | Common SLI/SLO vocabulary and evidence format; preserve issue-specific thresholds already approved. | `[NEW-OBS]`, #51, #48/#67 |
| Data residency/jurisdiction | **ADD** | Define deployment-level storage/processing capability matrix and prohibit unsupported claims. | `[NEW-RES]`, #42/#57 remote |
| Resend dependency | **KEEP TEMPORARILY** | Continue #18 migration; do not distract current architecture. Add observability only. | #18 |
| AI Gateway | **DEFER / EVALUATE** | Benchmark routing/caching/fallback/privacy/cost; never make it tenant authority. | `[NEW-AIG]` later |
| Rust OAuth installer | **DEFER / DO NOT ADD** | Revisit only if one-click Cloudflare-account installation becomes a product distribution requirement. | No issue now |
| Widget Service Worker offline outbox | **DO NOT ADD** | Server-side durable acceptance is higher priority. Add only on a real offline UX requirement. | No issue |
| Native Analytics Engine dependency | **DO NOT MANDATE** | Start with Workers Logs/Traces and existing canonical D1 audit; add a dedicated analytics sink only if evidence shows a need. | `[NEW-OBS]` |
| “Enterprise-grade from day one” readiness claim | **REJECT** | Preserve explicit separation of source implementation, beta evidence and production clearance. | ADR-0014; #42 |
