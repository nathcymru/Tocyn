# Acceptance Test and Evidence Matrix

This matrix is intended for the later implementation package. It does not claim the tests currently exist.

| Area | Test / fault | Required outcome | Evidence owner |
|---|---|---|---|
| Ingress auth | invalid provider signature | 401/provider-specific failure; no journal/raw object/Queue write | #51 |
| Ingress routing | forged tenant/path with valid other connection | zero cross-tenant state; fail closed | #51/#19 |
| Durable raw | R2 write fails | no success acknowledgement; no orphan authoritative journal | #91 |
| Journal | D1 journal write fails | no success acknowledgement; raw object cleaned/reconciled safely | #91 |
| Queue publish | journal durable but initial Queue publish fails | recoverable journal remains; provider retry semantics + idempotent recovery | #51/#91 |
| Queue duplicate | same pointer delivered repeatedly | one canonical result | #87 |
| Queue reorder | child/reply before parent | no detached duplicate ticket; deterministic reconciliation | #87 |
| Consumer crash | crash before canonical commit | retry safe; no partial canonical mutation | #87 |
| Consumer crash | crash after canonical commit before journal terminal update | retry detects existing canonical result and converges | #87 |
| Queue expiry | accepted event survives normal Queue retention expiry | journal/raw evidence allows recovery; no acknowledged loss | #91 |
| DLQ | max retries exceeded | message appears in configured ingress DLQ and can be dispositioned/replayed safely | #51/#91 |
| Quarantine | permanent schema/unsupported event | batch not poisoned; explicit terminal/quarantine record | #87 |
| Outbox atomicity | canonical mutation succeeds | outbox intent commits atomically where required | #88 |
| Outbound publish | Queue publication fails | D1 outbox remains pending/recoverable | #88 |
| Dispatch retry | 429/5xx/network timeout | bounded retry/backoff; current authority rechecked | #88 |
| Dispatch uncertainty | provider result indeterminate | `uncertain_send` retained; no false delivered state | #88 |
| Outbound DLQ | retry exhaustion | configured DLQ + operator replay/disposition | #88 |
| Revocation | connection revoked while queued | consumer/dispatch recheck prevents new unauthorised write/send | #87/#88 |
| Budget race | concurrent grant requests | total grants never exceed owner/window allocation | #64 |
| Budget restart | holder disappears with unused grant | uncertain credits not immediately double-issued | #64 |
| Budget reset | window boundary/policy update race | old grant cannot extend new policy beyond limit | #64 |
| Recovery reserve | new-work budget exhausted | accepted recovery remains operable from reserved capacity | #50/#64 |
| Observability redaction | secrets/tokens/cookies/OTP injected | none appear in persisted structured telemetry | `[NEW-OBS]` |
| Observability content | ticket/provider/AI bodies supplied | content absent; only allowlisted metadata emitted | `[NEW-OBS]` |
| Observability auth | telemetry disabled/unavailable | no auth/isolation/durability bypass | `[NEW-OBS]` |
| Correlation | one provider event end-to-end | same non-authoritative correlation identity traceable journal→consumer→outbox→dispatch | `[NEW-OBS]` |
| SLO baseline | local + isolated evidence | machine receipt records revision/runtime/tool/p50/p95/p99/errors | `[NEW-OBS]` |
| Tenant isolation | two tenants + colliding IDs | zero cross-tenant reads/writes/storage/vector effects | #19 + affected issue |
| Residency config | unrestricted deployment | makes no constrained-residency claim | `[NEW-RES]` |
| Residency config | constrained storage requested but one resource unsupported | provisioning/config validation fails or feature is explicitly disabled/narrowed; never silent fallback | `[NEW-RES]` |
| Residency authority | request contains fake jurisdiction | no resource/tenant authority change | `[NEW-RES]` |
| Residency immutability | existing incompatible D1/R2/DO | requires new resource/migration plan, not metadata-only flip | `[NEW-RES]` |
| Vector/AI residency | strict processing requirement | unsupported path is explicitly identified; no blanket in-region claim | `[NEW-RES]` |
| Widget isolation | polluted host CSS | #67 existing computed-style/overlay/focus requirements remain | #67 |
| Widget offline | browser offline | no new Service Worker contract is assumed; current product behaviour documented | no new issue |
| AI Gateway cache | tenant A/B same prompt | no cross-tenant cached result; default no private semantic cache | `[NEW-AIG]` if evaluated |
| AI Gateway fallback | primary model fails | fallback preserves schema/privacy/policy; core human flow remains available | `[NEW-AIG]` |
| AI authority | gateway/model proposes mutation | M4 policy gate remains mandatory; gateway cannot execute by standing authority | ADR-0010/M4 |
| Mail observability | auth/transactional mail | outcome/latency visible without recipient/body/token logging | #18 + `[NEW-OBS]` |
| Production gate | exact deploy candidate | #42 receipt includes migration range, rollback, SLO, telemetry policy and residency manifest | #42 |

## Evidence format

Each new performance/operational receipt should contain:

```text
revision
issue
scenario
environment
runtime/tool versions
configuration digest (safe)
synthetic fixture identifier
start/end timestamp
measurement/counts
expected threshold/invariant
pass/fail
known limitations
cleanup result
```

Do not put secrets or customer content into evidence files.

## Regression policy

- correctness/security invariants: hard failure;
- issue-specific approved performance thresholds: hard failure where environment is deterministic enough;
- newly measured broad latency: baseline first, then set a reviewed regression budget;
- provider/network timings: evidence and provider-specific gates, not universal guarantees;
- local synthetic acceptance: never described as production clearance.
