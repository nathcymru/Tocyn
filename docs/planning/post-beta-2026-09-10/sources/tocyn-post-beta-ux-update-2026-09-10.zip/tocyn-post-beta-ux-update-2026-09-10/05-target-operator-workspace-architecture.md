# Target Operator Workspace Architecture

## 1. Governing interaction model

The primary operator route becomes an **Inbox workspace**, not a table of records.

### Desktop

```text
┌────────────┬──────────────────┬─────────────────────────────────────┬───────────────────┐
│ Global nav │ Work views       │ Conversation                        │ Context           │
│            │ + conversations  │                                     │ (collapsible)     │
│ Inbox      │ Mine             │ Customer + subject + why it needs  │ Customer          │
│ Knowledge  │ Unassigned       │ attention + SLA/next action         │ Ticket details    │
│ Reports    │ Mentions         │                                     │ History           │
│ Settings   │ Drafts           │ chronological conversation          │ Knowledge         │
│            │ Snoozed          │                                     │ Operational ctx   │
│            │ Needs action     │ compact action bar                  │ Collaboration     │
│            │ Team/custom      │ composer: Reply / Internal          │                   │
└────────────┴──────────────────┴─────────────────────────────────────┴───────────────────┘
```

At common widths the work-view navigator and conversation list may combine. On mobile the surfaces become one-at-a-time, but the selected view, selected conversation, scroll anchor and draft remain intact.

## 2. Recommended route model

Prefer nested deep-linkable routes:

```text
/inbox
/inbox/:viewId
/inbox/:viewId/:ticketId
/tickets                     -> optional Table mode or compatibility route
/tickets/:ticketId           -> compatibility entry that opens /inbox/all/:ticketId semantics
```

Requirements:

- URL identifies work view and active ticket where safe.
- Never put customer content or secrets in URL parameters.
- Switching tickets should not unmount the entire workspace.
- Browser Back returns predictably without destroying drafts.
- Existing `/tickets/:id` deep links remain functional through a compatibility adapter during migration.
- Search/filter query state may be encoded in URL when non-sensitive and bounded.
- Authentication/authority change clears prior session caches and selection exactly as the current beta already does.

## 3. Proposed frontend decomposition

Do not replace one monolith with another. Proposed domain components:

```text
apps/dashboard/src/workspace/
  OperatorWorkspace.tsx
  GlobalNavigation.tsx
  WorkViewNavigator.tsx
  ConversationList.tsx
  ConversationListItem.tsx
  ConversationPane.tsx
  ConversationHeader.tsx
  TicketActionBar.tsx
  ConversationTimeline.tsx
  ConversationComposer.tsx
  ContextPanel.tsx
  CustomerContext.tsx
  TicketContext.tsx
  KnowledgeContext.tsx
  CollaborationContext.tsx
  OperationalContext.tsx
  ActivityCenter.tsx
  CommandPalette.tsx
  TicketTableView.tsx
  WorkspacePreferences.tsx

apps/dashboard/src/workspace/hooks/
  useWorkspaceRouteState.ts
  useWorkViews.ts
  useWorkspacePreferences.ts
  useConversationDraft.ts
  useActivityCenter.ts
  useWorkspaceCommands.ts
```

Exact paths may change, but separation of responsibilities should be preserved.

## 4. Work views

### Required built-in views

- **Mine** — actionable tickets assigned to current operator.
- **Unassigned** — actionable tickets with no owner.
- **Mentions** — unresolved colleague mentions/requests for current operator.
- **Drafts** — tickets with unsent current-user drafts.
- **Snoozed** — work deliberately deferred.
- **Needs Action** — due/resurfaced/customer-replied work requiring human action.
- **All** — authorised ticket scope.
- team/custom saved views.

Each view needs:

- stable ID;
- human label;
- bounded filter predicate;
- sort definition;
- optional count;
- permission scope;
- reason-for-inclusion metadata where useful.

Do not implement counts as unbounded N-query polling. Add a bounded aggregate/projection endpoint or query plan and measure D1 cost.

## 5. Conversation list

Default list item exposes only what changes triage decisions:

- requester/contact display;
- subject;
- one-line snippet/summary;
- unread/new-activity state;
- current owner/team where useful;
- priority only where non-normal;
- SLA/next-action due indicator;
- Draft/Snoozed/Mention marker;
- channel indicator where omnichannel;
- last meaningful activity age.

Do not expose every custom field.

Selection:

- remains visible;
- does not unmount the whole workspace;
- restores after reload/session when still authorised;
- falls back safely if ticket is no longer visible;
- preserves list scroll via logical item/anchor where practical.

## 6. Conversation header and action bar

The top of an active conversation answers:

1. **Who is this?**
2. **What are they asking?**
3. **Why does this currently need attention?**
4. **When/what is due next?**

The compact action bar groups:

- assignee/team;
- lifecycle/work state;
- priority;
- SLA/next action;
- Snooze;
- Resolve/reopen;
- contextual utilities;
- More.

Do not put transport latency, healthy system state or knowledge-index administration here.

## 7. Context panel

One collapsible right-side panel with switchable contextual sections.

### Customer

- verified customer/contact identity;
- tenant-scoped previous conversations;
- contact metadata;
- linked identities only after #74 verification.

Never infer identity equivalence from display name, phone text or email-like strings.

### Ticket

- custom fields;
- full audit/history;
- tags/categories;
- lifecycle/work-state history.

### Knowledge

- relevant articles;
- search/preview/insert;
- QA/indexing controls for authorised users;
- provenance.

Move today's per-message `Mark as Question/Answer` controls out of normal reading flow unless a knowledge-moderation mode is active.

### Collaboration

- current viewers;
- typing/active editor state;
- internal mentions/notes;
- collision warning.

Presence never grants authority or acts as a lock.

### Operational context

- typed contextual records;
- optional asset/service/device/log information;
- source/provenance/freshness;
- supplied later through #75-compatible connector contracts.

## 8. Durable draft model

Cross-navigation draft loss is unacceptable.

Recommended logical model:

```text
conversation_drafts
  tenant_id
  ticket_id
  user_id
  mode                 public | internal
  body_ref             existing scoped body-storage reference
  attachment_refs      validated scoped references
  base_conversation_revision
  draft_revision
  updated_at
  expires_at / retention policy
```

Requirements:

- authenticated tenant/user scope;
- optimistic debounced autosave;
- useful Saving / Saved / Save failed states;
- conflict-safe revision;
- delete/mark-sent only after confirmed submission;
- explicit discard;
- Draft badge/list view;
- attachment ownership retained;
- draft body excluded from analytics/audit logs;
- documented retention;
- AI edits the same draft instead of creating a parallel AI object.

Use existing R2/body-storage abstractions where appropriate instead of inventing a second sensitive-text pattern.

## 9. Work/attention state

Canonical ticket lifecycle and operator attention are related but not identical.

Add an additive work-state contract:

```text
ticket_attention_state
  tenant_id
  ticket_id
  waiting_reason_key?
  snoozed_until?
  next_action_at?
  last_customer_activity_at?
  last_operator_activity_at?
  revision
  updated_by
  updated_at
```

All writes are permission-checked, tenant-scoped, audited and retry-safe.

Default human-facing waiting semantics should distinguish:

- Waiting for customer
- Waiting internally
- Scheduled follow-up
- Awaiting external system/provider
- Other

These may map onto stable lifecycle categories used by APIs/SLA calculations.

## 10. Custom support workflow states

Use additive definitions rather than replacing current API status abruptly:

```text
ticket_state_definitions
  tenant_id
  key
  label
  lifecycle_category      open | waiting | resolved | closed
  customer_visible_label
  sla_behaviour
  sort_order
  active
```

Compatibility:

- current `open/pending/resolved/closed` remain seeded defaults/lifecycle categories;
- existing APIs stay compatible;
- new fields expose configured state key/label;
- deactivation cannot strand tickets;
- changes are audited;
- state labels never alter authority.

This becomes an input to #73 SLA presentation.

## 11. Snooze/resurface

Snooze is work-state, not browser hiding.

Requirements:

- authoritative server timestamp;
- audit who/when/why;
- predefined durations + explicit date/time;
- deterministic timezone handling;
- absent from normal actionable view but present in Snoozed;
- new customer activity can unsnooze/mark Needs Action according to policy;
- due time resurfaces without human memory;
- concurrency/retry tests;
- no silent loss if background processing is delayed.

## 12. Activity and notifications

Today's expiring ticket toasts must not carry unique actionable meaning.

Recommended projection:

```text
operator_notifications
  tenant_id
  user_id
  id
  source_event_id
  category
  ticket_id?
  created_at
  read_at?
  dismissed_at?
  expires_at?
```

Candidate sources:

- direct assignment;
- mention;
- customer reply on owned ticket;
- SLA risk/breach;
- snoozed work resurfacing;
- delivery state requiring intervention.

Routine unrelated ticket updates refresh lists/counts without interrupting active composition.

WebSocket events notify/invalidate; durable state remains authoritative.

## 13. Search model

### Universal search / command

`Cmd/Ctrl+K` can search:

- tickets;
- verified customers;
- knowledge;
- navigation;
- authorised commands on current ticket.

Use bounded server search appropriate to each type; do not add an external search platform unless evidence warrants it.

### Current-view filter

Within the ConversationList:

**Filter this view**

This filters the selected work-view semantics and must not be labelled as another global `Search tickets`.

## 14. Keyboard model

#71 should target this architecture:

- open command palette;
- focus work views;
- focus conversation list;
- next/previous;
- open/focus conversation;
- reply;
- internal note;
- assign;
- state;
- snooze;
- resolve;
- focus context;
- insert saved reply/knowledge;
- send;
- return to list.

Requirements:

- shortcut help discoverable;
- shortcuts disable-able;
- editable fields suppress conflicts;
- AT/pointer access remains complete;
- focus remains predictable after list update/resolve/snooze.

## 15. Collision prevention

Presence is not collision protection.

Capture server conversation revision / last-seen event ID when reply composition begins. Submission includes it.

If material new conversation content exists:

- return conflict;
- preserve draft;
- show new content;
- require explicit review/retry;
- do not automatically resend;
- do not create duplicate public reply.

Primary owner: #70, reusing #60/#63 correctness patterns.

## 16. Table mode and bulk action

Keep Table mode for supervisors, audit and mass administration.

Features:

- saved columns/order/density;
- explicit selection count;
- right preview;
- bounded maximum selection;
- bulk assign/state/snooze/tag;
- per-item permission checks;
- idempotency/retry behaviour;
- partial-failure receipt;
- destructive/broad confirmation;
- no bulk public-message send without separately accepted design.

Table mode is not the default support mental model.

## 17. Personal cognitive-accessibility preferences

Persist non-authoritative user presentation preferences:

```text
operator_workspace_preferences
  tenant_id
  user_id
  schema_version
  navigation_mode
  density
  font_scale
  context_panel_default
  focus_mode
  motion_mode
  interruption_level
  shortcuts_enabled
  advance_after_resolve
  updated_at
```

Rules:

- tenant theme supplies defaults, not accessibility defeat;
- system reduced-motion applies absent explicit user choice;
- preferences never grant data access;
- invalid values safely fall back;
- authority/session change cannot leak another tenant's view state.

## 18. Focus mode

May:

- collapse navigator/list after selection;
- collapse context panel;
- suppress noncritical activity;
- widen reading/composer area.

Must not hide:

- public/internal reply mode;
- delivery uncertainty/failure;
- relevant SLA breach;
- security/permission errors;
- current customer identity;
- ownership/state necessary to understand task.

## 19. Motion and salience

Default rules:

- no pulsing `Operational`;
- no pulsing healthy real-time indicator;
- no routine hover-scale effects;
- animation only when it communicates meaningful transition;
- reduced-motion removes nonessential transitions;
- high saturation reserved for genuine exception/risk;
- colour never sole status signal;
- selected item and primary action get strongest normal-work emphasis.

## 20. Target size and typography

- Meet WCAG 2.2 Target Size (Minimum): at least 24x24 CSS px or a valid exception/spacing arrangement.
- Use 44x44 as Tocyn's default design target for frequent primary pointer/touch actions where layout permits; do not call 44x44 an AA requirement.
- No critical function only on hover.
- Retire 9px/10px interactive labels.
- Use rem typography and preserve browser zoom/reflow.

## 21. Workspace utility action registry

Provide controlled extension without hardcoding every future support tool:

```ts
interface WorkspaceUtilityAction {
  id: string
  label: string
  requiredPermission?: string
  isAvailable(context: WorkspaceTicketContext): boolean
  invoke(context: WorkspaceTicketContext): Promise<void> | void
}
```

Bound presentation types to application command, internal dialog or validated external link/deep link. Never allow arbitrary tenant-provided JavaScript/DOM injection.

Possible later integrations: call/voice, remote support, RMM/device view, status page, CRM, runbook.

## 22. Dashboard/home

Current metrics Dashboard should stop being a decorative health page.

Operator home, if retained, should link to work:

- Needs Action;
- Unassigned;
- SLA at risk;
- Snoozed returning soon;
- Drafts;
- direct mentions;
- workload summary where authorised.

Technical connection/system status belongs in admin diagnostics and appears to operators only when degraded/relevant.

#85 remains owner of mature analytics.

## 23. Headless implementation boundary

#48 still owns Ark/Zag primitives. It supports rather than defines product model.

Required primitives likely include dialog, menu, tooltip, popover, combobox/select, tabs, disclosure, command composition, listbox/roving focus, resizable/collapsible panels where required, feedback and form-field/error patterns.

The ADR-0016 interaction contract must exist before mass migration so #48 can classify:

- retain and migrate;
- replace with new composition;
- compatibility-only then retire.

Do not spend the headless milestone reproducing obsolete full-page ticket interaction one-for-one.

## 24. Performance contract

NEW-UX-13 measures before fixing final SLOs.

Provisional design objectives:

- local input/state acknowledgement: target <=100ms;
- cached pane/ticket switch where no network is needed: target <=200ms p95;
- first useful local-beta ticket content: investigate against the <400ms Laws of UX heuristic;
- network mutation pending/confirmed distinction visible immediately;
- queue updates after confirmed resolve/snooze must not unpredictably reflow focus.

These are starting points, not internet guarantees. Accepted work records measured budgets against representative fixtures/devices.
