# Project Plan Change Set

## 1. Planning principles

1. Preserve accepted beta evidence and closed-issue history.
2. Preserve Baseline start/target under ADR-0014. Reforecast; do not overwrite.
3. Do not duplicate existing capability issues.
4. Insert architecture/work-state foundations before polishing or accelerating legacy UI.
5. Keep unrelated backend/security/cost work moving where it does not cement obsolete presentation.
6. Make the next operator-facing prerelease pass a new UX acceptance gate.

## 2. Milestone changes

| Action | Current | Proposed | Reason |
| --- | --- | --- | --- |
| ADD | M2.0: Fullstack - Operator Workspace Foundations | New milestone | Own post-beta interaction contract, durable work/attention state, snooze/resurface, draft-continuity prerequisites and workflow-state semantics. |
| RENAME | M2.1: Frontend - Workspace Layout & Routing | M2.1: Frontend - Operator Workspace & Navigation | Current name understates scope. Own persistent workspace, search semantics, context surfaces, preferences, Table mode, utilities, performance and keyboard navigation. |
| KEEP / RESCOPE CONTENT | M2.4: Frontend - Headless Design System | Same name | Keep Ark/Zag. Re-sequence after M2.0 interaction contract and before broad M2.1 implementation. #67 need not block standalone operator correction. |
| KEEP | M2.2: Frontend - Conversation Composer & Productivity | Same name | Expand #68/#69 acceptance; no rename needed. |
| KEEP | M2.3: Fullstack - Real-Time State & Presence | Same name | Add durable-activity successor issue; #70 owns concurrency/collision/mentions. |
| KEEP | M6.2: Frontend - Service Status & SLA | Same name for now | #73 remains SLA owner. NEW-UX-10 supplies work-state semantics; NEW-UX-11 can sit here. Rename discipline only if consolidated plan confirms server breadth makes Frontend materially false. |

## 3. Post-Beta Operator UX Correction programme

This is a bounded roadmap intervention, not an indefinite redesign.

### Increment UX-B1 — Architecture and state contract

**Primary milestone:** new M2.0.

Deliver:

- NEW-UX-01 interaction contract;
- ADR-0016 through ADR-0019 review;
- NEW-UX-03 durable continuity design/implementation;
- NEW-UX-04 work views/snooze;
- NEW-UX-10 explicit workflow/waiting-state semantics;
- dependency reforecast.

Exit: implementation teams can state exactly what survives, moves and retires from the beta UI.

### Increment UX-B2 — Headless foundation for the corrected workspace

**Primary milestone:** M2.4.

Deliver operator-required portions of:

- #48 shared primitives;
- #66 token/theme base including reduced-motion/accessibility constraints.

Do not require #67's full Web Component packaging to block standalone operator correction unless evidence shows an unavoidable shared-primitive dependency.

Exit: corrected workspace can be built on accepted primitives rather than new ad hoc controls.

### Increment UX-B3 — Operator workspace correction

**Primary milestone:** renamed M2.1.

Deliver:

- NEW-UX-02 persistent progressive workspace;
- NEW-UX-05 search/filter semantics;
- NEW-UX-06 cognitive-accessibility preferences/focus;
- NEW-UX-08 customer/context panel;
- NEW-UX-09 Table mode and bounded bulk action;
- NEW-UX-12 utility action registry;
- NEW-UX-13 performance budget;
- #71 keyboard/command navigation against the new workspace;
- critical durable-draft/core-composer portion of #68;
- NEW-UX-14 integrated cognitive/usability acceptance.

NEW-UX-07 from M2.3 must land before final Gate A if legacy transient notifications would otherwise remain.

Exit: **Operator Workspace UX Gate A passes.**

### Return to normal roadmap

After Gate A:

- complete remaining #68 rich-composer breadth;
- #69 reusable responses/macros;
- #70 collaboration/collision breadth;
- M2.3 remaining work;
- #73 SLA and later M6;
- #75/#76/#77 context/AI;
- channel work #49/#53–#56/#89;
- #85 mature analytics.

## 4. Existing issue state decisions

### Keep closed — do not reopen

- #21 Validate accessibility of core operator and portal workflows
- #62 Validate human handling of canonical ticket intake
- #65 Rehearse and publish the human-led private beta
- #93 Enforce private-beta resource guardrails

Add successor references/documentation only. Their completion remains truthful.

### Keep open but amend/resequence

- #48
- #66
- #68
- #69
- #70
- #71
- #73
- #74
- #75
- #76
- #77
- #85
- #49/#53–#56/#89
- #42

Exact wording is proposed in `07-existing-issue-amendments.md`.

## 5. Proposed new issue allocation

Temporary package IDs are not GitHub issue numbers.

| Package ID | Proposed issue | Milestone | Baseline | 3x planning |
| --- | --- | --- | ---: | ---: |
| NEW-UX-01 | Define the post-beta operator workspace interaction contract | M2.0 | 12h | 36h |
| NEW-UX-02 | Build the persistent progressive operator workspace | renamed M2.1 | 32h | 96h |
| NEW-UX-03 | Persist operator drafts, selection and workspace continuity | M2.0 | 20h | 60h |
| NEW-UX-04 | Add task-based work queues and snooze/resurface | M2.0 | 24h | 72h |
| NEW-UX-05 | Unify global search and scoped inbox filtering | renamed M2.1 | 12h | 36h |
| NEW-UX-06 | Add cognitive-accessibility workspace preferences and focus mode | renamed M2.1 | 16h | 48h |
| NEW-UX-07 | Replace transient ticket toasts with durable operator activity | M2.3 | 16h | 48h |
| NEW-UX-08 | Add customer context and contextual support panels | renamed M2.1 | 20h | 60h |
| NEW-UX-09 | Add configurable Table view and safe bulk ticket actions | renamed M2.1 | 16h | 48h |
| NEW-UX-10 | Add explicit waiting reasons and configurable support workflow states | M2.0 | 24h | 72h |
| NEW-UX-11 | Add workload-aware queues and operator capacity controls | M6.2 | 24h | 72h |
| NEW-UX-12 | Define workspace utility actions for call, remote support and external tools | renamed M2.1 | 12h | 36h |
| NEW-UX-13 | Measure operator interaction performance and enforce UI response budgets | renamed M2.1 | 8h | 24h |
| NEW-UX-14 | Validate redesigned operator workspace for usability and cognitive accessibility | renamed M2.1 | 16h | 48h |

**New-work total:** 252 baseline hours / 756 hours under the repository's mandatory 3x planning convention.

This does **not** mean all 756 hours block the next beta.

## 6. Gate A: required before next operator-facing prerelease

Gate A requires acceptance-relevant portions of:

- NEW-UX-01
- NEW-UX-02
- NEW-UX-03
- NEW-UX-04
- NEW-UX-05
- NEW-UX-06
- NEW-UX-07
- NEW-UX-08
- NEW-UX-10
- NEW-UX-13
- NEW-UX-14
- #48 operator-required primitives
- #66 operator-required tokens
- #71
- #68 durable-draft/core-composer portion

May remain post-gate if core workspace is coherent:

- NEW-UX-09 advanced bulk/Table customisation; basic secondary Table route should exist;
- NEW-UX-11 workload/capacity routing;
- NEW-UX-12 concrete external integrations; typed action slot should exist if otherwise structural;
- #69 macro breadth;
- remaining #70 collaboration breadth beyond duplicate-reply safety;
- #73 full SLA engine if beta does not promise SLA, while layout reserves due-state location;
- #75–#77 AI/context breadth.

## 7. Release changes

### Current truth

- accepted local private-beta testing checkpoint: 9 September 2026;
- no GitHub Release;
- no `v0.4.0-beta.1` tag/release;
- production/public authority remains separate.

### Proposed release rule

Add **Operator Workspace UX Gate A** as a prerequisite for the next operator-facing prerelease.

If no prerelease tag exists at consolidation, recommend keeping the actual candidate as `v0.4.0-beta.1`, but change its release acceptance to include Gate A.

If the maintainer explicitly records that the local untagged checkpoint consumes `beta.1` numbering, the corrected candidate becomes `v0.4.0-beta.2`.

The consolidated package must choose one based on actual tag/release state and record why. Never create a phantom historical tag.

### Production gate #42

Do not close or weaken #42.

Clarify:

- #42 validates production/cutover **technical readiness**;
- successful #42 is not by itself operator-usability acceptance;
- an operator-facing production/public release also requires the then-current UX gate.

## 8. Reforecast rule

After new issues/milestone/dependencies are accepted:

1. keep every existing Baseline start/target unchanged;
2. give new issues owner-approved baseline dates;
3. recalculate Forecast start/target from current actual status/dependencies;
4. record schedule variance;
5. update Wiki roadmap and Project fields together;
6. do not move dates merely to make the roadmap appear on time.

This package does not invent exact forecast dates because live GitHub Project workstream capacity/actual fields must be consulted at consolidation.

## 9. Parallel work rule

The intervention freezes **broad new dashboard presentation work**, not unrelated engineering.

Safe to continue where dependencies permit:

- cost/capacity contracts (#50/#64/#90);
- durable ingestion/recovery (#51/#87/#88/#91);
- production-readiness engineering that does not claim a user release;
- security/maintenance;
- provider backend contracts.

Before a new channel UI lands, it targets ADR-0016/updated #68 rather than the legacy full-page ticket detail.
