# Current State and Post-Beta Review Basis

## 1. Why this review is legitimate new project evidence

The accepted local private beta was intentionally a **functional/security/accessibility acceptance boundary**, not a full product-workspace redesign.

Issue #62, **Validate human handling of canonical ticket intake**, explicitly excluded workspace redesign. It proved that an operator could handle API/portal tickets, change assignment/state and send replies safely.

Issue #21, **Validate accessibility of core operator and portal workflows**, was explicitly first-beta scope. It proved keyboard, focus, labels, contrast and announcements on the included workflows. It did not certify future features or cognitive ergonomics.

Issue #65, **Rehearse and publish the human-led private beta**, accepted the local-only human-led API/portal test boundary. Its completion does not claim production or public-release maturity.

The first complete localhost experience therefore did exactly what a beta should do: it exposed product-level shortcomings that were not visible when individual routes and controls were assessed in isolation.

**Project interpretation:** these findings are successor evidence. They must not reopen or falsify #21, #62 or #65.

## 2. Verified implementation status at review

- Current reviewed `main`: `93de1b975a45edd9d28ca70edd725b60deb6b275`.
- Accepted application revision: `049ea82a02571681f834bcd87d43253603edf71f`.
- Local private-beta readiness accepted: 9 September 2026.
- GitHub Releases at review: none.
- `v0.4.0-beta.1`: candidate only; no tag/release was created.
- Ark/Zag headless design system: planned under #48/#66/#67; not the current implementation.
- Current dashboard remains React/Tailwind with locally composed controls and native elements.

## 3. Strengths that must survive the redesign

The beta is not a throwaway. Preserve these behaviours:

- tenant-scoped server authority;
- retry-safe and validated mutations;
- confirmed-state recovery instead of silently displaying failed writes;
- retained reply text and selected attachments after failed submission;
- explicit Public Reply vs Internal Note semantics;
- accessible labels, alerts, statuses and focus recovery;
- real-time invalidation of authoritative data;
- presence as informational collaboration state;
- saved filters;
- customer/internal visibility boundaries;
- audit attribution;
- AI-off human operation;
- local beta guardrails and resource limits.

A UI overhaul that regresses these would be a project failure even if it looks better.

## 4. Current operator interaction architecture

### Application shell

The current shell has:

- a 64px icon-only desktop navigation rail;
- a global `Search tickets...` field;
- a persistent real-time/disconnected chip;
- expandable latency/reconnect diagnostics and Force Reconnect;
- transient ticket-update toasts with entry animation;
- a general content route outlet.

### Ticket feed

The current primary ticket experience is:

- saved-filter column;
- page heading and New Ticket;
- a second `Search tickets...` field;
- seven-column ticket table;
- row action menu;
- pagination.

The table is appropriate for register-style administration. It is not an ideal default operator inbox.

### Ticket detail

Opening a ticket changes route and replaces queue context with a full-page ticket view containing, simultaneously:

- status;
- ticket reference;
- customer email and opened date;
- live-viewer presence;
- message thread;
- message attachments;
- per-message knowledge/QA controls;
- public/internal composer mode;
- explicit AI Suggestion control;
- separate AI Auto-Draft card;
- reply attachments;
- send action;
- priority;
- assigned agent;
- group;
- custom fields;
- another Active Now presence panel.

The resulting product asks the operator to prioritise the interface before they can prioritise the customer's problem.

## 5. Primary beta-review diagnosis

Five failures dominate:

1. **Flow:** route changes repeatedly interrupt work.
2. **Mental model:** a ticket is presented as a record to administer rather than a conversation requiring action.
3. **Working memory:** queue/filter/position context is not continuously visible.
4. **Cognitive load:** secondary metadata and technical state compete with the primary task.
5. **Selective attention:** animated/transient/colourful system signals capture attention regardless of user intent.

These are architectural UX failures. Headless controls alone cannot repair them.

## 6. Product target

Tocyn should target:

**the continuity of Freshdesk/Intercom + the restraint of Help Scout + the contextual depth of Zendesk + explicit W3C cognitive-accessibility controls**, while retaining Tocyn's stronger tenant/security/recovery boundaries.

It should not attempt to clone any competitor's density or commercial feature sprawl.

## 7. What must be retired or demoted

The plan does not require deleting history. It does require retiring several current presentation decisions:

- ticket table as the only/default operator inbox -> **demote to optional Table view**;
- full-route ticket detail as normal triage -> **replace with persistent workspace selection**;
- duplicate generic ticket search -> **replace with universal search + clearly scoped view filter**;
- persistent “Real-time / Operational” success indicators -> **remove from normal operator chrome**;
- routine transient ticket toasts -> **replace with durable, user-controlled attention state**;
- duplicated presence -> **one contextual collaboration location**;
- per-message QA actions in the normal reading flow -> **move to contextual knowledge/quality tools**;
- separate AI panel/card workflow -> **replace with inline augmentation of the existing composer/context**;
- icon-only navigation as the only desktop form -> **make labelled/expandable and persist the user's choice**;
- ambiguous `Pending` as the sole waiting concept -> **add explicit waiting/next-action semantics**;
- legacy `Luminatick` branding in Dashboard -> **remove immediately when the affected screen is next edited**.

## 8. Historical documents that must not remain authoritative

`docs/phase-2.2-layout-redesign.md` says no structural change is required for ticket list/detail/right sidebars. Beta evidence has disproved that premise.

Do **not** delete the file. Mark it **Superseded** and link to ADR-0016 and the new operator-workspace specification so the historical design decision remains auditable.

Likewise, first-beta dashboard/ticket specifications and `docs/operator-workflows.md` remain valid implementation/evidence history. Add successor links rather than rewriting them as if they had always described the new workspace.
