# ADR, Wiki and Documentation Change Set

## 1. ADR numbering

The repository-backed ADR index currently reaches ADR-0015. This package therefore proposes ADR-0016 through ADR-0019.

Before applying, check whether another consolidated package has allocated those numbers. If so, renumber these drafts and all backlinks together.

## 2. New ADRs

Add after review:

- ADR-0016 — Persistent operator workspace replaces route-driven ticket handling
- ADR-0017 — Durable operator attention state is distinct from canonical conversation state
- ADR-0018 — Cognitive accessibility and attention control are product architecture requirements
- ADR-0019 — Operator AI augments existing human workflows instead of creating a parallel UI

Full proposed text is in `/adrs`.

## 3. Existing ADR changes

### ADR-0010 — Policy-gated actions and reference validation

**No decision change.**

Add related-note only:

- operator macros, utility actions and AI suggestions do not bypass policy/permission boundaries;
- any future utility that performs governed backend mutation remains under ADR-0010.

### ADR-0011 — Architectural milestones and private beta (Wiki)

**Do not supersede. Add beta-review consequence.**

Add:

> Successful private-beta functional/security/accessibility acceptance does not certify product usability or operator-workspace maturity. Post-beta findings may create successor architectural milestones/issues without reopening accepted beta evidence. A later operator-facing release may add a UX acceptance gate distinct from deployment/cutover gates.

### ADR-0012 — Canonical conversations and channel adapters

**No decision change.**

Add Related:

- ADR-0016 operator workspace continuity;
- ADR-0019 operator AI augmentation.

Add Consequence:

> Provider adapters preserve canonical core state and expose typed channel capabilities to the shared operator workspace/composer. They do not create provider-specific operator inboxes.

### ADR-0013 — Email capability boundaries

No substantive change. Add ADR-0016/#68 cross-reference where support-email composer integration is described.

### ADR-0014 — Living delivery state uses baseline, forecast and actual evidence

**No decision change.**

Add post-beta planning example:

- accepted beta evidence remains actual history;
- new UX milestone is a reforecast trigger;
- original baseline fields remain immutable;
- new issues receive owner-approved baseline dates;
- Project forecast/variance is recalculated after dependency acceptance.

### ADR-0015 — Privacy metadata is not an access-control authority

**No decision change.**

Add Related:

- customer/operational context panels and workspace preferences are presentation/metadata consumers and never tenant/access authority;
- draft persistence follows authenticated tenant/user storage boundaries.

## 4. Wiki changes

### `Approved-architectural-roadmap`

Add:

- Post-Beta UX Review — 10 September 2026;
- new `M2.0: Fullstack - Operator Workspace Foundations`;
- rename M2.1 to `M2.1: Frontend - Operator Workspace & Navigation`;
- dependency sequence M2.0 -> operator portion #48/#66 -> M2.1 -> M2.2/M2.3;
- mark #67 non-blocking for standalone operator correction where possible;
- list new issues after real numbers allocated;
- add Operator Workspace UX Gate A;
- preserve old baseline dates and show reforecast separately;
- clarify local beta accepted but untagged.

### New Wiki page: `Operator-workspace-UX-architecture`

Include:

- governing mental model;
- desktop/mobile panel layouts;
- work-view definitions;
- route/deep-link semantics;
- context panel;
- draft/work-state;
- search;
- keyboard;
- notifications;
- Table mode;
- utility action slots;
- screenshots/wireframes only after accepted design, with complete prose equivalents.

### New Wiki page: `Cognitive-accessibility-and-neuroinclusive-design`

Include:

- W3C cognitive accessibility basis;
- attention, working memory, interruption, predictability and personalisation;
- default calmness;
- motion policy;
- target-size policy;
- no transient-only actionable information;
- focus mode;
- navigation labels;
- testing;
- explicit statement that preferences are interface choices, not health diagnoses.

### `System-architecture`

Update target browser section from generic Operator dashboard to accepted persistent operator-workspace composition.

Add:

- durable draft/work-attention state;
- workspace preference boundary;
- durable activity projection;
- channel-capability interface into composer/context.

Keep implemented-vs-planned separation.

### `Start-here` and `Home`

Add links to:

- Operator workspace UX architecture;
- Cognitive accessibility;
- post-beta review;
- new ADRs.

Clarify that first local beta proved core operation and exposed successor UX work.

### `Roadmap-and-releases`

Add:

- local beta checkpoint date and no-tag truth;
- UX Gate A;
- prerelease naming decision rule;
- no production/public implication.

### `Omnichannel-implementation-roadmap`

Add shared UI integration requirement:

- all providers render into ADR-0016 workspace;
- #68 channel-capability composer;
- no per-provider dashboard;
- provider constraints contextual;
- backend adapter testing can progress before final UI, but user-facing acceptance includes workspace integration.

### `Channels-and-conversation-model`

Add:

- channel identity/capabilities visible in conversation header/composer;
- channel switch/recipient restrictions typed;
- canonical conversation remains primary operator object.

### `AI-and-autonomous-operations`

Add ADR-0019:

- operator AI inline in existing draft/context;
- AI-off operation complete;
- no operator auto-send;
- autonomous M4 remains ADR-0010-governed.

### `Architecture-decision-records`

Add ADR-0016–0019 and backlinks.

## 5. Repository documentation changes

### `docs/roadmap.md`

Add `Post-beta UX review`:

- arose from accepted local beta;
- no closed first-beta issue reopened;
- new M2.0/intervention;
- reforecast required under ADR-0014;
- next operator-facing prerelease gated.

Do not delete historical forecast text; annotate as baseline/history if reforecast changes.

### `docs/architecture/system-overview.md`

Current target already says operators work in one canonical conversation workspace. Expand browser target to:

```text
Operator workspace
  Work views
  Conversation list
  Active conversation + composer
  Context panel
  Activity/commands/preferences
```

Add planned durable operator-state projection and distinguish it from canonical conversation authority.

### `docs/phase-2.2-layout-redesign.md`

**Mark Superseded. Do not delete.**

Suggested header:

> **Status: Superseded by post-beta operator-workspace review / ADR-0016.**  
> This plan correctly reduced top-level administrative navigation but its “no structural changes” assumption for ticket list/detail/right sidebar was invalidated by first-beta use. Preserve for history only.

### `docs/phase-1.3-dashboard-spec.md`

Mark as first-beta/historical implementation specification and link to successor workspace architecture. Do not rewrite it as though the new UX formed part of its acceptance.

### `docs/operator-workflows.md`

Preserve executable first-beta evidence. Add:

> Post-beta product review identified interaction/working-memory defects outside this document's functional acceptance. See post-beta UX review and ADR-0016.

### `docs/private-beta-readiness.md`

Preserve acceptance evidence. Add post-review addendum only:

- beta readiness remains true for its local scope;
- successor UX work gates next operator-facing release;
- no regression in security/accessibility acceptance is implied.

### New `docs/ux/` family

Propose:

- `docs/ux/post-beta-review-2026-09-10.md`
- `docs/ux/operator-workspace.md`
- `docs/ux/cognitive-accessibility.md`
- `docs/ux/validation.md`

### `docs/README.md`

Add new UX documentation group.

### Root `README.md`

After project change acceptance:

- current local beta remains working evidence;
- target operator workspace is planned until implementation lands;
- avoid screenshots/text presenting legacy table/detail UI as final architecture.

## 6. Source/UI retirement plan after implementation

These are future disposition targets, not instructions to delete now:

| Current surface | Disposition |
| --- | --- |
| `TicketListPage.tsx` | Extract/reuse query/table logic; default feed replaced by ConversationList; refactor into optional Table view where useful. |
| `TicketDetailPage.tsx` | Decompose into workspace components; retire monolithic full-page composition after compatibility parity. |
| `Layout.tsx` healthy real-time chip | Remove healthy-state operator diagnostic; keep degraded notice and move diagnostics to admin/support surface. |
| `Layout.tsx` routine ticket toasts | Replace with durable Activity projection; transient mirror optional for configured high-priority events only. |
| duplicated presence surfaces | Consolidate into Collaboration context. |
| per-message QA hover controls | Move to Knowledge/QA context or moderation mode. |
| separate AI Auto-Draft card | Retire after #68/#77 inline-composer parity. |
| current Dashboard system pulse | Remove; replace home with actionable work or mature #85 analytics. |
| legacy `Luminatick` copy | Delete from Tocyn-facing UI. |

Delete/refactor source only after successor tests prove parity; preserve Git history rather than maintaining dead compatibility indefinitely.
