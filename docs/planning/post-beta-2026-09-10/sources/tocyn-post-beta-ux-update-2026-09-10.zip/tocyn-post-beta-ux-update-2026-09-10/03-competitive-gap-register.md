# Competitive Gap Register

Benchmarks were checked against current 2026 documentation for Intercom, Freshdesk, Zendesk and Help Scout. Spiceworks is treated as an IT-helpdesk breadth baseline rather than the visual target. Tocyn should copy proven interaction concepts, not competitor density or branding.

| ID | Capability | Severity | Tocyn beta | Technical response | Primary owner | Dependencies |
| --- | --- | --- | --- | --- | --- | --- |
| COMP-01 | Persistent inbox + active conversation | Critical | No; table/detail are separate routes. | Persistent navigator/list/conversation/context workspace. Deep links select conversation without destroying work view. | NEW-UX-02 | #48/#66 |
| COMP-02 | Retain queue position/context | Critical | Weak. | Persist view, query, sort, selected ticket and scroll anchor; authority change invalidates state. | NEW-UX-03 | #71 |
| COMP-03 | Task-based inboxes | High | Saved filters only. | First-class Mine, Unassigned, Mentions, Drafts, Snoozed, Needs Action and team/custom views; bounded authoritative counts. | NEW-UX-04 | #70/#73 |
| COMP-04 | Configurable queue layout | High | Fixed table. | Conversation-list default plus configurable Table view with saved columns/order/density and preview. | NEW-UX-09 | #66 |
| COMP-05 | SLA visibility | Critical for B2B | Not implemented. | #73 exposes due/breach in list row and action bar, not just settings/reporting. | #73 | NEW-UX-10 |
| COMP-06 | Snooze/resurface | Critical | Absent. | Tenant-scoped audited snooze/next-action state with deterministic resurfacing and Snoozed view. | NEW-UX-04 | #63 |
| COMP-07 | Draft autosave across navigation/reload | High | Failure retention good; voluntary navigation resets local composer. | Server-backed per-user/per-ticket drafts using scoped body storage; revision/mode/attachments/retention; Draft badge/view. | #68 + NEW-UX-03 | ADR-0017 |
| COMP-08 | Saved replies | High | Absent. | Retain #69; searchable slash/command insertion, merge-tag validation and preview. | #69 | #68 |
| COMP-09 | Macros / multi-action shortcuts | High | Absent. | Retain #69; permission-checked composed actions, preview, attribution and safe mutation semantics. | #69 | #79 |
| COMP-10 | Command palette | High | Planned. | Expand #71 to universal command surface for navigation, search and authorised current-ticket commands; discoverable/disable-able. | #71 | NEW-UX-02 |
| COMP-11 | Full keyboard triage | High | Accessibility exists; triage acceleration planned. | #71 operates on new workspace: next/previous, assign, state, snooze, reply/note, send, focus regions. | #71 | NEW-UX-14 |
| COMP-12 | Collision prevention | High | Presence exists, not conflict gate. | #70 adds server revision/last-seen precondition; concurrent/new content yields review state while preserving draft; no auto-resend. | #70 | #63 |
| COMP-13 | Customer 360° context | Critical | Mostly email on current ticket. | Context panel uses verified tenant-scoped identity, previous conversations/contact details; #74 links verified channels; #75 adds operational context. | NEW-UX-08 | #74/#75 |
| COMP-14 | Omnichannel operator workspace | Critical long-term | Canonical architecture exists; channels planned. | Every #53–#56/#89 adapter renders in same workspace using channel-capability contract; restrictions appear contextually. | #49/#53–#56/#89 | ADR-0016 |
| COMP-15 | Rich/channel-aware composer | High | Plain textarea. | #68 shared composer + channel capability model, formatting, recipients/constraints, draft persistence, attachments and extension hooks. | #68 | #53–#56/#89 |
| COMP-16 | Inline knowledge insertion | High | Knowledge exists but not low-friction composer action. | Search/preview/insert KB from slash/context; move per-message QA administration away from reading flow. | #68 / NEW-UX-08 | #77 |
| COMP-17 | AI summarisation | High | No first-class summary. | #76 schema-validated bounded summary; progressive/on-demand display in header/context. | #76 | ADR-0019 |
| COMP-18 | AI rewrite/tone/translate | Medium-High | Separate AI suggestion card only. | Expand #77: improve, shorten, clarify, tone, translate on selected/draft text; preview/accept; no auto-send. | #77 | ADR-0019 |
| COMP-19 | Context-aware AI assistance | High | Single suggestion endpoint. | #77 consumes authorised current conversation/context/KB with provenance/freshness; AI-disabled path unchanged. | #77 | #75/#76 |
| COMP-20 | Bulk queue actions | High | No mature bulk workflow. | Table selection + bounded server batch mutations, permission checks, idempotency, partial-failure receipts and confirmation. | NEW-UX-09 | #60/#64/#79 |
| COMP-21 | Workload/capacity awareness | Medium-High | Absent. | Authoritative per-agent/team active-work counts, availability/limits and routing inputs; separate from surveillance analytics. | NEW-UX-11 | #73/#85 |
| COMP-22 | Custom workflow/waiting states | Medium-High | Fixed open/pending/resolved/closed. | Add additive tenant-defined work-state definitions mapped to stable lifecycle categories; explicit waiting reason/SLA behaviour. | NEW-UX-10 | #73 |
| COMP-23 | IT asset/device/service context | Medium / market dependent | Absent. | Keep core generic. NEW-UX-08 typed context slots; #75 optional authorised asset/service/device/log connectors with provenance. | NEW-UX-08 | #75 |
| COMP-24 | Call / remote-support utilities | High if technical-support market | No workspace utility surface. | Typed permission-checked utility-action registry/slot now; specific call/remote integrations later with validated origins/permissions. | NEW-UX-12 | #79 |
| COMP-25 | Actionable reporting | High | Dashboard totals/priority/users/groups + healthy pulse. | #85 mature metrics; operator home links to Needs Action/SLA risk/unassigned/resurfaced/workload; technical health to admin diagnostics. | #85 / NEW-UX-02 | #73 |
| COMP-26 | Contextual workspace configuration | Medium-High | Fixed detail surface. | Capability-driven/collapsible context sections/actions; role/admin defaults without hiding required safety/status information. | NEW-UX-08 | #79 |

## Benchmark direction

### Intercom
Borrow configurable Chat/Table layouts, custom views/folders, SLA-aware filtering, macros, command navigation and user-customisable sidebars/composer shortcuts. Do **not** copy the entire visual density.

### Freshdesk
The current Quick List model directly confirms the beta finding: multiple tickets from one screen, switching without leaving detail, restoration of the last list across sessions, draft autosave through refresh/close, Draft labels in the list, and progressive AI summary access.

### Zendesk
Useful patterns are the unified agent workspace, right-side customer/context panel, contextual workspaces, knowledge and side-conversation context.

### Help Scout
Useful patterns are restrained presentation, strong keyboard commands, saved replies and collision detection beyond presence.

### Spiceworks
Relevant mainly as technical-support category breadth: queue/inbox, SLA, knowledge, contact/asset/configuration context, remote access/control and reporting expectations. It is not the visual target.
