# Existing Issue Amendment Set

These are proposed issue-body **additions/amendments**, not instructions to rewrite completed history. Preserve original comments, accepted checklists, baselines and receipts.

## #48 — Establish shared headless primitives for standalone Tocyn

**Change:** keep title/milestone; amend scope and sequencing.

Add beta-review constraint:

> Post-beta UX review establishes that the first-beta ticket table/full-detail interaction is not the target operator workspace. The migration matrix MUST classify existing UI as **retain/migrate**, **replace**, or **compatibility-only/retire**. “ALL existing base-component migration” means every retained base behaviour is accounted for; it does not require reproducing obsolete product compositions one-for-one before replacing them.

Add prerequisite:

- NEW-UX-01 / accepted ADR-0016.

Add acceptance:

- persistent navigator/list/conversation/context composition primitives;
- no critical hover-only action;
- target-size/focus/reduced-motion tests;
- command/listbox/panel composition needed by #71;
- interaction-response cost as well as bundle/startup cost;
- compatibility adapters may exist temporarily but obsolete behaviour is removed after parity;
- queue/work-state semantics remain M2.0/ADR-0016/0017 ownership.

## #66 — Apply tenant themes through standard CSS variables

**Change:** keep title/milestone; expand accessibility-token contract.

Add contracts for:

- motion duration/easing with reduced-motion path;
- control target sizing;
- density;
- typography scale/line height;
- selected/focus/critical/quiet salience;
- panel/divider surfaces.

Rules:

- tenant branding cannot reduce required focus visibility, contrast or minimum target accessibility;
- `prefers-reduced-motion` applies unless a valid user preference overrides;
- cognitive/workspace preference values are NEW-UX-06 ownership, not tenant-brand data;
- healthy system state must not require animated tokens.

## #68 — Add a rich conversation composer

**Change:** keep title/milestone; expand draft/channel architecture.

Add:

- autosave across ticket switch, route change and reload;
- server-backed tenant/user-scoped draft content, not sensitive persistent browser storage by default;
- Draft badge and Drafts view;
- Save-failed/unsaved recovery;
- base-conversation revision for #70 collision review;
- channel capability contract for recipients/format/attachments/limits;
- KB/saved-response insertion hooks;
- AI transforms use the same draft inline;
- Public Reply/Internal Note mode restores unambiguously.

Gate A may accept durable core-composer work with `Progresses #68` while richer Markdown/code/emoji breadth stays open.

## #69 — Add reusable responses and safe operator macros

Keep. Add:

- composer slash menu + command palette;
- exact preview of message/ticket mutations;
- current verified selection and stale-selection protection;
- bulk macro use follows NEW-UX-09;
- all actions remain permission/audit/policy checked.

## #70 — Add typing awareness and private colleague collaboration

Keep. Add:

- presence is advisory;
- reply includes conversation revision/last-seen precondition;
- material new content creates explicit conflict/review without draft loss/auto-resend;
- one Collaboration context replaces duplicated viewers;
- mentions create durable activity owned by NEW-UX-07;
- typing/presence respects motion/interruption preference and expires cleanly.

## #71 — Enable keyboard-first workspace navigation

Keep title; target ADR-0016 rather than legacy page transitions.

Add prerequisites:

- NEW-UX-02;
- NEW-UX-04;
- #48 operator primitives;
- #66.

Keep #62 as satisfied historical functional evidence rather than the target UI.

Add commands:

- focus work views/list/conversation/context;
- next/previous;
- open;
- assign;
- state;
- snooze;
- resolve;
- reply/internal note;
- saved reply/KB;
- send;
- `Cmd/Ctrl+K`.

Add:

- shortcut help/search;
- shortcuts user-disable-able;
- no single-key conflicts while typing;
- list reorder/removal preserves sensible focus;
- screen-reader acceptance against final workspace.

## #73 — Expose SLA progress and responsible handlers

Keep; integrate with NEW-UX-10.

Add:

- due/breach in ConversationList;
- due/paused state in TicketActionBar;
- SLA visible without settings/report screen;
- waiting reason deterministically controls pause/resume;
- colour not sole signal;
- SLA risk may generate durable activity through NEW-UX-07 by policy.

## #74 — Preserve conversations across verified channel changes

Keep. Add that verified linked identities feed NEW-UX-08 Customer Context. Context presentation itself never grants authority.

## #75 — Enrich intake with authorised operational context

Keep backend scope. Add typed provenance/freshness/availability output consumable by NEW-UX-08. Allow optional asset/service/device/log reference types without making ITSM objects mandatory to core.

## #76 — Add bounded triage and conversation summarisation

Keep. Add display rule:

- summary is optional/progressive;
- no permanent AI panel required;
- uncertainty visible;
- AI unavailable yields normal human workflow;
- summary never hides original conversation or becomes mutation authority.

## #77 — Expand the operator copilot with translation and runbooks

Keep; add:

- improve clarity;
- shorten;
- tone;
- translate;
- draft reply;
- explain/cite runbook/knowledge;
- selected text/current draft;
- same composer draft;
- provenance/freshness;
- explicit operator accept/send;
- no standalone AI tab/surface required;
- AI-off workspace complete.

## #85 — Report operational performance and quality metrics

Keep; add:

- response/resolution/SLA/workload/queue metrics deep-link to authorised work views where useful;
- operator-home cues separated from supervisor analytics;
- no pulsing `Operational` routine operator content;
- every metric defines denominator/freshness/actionability.

## #49 — Track delivery of the omnichannel architecture

Keep cross-roadmap tracker. Add:

- every provider has channel-capability mapping for ADR-0016 workspace and #68 composer;
- no provider-specific operator inbox;
- delivery/window/recipient restrictions contextual;
- future channel UI passes cognitive/accessibility acceptance.

## #53/#54/#55/#56/#89 — provider/support-email issues

Keep provider-specific scope. Add to UI acceptance:

- shared canonical work view/conversation/composer;
- source/channel identity;
- channel-specific reply limitation at action point;
- preserve draft if send becomes unavailable;
- no separate provider ticket screen.

Backend adapter implementation may progress before UI polish if contracts can be tested headlessly; user-facing acceptance includes workspace integration.

## #67 — Package isolated helpdesk Web Components

Keep functionally. Remove from operator-workspace critical path where possible. Embedded delivery should not delay standalone operator correction absent a hard shared-primitive dependency.

## #42 — Validate production cutover and rollback readiness

Keep open. Add:

> Technical production/cutover readiness does not constitute operator UX release acceptance. Any operator-facing public/remote release also requires the current Operator Workspace UX Gate. The post-beta UX gate does not weaken or replace backup, migration, security, rollback or tenant-isolation requirements owned by #42.

## #21 / #62 / #65 / #93

**No reopening. No acceptance rewrite.**

Optional cross-reference only:

> Subsequent post-beta usage identified product-level workspace/cognitive UX issues outside this issue's accepted scope. Successor work is tracked by the post-beta UX update; this issue remains historically complete.
