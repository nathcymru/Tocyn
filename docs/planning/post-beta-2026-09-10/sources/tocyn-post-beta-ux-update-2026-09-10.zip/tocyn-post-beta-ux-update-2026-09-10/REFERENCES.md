# References

Sources were checked for this post-beta planning package on 10 September 2026 unless noted otherwise.

## Tocyn repository evidence

- Repository: https://github.com/nathcymru/Tocyn
- Current reviewed main: `93de1b975a45edd9d28ca70edd725b60deb6b275`
- Accepted application revision: `049ea82a02571681f834bcd87d43253603edf71f`
- #21: https://github.com/nathcymru/Tocyn/issues/21
- #42: https://github.com/nathcymru/Tocyn/issues/42
- #48: https://github.com/nathcymru/Tocyn/issues/48
- #49: https://github.com/nathcymru/Tocyn/issues/49
- #53–#56: https://github.com/nathcymru/Tocyn/issues
- #62: https://github.com/nathcymru/Tocyn/issues/62
- #65: https://github.com/nathcymru/Tocyn/issues/65
- #66: https://github.com/nathcymru/Tocyn/issues/66
- #67: https://github.com/nathcymru/Tocyn/issues/67
- #68: https://github.com/nathcymru/Tocyn/issues/68
- #69: https://github.com/nathcymru/Tocyn/issues/69
- #70: https://github.com/nathcymru/Tocyn/issues/70
- #71: https://github.com/nathcymru/Tocyn/issues/71
- #73: https://github.com/nathcymru/Tocyn/issues/73
- #74: https://github.com/nathcymru/Tocyn/issues/74
- #75: https://github.com/nathcymru/Tocyn/issues/75
- #76: https://github.com/nathcymru/Tocyn/issues/76
- #77: https://github.com/nathcymru/Tocyn/issues/77
- #85: https://github.com/nathcymru/Tocyn/issues/85
- #89: https://github.com/nathcymru/Tocyn/issues/89
- #93: https://github.com/nathcymru/Tocyn/issues/93
- Private-beta readiness: `docs/private-beta-readiness.md`
- Roadmap: `docs/roadmap.md`
- System architecture: `docs/architecture/system-overview.md`
- ADR index: `docs/adr/README.md`
- ADR-0012: `docs/adr/ADR-0012-canonical-conversations-and-channel-adapters.md`
- ADR-0014: `docs/adr/ADR-0014-living-delivery-state.md`
- Historical layout plan: `docs/phase-2.2-layout-redesign.md`

## UX principles

- Laws of UX: https://lawsofux.com/laws/
- Cognitive Load: https://lawsofux.com/cognitive-load/
- Flow: https://lawsofux.com/flow/
- Hick's Law: https://lawsofux.com/hicks-law/

These are heuristics/principles, not statutory accessibility standards.

## W3C cognitive accessibility / WCAG

- W3C Cognitive Accessibility: https://www.w3.org/WAI/cognitive/
- Cognitive and learning barriers: https://www.w3.org/WAI/people-use-web/abilities-barriers/cognitive/
- Help users focus: https://www.w3.org/WAI/WCAG2/supplemental/objectives/o5-user-focus/
- Minimal interruptions: https://www.w3.org/WAI/WCAG2/supplemental/patterns/o5p01-minimal-interruptions/
- Clear controls: https://www.w3.org/WAI/WCAG2/supplemental/patterns/o1p05-clear-controls/
- WCAG 2.2: https://www.w3.org/TR/WCAG22/
- Target Size (Minimum): https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum
- Interruptions: https://www.w3.org/WAI/WCAG22/Understanding/interruptions
- Pause, Stop, Hide: https://www.w3.org/WAI/WCAG22/Understanding/pause-stop-hide

## Intercom

- Customize Inbox: https://www.intercom.com/help/en/articles/7911926-customize-the-inbox-to-suit-you-and-how-you-work-best
- Custom views/folders: https://www.intercom.com/help/en/articles/6588834-organize-your-inbox-with-custom-views-and-folders
- Table layout: https://www.intercom.com/help/en/articles/6603905-how-to-find-and-view-tickets-in-the-inbox
- SLA: https://www.intercom.com/help/en/articles/6546152-set-slas-for-conversations-and-tickets
- Macros: https://www.intercom.com/help/en/articles/6584504-using-macros-in-the-inbox
- Create/manage macros: https://www.intercom.com/help/en/articles/6433193-creating-and-managing-macros

## Freshdesk

- Ticket details enhancements / Quick List / draft autosave / channel editor:
  https://support.freshdesk.com/support/solutions/articles/50000013902-ticket-details-enhancements

## Zendesk

- Agent Workspace:
  https://support.zendesk.com/hc/en-us/articles/4408821259930-About-the-Zendesk-Agent-Workspace
- Context panel:
  https://support.zendesk.com/hc/en-us/articles/4408828503450-Configuring-the-context-panel-in-the-Zendesk-Agent-Workspace
- Contextual workspaces:
  https://support.zendesk.com/hc/en-us/articles/4408822138522-Managing-contextual-workspaces

## Help Scout

- Keyboard shortcuts: https://docs.helpscout.com/article/419-keyboard-shortcuts
- Collision detection: https://docs.helpscout.com/article/99-prevent-duplicate-replies-with-collision-detection
- Saved replies: https://docs.helpscout.com/article/18-create-saved-replies-for-fast-answers

## Spiceworks / technical-support category breadth

The Spiceworks first-party site was not directly accessible to the research browser, so no first-party product claim should be inferred here.

Third-party category evidence:

- G2 Spiceworks Cloud Help Desk features:
  https://www.g2.com/products/spiceworks-cloud-help-desk/features
- Capterra Spiceworks Cloud Help Desk reviews:
  https://www.capterra.com/p/102709/Spiceworks-IT-Help-Desk/reviews/

Use Spiceworks only as a category-breadth reference for ticketing, queues, SLA, knowledge, contacts, asset/configuration context, remote support and reporting—not as Tocyn's visual target.
