# Tocyn Post-Beta UX/UI Project Update Package

**Package date:** 10 September 2026  
**Repository reviewed:** `nathcymru/Tocyn`  
**Current `main` reviewed:** `93de1b975a45edd9d28ca70edd725b60deb6b275`  
**Accepted application revision underlying the local private beta:** `049ea82a02571681f834bcd87d43253603edf71f`  
**Package type:** project update following beta review  
**This is not:** a recovery package, implementation patch, deployment instruction, or repository mutation.

## Purpose

The first functioning local private beta made Tocyn's operator workflow visible as a complete product rather than as isolated implementation tasks. That review exposed severe product-level UI/UX problems which were outside the deliberately bounded acceptance of the first-beta work.

This package converts those observations into a complete, traceable project-plan change set. It does not compress the findings into a short priority list. Every negative finding from the beta review is carried into one or more explicit remediation items, acceptance gates, existing-issue amendments, new-issue proposals, ADRs, documentation changes, or later-roadmap dependencies.

## Critical conclusion

The problem is not primarily the current component library.

The current operator experience is built around a **ticket-record mental model**:

`ticket table -> full ticket route -> work ticket -> Back to Tickets -> reconstruct queue context`

The target must become a **continuous operator-workspace mental model**:

`work view remains visible -> select conversation -> understand -> act -> resolve/snooze -> advance -> context persists`

Ark/Zag headless primitives remain an appropriate implementation foundation, but issue #48 must not blindly migrate obsolete interaction structures and thereby make the wrong workflow more polished.

## Current beta/release truth

The repository documentation records the local-only private-beta testing boundary as accepted on 9 September 2026. The accepted beta used Wrangler/local resources, synthetic tenants and locally captured authentication mail. It grants no production or public-release authority.

There is **no GitHub Release** for Tocyn at the package date. The repository roadmap describes `v0.4.0-beta.1` as a candidate that has not been created. Therefore:

- retain the accepted 9 September local checkpoint as historical beta evidence;
- do not retcon #21, #62 or #65;
- do not claim that `v0.4.0-beta.1` was published;
- make the next operator-facing prerelease conditional on the post-beta UX acceptance gate;
- if no prerelease tag is created before this package is consolidated, the most evidence-accurate actual prerelease candidate remains `v0.4.0-beta.1`;
- if the maintainer deliberately decides that the untagged local checkpoint consumes the “beta.1” ordinal for product communication, use `v0.4.0-beta.2` instead and document that numbering decision explicitly. Do not infer it silently.

## Recommended roadmap intervention

Add **`M2.0: Fullstack - Operator Workspace Foundations`** and insert a bounded Post-Beta Operator UX Correction programme before substantial expansion of the existing dashboard UI.

The dependency sequence should become:

`accepted local beta -> M2.0 interaction/work-state foundations -> #48/#66 retained headless foundation -> renamed M2.1 operator workspace -> M2.2 composer/productivity -> M2.3 realtime/collaboration -> normal M3/M6/M7 path`

Unrelated backend/security/cost work may continue where it does not cement the obsolete operator presentation.

## Files in this package

1. `01-current-state-and-beta-review.md` — evidence boundary, strengths and current UX architecture.
2. `02-ux-law-gap-register.md` — exhaustive law-level findings and remediation.
3. `03-competitive-gap-register.md` — feature/workflow benchmark and technical response.
4. `04-cognitive-accessibility-gap-register.md` — AuDHD/cognitive-accessibility gap register.
5. `05-target-operator-workspace-architecture.md` — target IA, state, routes, components and data contracts.
6. `06-project-plan-change-set.md` — milestone, issue, sequencing and release-plan changes.
7. `07-existing-issue-amendments.md` — proposed amendments to existing issues without rewriting historical acceptance.
8. `08-new-issue-proposals.md` — complete proposed issue bodies using temporary package identifiers.
9. `09-adr-and-documentation-change-set.md` — ADR, Wiki and repository-document changes.
10. `adrs/ADR-0016-operator-workspace-continuity.md`
11. `adrs/ADR-0017-durable-operator-attention-state.md`
12. `adrs/ADR-0018-cognitive-accessibility-and-attention-control.md`
13. `adrs/ADR-0019-operator-ai-augments-human-workflows.md`
14. `10-validation-and-release-gates.md` — usability, accessibility, performance and release acceptance.
15. `11-traceability-matrix.md` — finding-to-change ownership matrix.
16. `REFERENCES.md` — repository and external benchmark sources.
17. `MANIFEST.md` — consolidation instructions and non-authority statement.

## Consolidation instructions

This package is designed to be combined with other project-update packages.

When consolidating:

- compare against the then-current `main`, issue states and Project fields;
- allocate real GitHub issue numbers only when issues are actually created;
- preserve ADR-0014 baseline dates and use forecast/actual fields rather than overwriting history;
- preserve completed issue evidence;
- resolve any concurrently allocated ADR numbers before committing the proposed ADR drafts;
- rerun the roadmap forecast after new issue dependencies are accepted;
- do not turn proposed technical paths in this package into deployment claims;
- do not merge this package mechanically if later code has already solved a listed gap—record the changed evidence and disposition instead.

## Non-authority statement

Nothing in this ZIP changes the repository, creates GitHub issues, modifies milestones, publishes Wiki pages, creates tags/releases, deploys Cloudflare resources, sends mail, or changes tenant/customer data.
