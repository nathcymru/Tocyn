# Cognitive Accessibility / AuDHD Gap Register

There is no single formal “AuDHD UI standard”. This plan therefore uses W3C cognitive accessibility guidance, WCAG 2.2, conventional usability principles and explicit user control of attention/working-memory demands. ADHD and autism are both within populations addressed by W3C cognitive accessibility work.

| ID | Need | Severity | Beta gap | Required response | Ownership |
| --- | --- | --- | --- | --- | --- |
| COG-01 | Persistent orientation | Critical | Opening a ticket removes visible queue. | Persistent navigator/list/conversation shell; mobile back preserves exact work state. | ADR-0016 / NEW-UX-02 |
| COG-02 | Recognition rather than recall | Critical | Operator remembers filter/page/position. | Visible active view/reason-for-inclusion; persisted selection/scroll/sort/filter. | NEW-UX-03 |
| COG-03 | Low working-memory demand | Critical | Repeated context reconstruction and scattered work state. | Header shows who/what/why-needs-attention/next-due; relevant status controls grouped. | NEW-UX-02 / NEW-UX-04 |
| COG-04 | Progressive disclosure | Critical | Metadata, AI, QA, presence and conversation compete. | Primary conversation first; context/knowledge/collaboration on demand with remembered panel state. | NEW-UX-02 / NEW-UX-08 |
| COG-05 | Low-interruption environment | Critical | Routine real-time toasts interrupt task. | Durable Activity centre; badge for routine events; configurable interruption classes; no transient-only critical notice. | ADR-0018 / NEW-UX-07 |
| COG-06 | Control of movement | High | Pulse, slide-in and hover-scale motion are nonessential. | Respect `prefers-reduced-motion`; persistent user override; remove healthy pulses/decorative transforms. | #66 / NEW-UX-06 |
| COG-07 | Visible navigation labels | High | Desktop navigation icon-only. | Expandable labelled rail; label+icon for key destinations; persist preference. | NEW-UX-06 / #71 |
| COG-08 | Literal state terminology | High | `Pending` does not identify who/what is awaited. | Waiting for customer/internal/scheduled follow-up/external system/etc.; stable machine lifecycle separate. | NEW-UX-10 |
| COG-09 | Clear primary task | Critical | Many visually similar actions compete. | One dominant state-appropriate action; quiet secondaries; rare actions under More/context. | NEW-UX-01 / #48 |
| COG-10 | Manageable content quantity | Critical | Information-dense full ticket page. | Persistent workspace with one primary conversation surface; collapsible context; density modes. | NEW-UX-02 / NEW-UX-06 |
| COG-11 | Resumability | Critical | No first-class snooze; voluntary switch loses draft. | Server draft + Snoozed/Needs Action; deterministic resurfacing and deep-link resume. | ADR-0017 / NEW-UX-03/04 |
| COG-12 | Externalised task management | Critical | Operator remembers future follow-up. | Snooze/next-action/due/waiting reason, persistent views and reminders. | NEW-UX-04 / #73 |
| COG-13 | Predictable shell | High | Route transition materially reconfigures task context. | Stable panel positions and focus targets; normal ticket switching does not rebuild mental map. | ADR-0016 / NEW-UX-02 |
| COG-14 | Personalisation | High | Little control over workspace presentation. | User-scoped density, nav labels, context default, font scale, motion, interruptions, shortcuts and advance-after-resolve. | ADR-0018 / NEW-UX-06 |
| COG-15 | Focus mode | High | No distraction-reduced mode. | Optional focus mode collapses optional surfaces/suppresses noncritical activity without hiding delivery/state/safety errors. | NEW-UX-06 |
| COG-16 | Clear search scope | High | Two fields both say Search tickets. | One global command/search; list control explicitly `Filter this view`; query semantics documented. | NEW-UX-05 |
| COG-17 | Large/easy targets | High | Tiny icon and hover-only controls. | WCAG 2.2 24x24 minimum or valid exception; 44x44 design target for frequent primary controls; no critical hover-only affordance. | #48 / NEW-UX-14 |
| COG-18 | Keyboard acceleration without memorisation | High | Future #71; current access != efficient triage. | Command palette, shortcut help, focus commands and optional shortcut disablement; features remain pointer/AT accessible. | #71 |
| COG-19 | Durable important information | High | Ticket toasts expire after ~8 seconds. | Activity/notification projection with read state; transient toast may mirror but never be sole carrier. | NEW-UX-07 |
| COG-20 | Draft protection | High | Failed-request protection strong; navigation persistence weak. | Server autosave, versioning, discard/send cleanup and Draft indicators; avoid sensitive persistent localStorage by default. | #68 / NEW-UX-03 |
| COG-21 | Sensory hierarchy | Critical | Many colours, pulses, badges/cards demand attention. | Semantic salience hierarchy; colour never sole signal; high salience for selected/primary/error/SLA breach only. | #66 / ADR-0018 |
| COG-22 | Error tolerance and recovery | Strength to preserve | Current beta is strong. | Make non-regression gate for every workspace mutation/draft path. | NEW-UX-14 / #60 |
| COG-23 | Choice of reading context | Medium-High | Fixed density and constrained message pane. | Comfortable/compact density, context collapse, sensible line length, zoom compatibility, no tiny interactive typography. | #66 / NEW-UX-06 |
| COG-24 | Interruption recovery cue | High | Returning gives little explicit 'where was I?' cue. | Persist selected ticket/last work view; optional Resume for drafts/snoozed/last active; no shame/gamification. | NEW-UX-03 / NEW-UX-04 |

## Proposed design policy

1. **Default calmness:** healthy infrastructure is silent.
2. **No actionable information exists only transiently.**
3. **Working state survives interruption.**
4. **Recognition is preferred to recall.**
5. **Conversation and next action own the visual hierarchy.**
6. **Secondary context is discoverable but progressively disclosed.**
7. **Motion and routine interruptions are user controllable.**
8. **Keyboard shortcuts accelerate; they never become the only access path.**
9. **Tenant branding cannot remove required contrast/focus/target-size protections.**
10. **AI is optional and cannot become a prerequisite for a comprehensible workspace.**

## Privacy note

Do not persist sensitive draft/customer content in long-lived `localStorage` merely to improve resumability. Use tenant/user-authorised server storage built on Tocyn's scoped body-storage boundary. Browser-local state should be limited to non-sensitive presentation/session hints unless a separate privacy decision permits more.
