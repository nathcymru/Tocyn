# Package Manifest and Application Boundary

## Package identity

`tocyn-post-beta-ux-update-2026-09-10`

## Intent

Proposal package to be combined with other change packages before any repository/project updates are applied.

## Source boundary

Reviewed connected/public `nathcymru/Tocyn` state and current external UX/accessibility references. No production Cloudflare environment or tenant/customer data was accessed.

## Repository mutation

**None.**

Producing this package did not:

- edit a repository file;
- create/update/close a GitHub issue;
- change a milestone;
- change GitHub Project fields;
- create branch/commit/PR;
- publish Wiki pages;
- create tag/release;
- deploy Cloudflare resources;
- send external mail.

## Proposed additions

- 1 milestone: `M2.0: Fullstack - Operator Workspace Foundations`
- 14 new issues with temporary NEW-UX IDs
- 4 proposed ADRs, 0016–0019 subject to collision check
- 2 new Wiki pages plus multiple Wiki/doc updates
- Operator Workspace UX Gate A
- post-beta roadmap intervention/reforecast

## Proposed modifications

- rename M2.1;
- rescope/resequence #48 and associated M2 work;
- expand #66/#68/#69/#70/#71/#73/#74/#75/#76/#77/#85 integration acceptance;
- add workspace integration to omnichannel tracker/provider issues;
- clarify #42 UX vs production-readiness gate;
- supersede, not delete, historical layout-plan authority.

## Proposed retirements after accepted replacement

No historical project artefact is deleted merely because beta invalidated a design premise.

After successor implementation/parity only:

- retire monolithic legacy ticket-detail composition;
- demote/refactor legacy ticket table into optional Table mode;
- remove healthy-state realtime/operator pulse presentation;
- remove routine transient-only ticket toast workflow;
- consolidate duplicated presence;
- move per-message knowledge QA hover controls out of normal reading;
- remove separate AI Auto-Draft panel after inline parity;
- remove legacy `Luminatick` user-facing copy.

## Consolidation checklist

- [ ] Refresh current `main`.
- [ ] Refresh issue states/milestones/Project fields.
- [ ] Check ADR-number collisions.
- [ ] Replace NEW-UX IDs with real issue numbers.
- [ ] Decide prerelease ordinal from actual tags/releases then present.
- [ ] Preserve ADR-0014 baseline fields.
- [ ] Reforecast dependencies/forecast dates.
- [ ] Confirm other packages do not duplicate new issues.
- [ ] Preserve closed first-beta issues.
- [ ] Review security/privacy effects of draft/notification/context state.
- [ ] Apply docs/Wiki only after architecture acceptance.
- [ ] Use normal review/CI/governance for implementation.
