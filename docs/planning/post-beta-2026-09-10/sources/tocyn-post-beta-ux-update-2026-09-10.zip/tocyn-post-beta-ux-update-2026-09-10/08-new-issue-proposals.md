# New Issue Proposals

Temporary identifiers `NEW-UX-01` etc. are package coordination IDs only. Do not use them as GitHub issue numbers. When the consolidated package creates issues, replace cross-references with assigned GitHub numbers.

Titles follow the repository's verb-led naming style. Effort uses the mandatory 3x planning convention. Exact baseline/forecast dates require owner approval and a Project reforecast after issue creation.


---

## NEW-UX-01 — Define the post-beta operator workspace interaction contract

**Proposed milestone:** `M2.0: Fullstack - Operator Workspace Foundations`  
**Baseline effort:** 12 hours  
**Mandatory 3x planning effort:** 36 hours

### Approved implementation scope

- Define persistent workspace IA: global navigation, work views, conversation list, active conversation, action bar, composer and contextual panel.
- Define desktop/medium/mobile composition and deep-link/back semantics.
- Classify current beta UI as retain/migrate, replace, compatibility-only/retire or move-to-context.
- Define universal search vs current-view filtering scope and terminology.
- Define visual salience/progressive-disclosure rules.
- Produce inspectable interaction contracts sufficient for #48 and NEW-UX-02 without choosing decorative styling.

### Scope boundary

- Do not implement application code, migrate primitives, change canonical tenant authority or create a new ticket data model.
- Do not clone a competitor UI.

### Acceptance and demonstration

- [ ] Maps every Critical LAW/COMP/COG finding to a named surface/state.
- [ ] Ticket switching never requires conceptual loss of current work view.
- [ ] Table mode is explicitly secondary.
- [ ] Healthy infrastructure state is absent from primary operator attention.
- [ ] ADR-0016/0018 decisions are reviewable.
- [ ] Responsive and keyboard focus destinations are specified.

### Dependencies / coordination

- accepted local beta evidence
- #62 as satisfied historical functional evidence

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-02 — Build the persistent progressive operator workspace

**Proposed milestone:** `M2.1: Frontend - Operator Workspace & Navigation`  
**Baseline effort:** 32 hours  
**Mandatory 3x planning effort:** 96 hours

### Approved implementation scope

- Implement persistent workspace shell and nested route/state model.
- Keep work views/conversation list mounted while active ticket changes on desktop.
- Implement ConversationHeader, TicketActionBar, ConversationTimeline and ContextPanel composition.
- Preserve public/internal, attachment, assignment, status and recovery correctness.
- Provide compatibility behaviour for `/tickets` and `/tickets/:id` links.
- Replace normal Back-to-Tickets triage with selection/advance within workspace.
- Remove duplicate presence and healthy real-time diagnostics from primary surface.
- Replace current dashboard legacy branding and route operator-home actions into work views.

### Scope boundary

- Does not own rich-composer breadth (#68), macros (#69), provider adapters, AI models or SLA engine.
- Must not weaken #60/#63 correctness.

### Acceptance and demonstration

- [ ] Switch 20 fixture tickets without losing selected view/list position.
- [ ] Resolve/snooze reclassifies current item and optional advance selects deterministic next work.
- [ ] Mobile return restores exact view/list position/draft.
- [ ] Failed reads/writes preserve confirmed state and recovery semantics.
- [ ] No `Luminatick` user-facing branding remains in affected workspace.
- [ ] Manual keyboard/screen-reader checks pass new composition.

### Dependencies / coordination

- NEW-UX-01
- #48 operator primitives
- #66
- NEW-UX-03
- NEW-UX-04

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-03 — Persist operator drafts, selection and workspace continuity

**Proposed milestone:** `M2.0: Fullstack - Operator Workspace Foundations`  
**Baseline effort:** 20 hours  
**Mandatory 3x planning effort:** 60 hours

### Approved implementation scope

- Add server-backed tenant/user-scoped draft persistence using existing scoped body-storage principles.
- Persist active work view, sort/filter preference, selected ticket and panel preference without sensitive conversation text in long-lived browser storage by default.
- Add Draft indicator and Drafts-view query input.
- Preserve base conversation revision for collision-aware send.
- Define discard, confirmed-send cleanup and retention.
- Restore state only when current session retains authority.

### Scope boundary

- Does not add AI or rich-editor formatting.
- Does not make browser persistence a data-authority boundary.

### Acceptance and demonstration

- [ ] Draft/mode/attachments restore after ticket switch and reload.
- [ ] Failed autosave is visible and never reports Saved falsely.
- [ ] Confirmed send removes only matching draft revision.
- [ ] Tenant/user B cannot observe A draft or view state.
- [ ] Authority/session change clears inappropriate previous state.
- [ ] Retention/cleanup deterministic and tested.

### Dependencies / coordination

- #60
- #63
- existing scoped R2/body storage
- NEW-UX-01

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-04 — Add task-based work queues and snooze/resurface

**Proposed milestone:** `M2.0: Fullstack - Operator Workspace Foundations`  
**Baseline effort:** 24 hours  
**Mandatory 3x planning effort:** 72 hours

### Approved implementation scope

- Create authoritative predicates/APIs for Mine, Unassigned, Mentions, Drafts, Snoozed, Needs Action and All.
- Add audited snooze/next-action state with authoritative timestamps.
- Define new-customer-activity and due-time resurface policy.
- Provide bounded aggregate counts and measured D1 query cost.
- Integrate existing saved filters as custom views rather than deleting them.
- Expose reason-for-inclusion metadata where it helps comprehension.

### Scope boundary

- Does not implement team-capacity routing (NEW-UX-11).
- Does not replace canonical tenant authority.

### Acceptance and demonstration

- [ ] Snoozed work leaves normal actionable view and appears in Snoozed.
- [ ] Controlled time advance/customer reply resurfaces per policy.
- [ ] Counts reconcile with fixture tickets.
- [ ] No cross-tenant count leak.
- [ ] Saved custom filters continue to work.
- [ ] Queue-clear state is truthful and not gamified.

### Dependencies / coordination

- #63
- NEW-UX-03
- NEW-UX-10

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-05 — Unify global search and scoped inbox filtering

**Proposed milestone:** `M2.1: Frontend - Operator Workspace & Navigation`  
**Baseline effort:** 12 hours  
**Mandatory 3x planning effort:** 36 hours

### Approved implementation scope

- Replace duplicate generic ticket search with distinct universal search/command and `Filter this view` controls.
- Define bounded search contracts for authorised tickets, customers and knowledge where available.
- Keep work-view predicates active while filtering current list.
- Integrate command-navigation search with #71.
- Preserve safe URL/deep-link semantics for non-sensitive query state.

### Scope boundary

- Does not mandate an external search engine.
- Does not broaden data access.

### Acceptance and demonstration

- [ ] Visible labels make global vs current-view scope unambiguous.
- [ ] Keyboard/screen reader can reach, clear and switch result types.
- [ ] Search never returns another tenant/unauthorised ticket.
- [ ] Clearing filter restores same work view predictably.

### Dependencies / coordination

- NEW-UX-02
- #71
- existing ticket/knowledge APIs

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-06 — Add cognitive-accessibility workspace preferences and focus mode

**Proposed milestone:** `M2.1: Frontend - Operator Workspace & Navigation`  
**Baseline effort:** 16 hours  
**Mandatory 3x planning effort:** 48 hours

### Approved implementation scope

- Add user-scoped preferences for labelled/compact navigation, density, font scale, context-panel default, focus mode, motion, interruption level, shortcuts and optional advance-after-resolve.
- Respect system reduced-motion absent explicit user preference.
- Implement Focus mode suppressing noncritical chrome without hiding delivery/state/error/public-vs-internal information.
- Ensure tenant theme cannot override required accessibility protections.
- Validate preference values/versioning and safe fallback.

### Scope boundary

- Preferences do not grant authority or alter tenant policy.
- Do not create diagnostic/medical profiles; store interface preferences, not health labels.

### Acceptance and demonstration

- [ ] Preferences survive reload and remain user/tenant scoped.
- [ ] Reduced-motion removes nonessential pulse/slide/scale.
- [ ] Focus mode preserves every critical workflow state.
- [ ] 200% zoom/reflow and browser text scaling remain usable.
- [ ] Corrupt/old preference schema falls back safely.

### Dependencies / coordination

- #66
- ADR-0018
- NEW-UX-02

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-07 — Replace transient ticket toasts with durable operator activity

**Proposed milestone:** `M2.3: Fullstack - Real-Time State & Presence`  
**Baseline effort:** 16 hours  
**Mandatory 3x planning effort:** 48 hours

### Approved implementation scope

- Create durable operator activity/notification projection for direct assignment, mention, relevant customer reply, SLA risk, resurfaced work and intervention-required delivery state.
- Use WebSocket as invalidation/signal, not notification source of truth.
- Routine ticket updates update views/counts without interrupting active composer.
- Add read/dismiss state and configurable interruption classes.
- Move latency/reconnect diagnostics out of healthy operator chrome; show degraded-state notice only when relevant.

### Scope boundary

- Does not replace audit events.
- Does not promise out-of-band delivery without separate configured provider.

### Acceptance and demonstration

- [ ] No actionable event exists only in an expiring toast.
- [ ] Reload preserves unread relevant activity.
- [ ] Routine unrelated traffic does not steal focus by default.
- [ ] Disconnected/degraded state is clear/recoverable without permanent healthy badge.
- [ ] User interruption preferences are respected.

### Dependencies / coordination

- #63
- #70
- #66
- NEW-UX-06

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-08 — Add customer context and contextual support panels

**Proposed milestone:** `M2.1: Frontend - Operator Workspace & Navigation`  
**Baseline effort:** 20 hours  
**Mandatory 3x planning effort:** 60 hours

### Approved implementation scope

- Implement collapsible Customer, Ticket, Knowledge, Collaboration and Operational context sections.
- Use verified tenant-scoped customer/identity keys for history; do not merge identities by display text.
- Move custom fields and detailed audit/history into contextual presentation while retaining keyboard access.
- Move knowledge QA/indexing actions out of normal message hover flow.
- Provide KB search/preview/insert hook for #68.
- Provide typed context slots for #75 operational context with provenance/freshness.
- Persist panel preference via NEW-UX-06.

### Scope boundary

- Does not implement unverified cross-channel identity merging.
- Does not implement #75 connectors themselves.

### Acceptance and demonstration

- [ ] Conversation readable with context closed.
- [ ] Context opens without losing composer/list state.
- [ ] Customer history tenant/identity scoped.
- [ ] Knowledge insertion keyboard accessible.
- [ ] Absent operational sources produce calm unavailable/empty state.

### Dependencies / coordination

- NEW-UX-02
- #74
- #75
- #63

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-09 — Add configurable Table view and safe bulk ticket actions

**Proposed milestone:** `M2.1: Frontend - Operator Workspace & Navigation`  
**Baseline effort:** 16 hours  
**Mandatory 3x planning effort:** 48 hours

### Approved implementation scope

- Retain secondary Table mode with user-selectable columns/order/density.
- Provide right-side ticket preview without leaving selected work context.
- Add bounded multi-select and bulk assignment/state/snooze/tag operations.
- Use server permission checking, mutation receipts/idempotency and explicit partial-failure results.
- Protect destructive/broad operations with confirmation/preview.

### Scope boundary

- Table mode is not default operator mental model.
- No bulk public reply without separately accepted design.

### Acceptance and demonstration

- [ ] Column preferences persist per user.
- [ ] Selection cannot silently target items no longer in scope.
- [ ] Mixed authorised/unauthorised batch returns safe result without cross-tenant leak.
- [ ] Retry does not duplicate intended mutations.
- [ ] Keyboard/screen-reader selection/actions pass.

### Dependencies / coordination

- NEW-UX-02
- #60
- #64
- #79 when capability model lands

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-10 — Add explicit waiting reasons and configurable support workflow states

**Proposed milestone:** `M2.0: Fullstack - Operator Workspace Foundations`  
**Baseline effort:** 24 hours  
**Mandatory 3x planning effort:** 72 hours

### Approved implementation scope

- Add additive tenant-defined support-state definitions mapped to stable lifecycle categories.
- Seed compatibility states matching current open/pending/resolved/closed behaviour.
- Add waiting reason and optional next-action semantics.
- Expose customer-visible label separately from internal label.
- Define SLA pause/resume input for #73.
- Audit definition/state changes and handle deactivation safely.

### Scope boundary

- Do not break current API clients.
- State labels do not grant permissions.

### Acceptance and demonstration

- [ ] Legacy status clients continue to function.
- [ ] Default `Pending` can be represented with explicit human waiting reason.
- [ ] State deactivation cannot strand active tickets.
- [ ] SLA engine can consume deterministic lifecycle/waiting semantics.
- [ ] Cross-tenant state definitions cannot be applied.

### Dependencies / coordination

- #60
- #63
- NEW-UX-01

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-11 — Add workload-aware queues and operator capacity controls

**Proposed milestone:** `M6.2: Frontend - Service Status & SLA`  
**Baseline effort:** 24 hours  
**Mandatory 3x planning effort:** 72 hours

### Approved implementation scope

- Add authoritative team/operator availability and active-work counts needed for balanced/manual routing.
- Allow configured assignment ceilings/availability without client state as authority.
- Show operator-relevant capacity calmly; supervisor detail through authorised analytics.
- Integrate with queue sorting/routing and #73 SLA priorities.
- Define fairness/fallback when all operators are at capacity.

### Scope boundary

- Do not introduce employee productivity scoring/surveillance by default.
- Does not replace permissions or assignment authority.

### Acceptance and demonstration

- [ ] Concurrent assignment respects declared hard rules.
- [ ] Manual override behaviour explicit/audited.
- [ ] Unavailable operators not auto-assigned.
- [ ] Metrics distinguish current work from historical performance.
- [ ] Tenant boundaries hold.

### Dependencies / coordination

- #73
- #79
- #85
- NEW-UX-04

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-12 — Define workspace utility actions for call, remote support and external tools

**Proposed milestone:** `M2.1: Frontend - Operator Workspace & Navigation`  
**Baseline effort:** 12 hours  
**Mandatory 3x planning effort:** 36 hours

### Approved implementation scope

- Define typed core-owned utility-action registry for current ticket context.
- Provide bounded UI slot in TicketActionBar/More.
- Support permission/availability checks and internal-dialog/application-command/validated-link action classes.
- Document security boundary for future voice, remote support, RMM, CRM and status tools.
- Ensure extensions cannot inject arbitrary tenant JavaScript or bypass governed actions.

### Scope boundary

- Does not implement a specific voice/remote vendor.
- Does not grant backend mutation authority.

### Acceptance and demonstration

- [ ] Reference utility enables/disables without layout redesign.
- [ ] Unavailable action absent/disabled with reason according to design.
- [ ] Permission denial server authoritative.
- [ ] Unsafe external schemes/origins rejected.
- [ ] Keyboard/screen-reader action access passes.

### Dependencies / coordination

- NEW-UX-01
- #79 for granular permissions where applicable

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-13 — Measure operator interaction performance and enforce UI response budgets

**Proposed milestone:** `M2.1: Frontend - Operator Workspace & Navigation`  
**Baseline effort:** 8 hours  
**Mandatory 3x planning effort:** 24 hours

### Approved implementation scope

- Measure input acknowledgement, cached ticket switching, initial useful conversation render, command palette, queue update after mutation and degraded-network feedback.
- Record warm/cold/cache conditions and representative ticket/thread sizes.
- Set numeric regression budgets from measured baseline and target experience.
- Add stable CI/browser performance checks where appropriate; preserve separate internet/server latency evidence.

### Scope boundary

- Do not advertise the Laws of UX 400ms heuristic as a universal network SLA.
- Do not hide failed/uncertain writes to improve apparent speed.

### Acceptance and demonstration

- [ ] Reproducible commands/fixtures recorded.
- [ ] p50/p95 or equivalent distributions recorded.
- [ ] Budgets visibly fail on material regression.
- [ ] Representative/low-power hardware considered, not only developer workstation.
- [ ] Pending state shown immediately for network writes.

### Dependencies / coordination

- #48
- NEW-UX-02

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.


---

## NEW-UX-14 — Validate the redesigned operator workspace for usability and cognitive accessibility

**Proposed milestone:** `M2.1: Frontend - Operator Workspace & Navigation`  
**Baseline effort:** 16 hours  
**Mandatory 3x planning effort:** 48 hours

### Approved implementation scope

- Run final task-based review across Critical LAW/COMP/COG findings.
- Run automated accessibility plus manual keyboard/screen-reader journeys.
- Test interruption/resume, reduced motion, focus mode, zoom, stale reads, failed drafts, collision, resolve/snooze/advance and queue-clear.
- Record real defects as issues; do not close by checklist alone.
- Use synthetic tenant data and local/isolated boundaries.

### Scope boundary

- Does not replace #42 production readiness.
- Does not claim one neurodivergent participant/profile represents all users.

### Acceptance and demonstration

- [ ] Every Critical traceability row has evidence or explicitly approved residual limitation.
- [ ] VoiceOver/Safari and at least one second screen-reader/browser combination exercised where available.
- [ ] Core workflow succeeds with AI disabled.
- [ ] No actionable state transient-only.
- [ ] No critical action hover-only.
- [ ] Draft/resume and queue continuity demonstrated.
- [ ] Gate A decision/residual risk documented.

### Dependencies / coordination

- all Gate A items
- ADR-0016/17/18/19

### Baseline and execution boundary

This proposal is post-beta planning, not implementation or deployment authority. Preserve current tenant, session, retry, audit, privacy and resource boundaries. Deliver through issue-owned reviewed PRs with positive, negative, failure and tenant-isolation evidence. Record resource consumption and recovery behaviour. Use ADR-0014 baseline/forecast/actual conventions.
