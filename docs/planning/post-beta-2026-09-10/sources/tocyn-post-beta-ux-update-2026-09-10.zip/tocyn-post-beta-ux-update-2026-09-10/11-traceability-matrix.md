# Master Traceability Matrix

This file is intentionally repetitive. Its purpose is to prevent broad phrases such as “workspace redesign” from hiding unresolved negative findings.

| Finding | Severity | Owner / linked work | Detailed register | Gate/disposition |
| --- | --- | --- | --- | --- |
| LAW-01 | Medium | #48, #66, NEW-UX-02, NEW-UX-14 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-02 | High | NEW-UX-01, NEW-UX-02, NEW-UX-08, #68, #77 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-03 | High | NEW-UX-01, NEW-UX-02, NEW-UX-08 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-04 | Critical | NEW-UX-02–08, #71 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-05 | Unverified / must measure | NEW-UX-13, #48 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-06 | High | #48, #66, NEW-UX-06, NEW-UX-14 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-07 | Critical | ADR-0016, NEW-UX-02, NEW-UX-03, #71 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-08 | Medium | NEW-UX-04, NEW-UX-02, NEW-UX-11 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-09 | High | NEW-UX-01, NEW-UX-02, #69, #71 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-10 | Critical | ADR-0016, NEW-UX-02, NEW-UX-09 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-11 | Medium | NEW-UX-02, NEW-UX-08, #70, #73 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-12 | High | NEW-UX-02, NEW-UX-04, #76 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-13 | Medium | #48, #66 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-14 | Critical | ADR-0016, NEW-UX-01, NEW-UX-02 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-15 | Critical | ADR-0017, NEW-UX-03, #71 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-16 | High | NEW-UX-05, NEW-UX-07, NEW-UX-02 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-17 | High | NEW-UX-01, NEW-UX-02, #69, #71 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-18 | Medium | NEW-UX-02, NEW-UX-04 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-19 | Critical | ADR-0018, NEW-UX-06, NEW-UX-07, #66 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-20 | High | #66, NEW-UX-01, NEW-UX-14 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-21 | High | NEW-UX-04, NEW-UX-10, #69, #73, #76 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| LAW-22 | High | ADR-0017, NEW-UX-03, NEW-UX-04, #68 | 02-ux-law-gap-register.md | UX-A0/A1 according to severity |
| COMP-01 | Critical | NEW-UX-02; #48/#66 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-02 | Critical | NEW-UX-03; #71 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-03 | High | NEW-UX-04; #70/#73 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-04 | High | NEW-UX-09; #66 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-05 | Critical for B2B | #73; NEW-UX-10 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-06 | Critical | NEW-UX-04; #63 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-07 | High | #68 + NEW-UX-03; ADR-0017 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-08 | High | #69; #68 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-09 | High | #69; #79 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-10 | High | #71; NEW-UX-02 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-11 | High | #71; NEW-UX-14 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-12 | High | #70; #63 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-13 | Critical | NEW-UX-08; #74/#75 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-14 | Critical long-term | #49/#53–#56/#89; ADR-0016 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-15 | High | #68; #53–#56/#89 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-16 | High | #68 / NEW-UX-08; #77 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-17 | High | #76; ADR-0019 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-18 | Medium-High | #77; ADR-0019 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-19 | High | #77; #75/#76 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-20 | High | NEW-UX-09; #60/#64/#79 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-21 | Medium-High | NEW-UX-11; #73/#85 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-22 | Medium-High | NEW-UX-10; #73 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-23 | Medium / market dependent | NEW-UX-08; #75 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-24 | High if technical-support market | NEW-UX-12; #79 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-25 | High | #85 / NEW-UX-02; #73 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COMP-26 | Medium-High | NEW-UX-08; #79 | 03-competitive-gap-register.md | A1 if Critical; otherwise owned successor |
| COG-01 | Critical | ADR-0016 / NEW-UX-02 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-02 | Critical | NEW-UX-03 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-03 | Critical | NEW-UX-02 / NEW-UX-04 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-04 | Critical | NEW-UX-02 / NEW-UX-08 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-05 | Critical | ADR-0018 / NEW-UX-07 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-06 | High | #66 / NEW-UX-06 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-07 | High | NEW-UX-06 / #71 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-08 | High | NEW-UX-10 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-09 | Critical | NEW-UX-01 / #48 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-10 | Critical | NEW-UX-02 / NEW-UX-06 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-11 | Critical | ADR-0017 / NEW-UX-03/04 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-12 | Critical | NEW-UX-04 / #73 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-13 | High | ADR-0016 / NEW-UX-02 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-14 | High | ADR-0018 / NEW-UX-06 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-15 | High | NEW-UX-06 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-16 | High | NEW-UX-05 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-17 | High | #48 / NEW-UX-14 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-18 | High | #71 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-19 | High | NEW-UX-07 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-20 | High | #68 / NEW-UX-03 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-21 | Critical | #66 / ADR-0018 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-22 | Strength to preserve | NEW-UX-14 / #60 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-23 | Medium-High | #66 / NEW-UX-06 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |
| COG-24 | High | NEW-UX-03 / NEW-UX-04 | 04-cognitive-accessibility-gap-register.md | A1 for Critical/High core interaction; otherwise explicit successor |

## Closure rule

A finding can be marked **Addressed** only when:

1. the owning issue/ADR is accepted;
2. the final relevant UI exists;
3. the relevant task/negative test has evidence;
4. no listed successor dependency is still required for the claim being made.

A finding may be marked **Deferred with owner** when:

- it is not required for Gate A;
- its issue/milestone/dependency is explicit;
- current UI does not falsely claim the capability.

It must not disappear from the roadmap merely because another broad issue sounds related.
