# ADR-0017 — Durable operator attention state is distinct from canonical conversation state

- **Status:** Proposed
- **Date:** 10 September 2026
- **Decision owners:** Proposed by post-beta UX review; requires project acceptance

## Context

Canonical ticket/conversation state answers what has happened in the support interaction. Operators additionally need to know what work is unfinished, deferred, drafted, mentioned, due or ready to resume.

The beta retains drafts after some failures, but changing ticket resets local composer state. There is no first-class Snoozed, Drafts or Needs Action model. That pushes follow-up and interruption recovery into human memory.

Storing sensitive draft text in arbitrary browser persistence would solve one UX defect by creating a privacy/data-lifecycle problem.

## Decision

Tocyn will represent operator work-in-progress and attention explicitly, without treating it as tenant authority.

At minimum the architecture supports:

- per-user/per-ticket durable draft state;
- selected work view/workspace presentation state;
- audited ticket-level snooze/next-action state;
- waiting reason;
- derived Drafts/Snoozed/Needs Action work views;
- durable operator notifications/activity;
- revision information sufficient for collision-aware resume/send.

Sensitive draft content uses Tocyn's authenticated tenant-scoped storage/body abstractions. Long-lived browser storage is not the default canonical store for customer-content drafts.

Presentation preferences may be server persisted per tenant/user but cannot grant access or change server permission.

Canonical ticket lifecycle remains the source for ticket state. Attention/work state is additive and must not silently invent a second incompatible ticket system.

## Consequences

- NEW-UX-03/04 require additive data/API work.
- Draft retention and cleanup need documented retention.
- Snooze/resurface needs deterministic scheduler/query behaviour.
- #68 consumes durable drafts.
- #70 consumes base-conversation revision/collision state.
- #73 consumes waiting/next-action semantics.
- #63 audit remains authoritative for attributable ticket mutations.
- Authentication/authority changes must prevent restoration of stale prior-tenant work state.

## Related

- ADR-0012
- ADR-0014
- ADR-0016
- ADR-0018
- #60, #63, #68, #70, #73
- NEW-UX-03, NEW-UX-04, NEW-UX-07, NEW-UX-10
