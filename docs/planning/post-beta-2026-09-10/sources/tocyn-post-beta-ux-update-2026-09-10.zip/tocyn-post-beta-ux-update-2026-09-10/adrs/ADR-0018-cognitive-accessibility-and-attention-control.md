# ADR-0018 — Cognitive accessibility and attention control are product architecture requirements

- **Status:** Proposed
- **Date:** 10 September 2026
- **Decision owners:** Proposed by post-beta UX review; requires project acceptance

## Context

The first beta has strong conventional accessibility foundations, including keyboard/focus/error semantics and actual screen-reader evidence. Post-beta use nevertheless shows substantial cognitive barriers: context loss, information overload, icon-only navigation, transient interruptions, motion, duplicate controls and weak resumability.

WCAG conformance is necessary but does not by itself guarantee a low-cognitive-load operator workflow. W3C cognitive accessibility guidance explicitly addresses attention, memory, comprehension and personalisation, including users with ADHD and autism.

## Decision

Tocyn adopts cognitive accessibility as a product-level design constraint alongside WCAG.

Defaults:

- healthy infrastructure is visually quiet;
- current conversation and next action dominate;
- no actionable information is available only transiently;
- state survives interruption;
- recognition is preferred to recall;
- secondary information uses progressive disclosure;
- critical actions are never hover-only;
- target sizing meets WCAG 2.2 minimums and frequent primary controls target larger comfortable hit areas;
- nonessential motion responds to `prefers-reduced-motion` and explicit user preference;
- routine interruptions are user controllable;
- labelled navigation is available and persistent;
- focus/density/font/context preferences are supported without storing diagnostic labels about the user;
- colour is not the sole state signal;
- tenant themes cannot defeat essential focus/contrast/target protections;
- keyboard shortcuts are optional accelerators, never exclusive access paths.

## Consequences

- #66 token contract expands for motion, density, typography and salience.
- NEW-UX-06 owns user workspace preferences/focus mode.
- NEW-UX-07 owns durable attention/notifications.
- NEW-UX-14 adds cognitive/usability acceptance rather than relying on automated accessibility scanning.
- Dense competitor UI patterns are not automatically acceptable merely because they are familiar.
- Product documentation distinguishes WCAG accessibility evidence from cognitive-usability evidence.

## Related

- W3C Cognitive Accessibility: https://www.w3.org/WAI/cognitive/
- WCAG 2.2: https://www.w3.org/TR/WCAG22/
- ADR-0016
- ADR-0017
- #21 historical first-beta accessibility evidence
- #66, #71
- NEW-UX-06, NEW-UX-07, NEW-UX-14
