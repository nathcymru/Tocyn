# Validation and Release Gates

## 1. Gate structure

### Gate UX-A0 — Architecture acceptance

Before mass UI migration:

- ADR-0016/0017/0018 reviewed;
- every critical beta finding has an owner;
- current beta components classified retain/replace/retire;
- route/work-state/draft/search/attention semantics defined;
- no duplicated issue ownership.

### Gate UX-A1 — Operator workspace acceptance

Required before next operator-facing prerelease.

Must pass the critical items in `06-project-plan-change-set.md`.

### Gate UX-A2 — Competitive productivity acceptance

May follow A1:

- full #68 rich composer;
- #69 saved replies/macros;
- #70 collaboration;
- advanced Table/bulk;
- SLA if promised;
- workload routing;
- inline KB/AI breadth.

### #42 remains separate

Production/cutover/security readiness remains #42. Neither gate substitutes for the other.

## 2. Canonical task journeys

Each final workspace candidate must exercise at least:

1. Login/MFA -> Mine -> first conversation -> reply -> resolve -> advance.
2. Unassigned -> assign to self -> internal note -> public reply.
3. Type draft -> switch ticket -> reload -> return -> draft/mode/attachments intact.
4. Snooze -> removed from actionable queue -> controlled clock advances -> resurfaces in Needs Action.
5. Customer sends new message while draft open -> collision/review -> no duplicate reply.
6. Direct mention -> durable Activity -> read/dismiss -> reload.
7. Lose real-time connection -> persistent degraded notice -> restore -> no false lost state.
8. Failed list refresh -> confirmed list remains with retry.
9. Failed reply/uncertain delivery -> draft preserved and no automatic duplicate.
10. Universal search ticket/customer/knowledge -> open -> predictable return.
11. `Filter this view` -> clear -> original work view remains.
12. Table mode -> bounded selection -> bulk assignment with mixed outcomes.
13. Reduced motion -> same tasks without pulse/slide/scale.
14. Focus mode -> same work with critical status/errors visible.
15. 200% zoom/reflow.
16. Keyboard-only next/previous/assign/snooze/reply/note/resolve.
17. Screen reader: work-view/list/conversation/context landmarks and state announcements.
18. AI disabled -> all human work complete.
19. AI enabled -> improve/draft/translate -> same composer -> explicit send.
20. Two tenants/users -> no state/draft/search/count/context crossover.

## 3. Cognitive usability acceptance

Do not reduce to “passes axe”.

Collect evidence for:

- steps/time to identify next required task;
- number of context switches/routes;
- resumption after deliberate interruption;
- distinction between universal search and view filter;
- Public Reply/Internal Note comprehension;
- discovery of Draft/Snoozed/Needs Action without hidden-memory reliance;
- healthy system state remaining quiet;
- finding context without permanently occupying attention;
- perceived workload/clarity.

Use representative participants where practical. Never claim a single autistic/ADHD participant proves universal neurodivergent usability.

## 4. Conventional accessibility

For redesigned/new surfaces:

- automated semantic/contrast tests;
- manual keyboard;
- focus order/restoration;
- 200% text zoom/reflow;
- target-size inspection;
- `prefers-reduced-motion`;
- VoiceOver/Safari;
- a second browser/screen-reader combination where available, e.g. NVDA + Firefox/Chrome;
- high contrast/forced-colours where supported;
- no colour-only status;
- dynamic announcements useful rather than noisy.

#21 remains closed because this is successor UI acceptance.

## 5. Performance

NEW-UX-13 records measured budgets for:

- command palette open;
- list selection;
- cached conversation switch;
- first useful conversation render;
- filter input;
- context open;
- pending feedback on mutations;
- queue update after confirmed resolve/snooze;
- draft autosave acknowledgement;
- Activity unread count.

Test long threads and large authorised queues, not only tiny fixtures.

## 6. Failure/recovery

Required negative tests:

- draft save failure;
- ticket becomes unauthorised while selected;
- ticket leaves current view after external change;
- stale saved view/filter;
- snooze scheduler delay;
- notification projection delay;
- duplicate WebSocket events;
- two-operator collision;
- attachment upload succeeds but reply fails;
- bulk partial failure;
- AI unavailable/timeout;
- channel reply unavailable mid-draft;
- context connector unavailable/stale;
- preference schema invalid;
- browser storage cleared.

## 7. Security/privacy non-regression

- new D1 tables tenant-qualified;
- user-specific state includes user ID;
- URL never carries customer-content drafts/secrets;
- search authorised;
- context identity verified, not string-matched authority;
- utility actions cannot inject arbitrary JS;
- draft retention/cleanup documented;
- notifications reveal only authorised metadata;
- bulk actions recheck each target;
- theme/preferences never become authority.

## 8. Release decision record

At Gate A completion, record:

- tested commit SHA;
- issue/PR receipts;
- residual gaps;
- law/competitor/cognitive traceability status;
- performance measurements;
- accessibility evidence;
- tenant/security regression evidence;
- chosen prerelease tag name, if any;
- explicit local-only/remote/public scope;
- #42 status separately.

Do not infer deployment/public authority from UX acceptance.
