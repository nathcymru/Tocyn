# Repository Baseline Used for This Package

**Verified:** 10 September 2026  
**Repository:** `nathcymru/Tocyn`  
**Default branch reviewed:** `main`  
**Head SHA:** `93de1b975a45edd9d28ca70edd725b60deb6b275`  
**Head commit message:** `docs: record verified local private-beta readiness (#125)`

## Current roadmap authority observed

`docs/roadmap.md` and Wiki-sync documentation define:

- M0 Engineering/platform cost/delivery;
- M1 core data/intake/mail;
- M2 human workspace/productivity/realtime state/design;
- M3 context/triage/operator AI;
- M4 policy-gated execution/autonomy/handoff;
- M5 authorisation/audit/analytics/privacy/workflow administration;
- M6 service-user/portal/SLA/continuity/self-service;
- M7 WhatsApp/Telegram/Slack/Teams/support-email.

Current first private beta candidate: `v0.4.0-beta.1`, forecast 21 November 2026.

Preserved original scoped roadmap completion forecast: 16 July 2027.

## Release state

GitHub Releases API returned an empty list at package preparation time. There is no release history to modify.

## Existing issue evidence relied on

- #48 — Establish shared headless primitives for standalone Tocyn
- #49 — Track delivery of the omnichannel architecture
- #50 — Define enforceable cost policies and resource budgets
- #68 — Add a rich conversation composer
- #70 — Add typing awareness and private colleague collaboration
- #72 — Split and merge tickets without losing context
- #73 — Expose SLA progress and responsible handlers
- #74 — Preserve conversations across verified channel changes
- #75 — Enrich intake with authorised operational context
- #76 — Add bounded triage and conversation summarisation
- #77 — Expand the operator copilot with translation and runbooks
- #78 — Author and publish governed diagnostic workflows visually
- #79 — Enforce granular human and agent capabilities
- #80 — Validate governed actions against an isolated reference API
- #84 — Review agent interactions through auditable QA workflows
- #85 — Report operational performance and quality metrics
- #86 — Expose authorised deterministic self-service actions
- #87 — Normalise provider events into reliable conversation state
- #88 — Dispatch transactional outbound intents reliably
- #90 — Expose owner and tenant Cost & Capacity controls
- #96 — Complete repository, architecture and privacy documentation (closed)

## ADR state observed

Repository-backed ADRs present:

- ADR-0012 Canonical conversations and channel adapters
- ADR-0013 Email capability boundaries
- ADR-0014 Living delivery state
- ADR-0015 Privacy metadata boundary

ADR-0010/0011 are preserved on the Wiki. The next free repository-backed ordinal at this snapshot is ADR-0016.

## Documentation hazards observed

Several older files remain historical Luminatick/Phase-1 plans and contain single-tenant or current-sounding statements. The change package does not delete them; it proposes explicit historical/superseded notices.

## Limitation

The GitHub connector used for preparation exposed issues, files, commits and Releases but not the live custom fields of GitHub Project 4. Therefore this package does **not** claim current Project field values. The final applying conversation must read Project 4 before populating or reforecasting it.
