# External Technical References

Verified during planning on 10 September 2026. Recheck at implementation because platform APIs/pricing can change.

## Cloudflare Realtime

- Overview: https://developers.cloudflare.com/realtime/
- Realtime SFU overview: https://developers.cloudflare.com/realtime/sfu/
- Realtime SFU introduction: https://developers.cloudflare.com/realtime/sfu/introduction/
- Connection API: https://developers.cloudflare.com/realtime/sfu/https-api/
- Media Transport Adapters: https://developers.cloudflare.com/realtime/sfu/media-transport-adapters/
- WebSocket media adapter: https://developers.cloudflare.com/realtime/sfu/media-transport-adapters/websocket-adapter/
- RealtimeKit: https://developers.cloudflare.com/realtime/realtimekit/
- RealtimeKit audio-only calls: https://developers.cloudflare.com/realtime/realtimekit/audio-calls/
- Recording: https://developers.cloudflare.com/realtime/realtimekit/recording-guide/
- Track recording: https://developers.cloudflare.com/realtime/realtimekit/recording-guide/track-recording/
- R2/cloud recording export: https://developers.cloudflare.com/realtime/realtimekit/recording-guide/custom-cloud-storage/
- Transcription: https://developers.cloudflare.com/realtime/realtimekit/ai/transcription/
- Realtime SFU pricing: https://developers.cloudflare.com/realtime/sfu/pricing/
- RealtimeKit pricing: https://developers.cloudflare.com/realtime/realtimekit/pricing/

Planning conclusions drawn from the current docs:

- Realtime SFU is intended for custom audio/video/data applications where the app owns signalling, participants, permissions and UI.
- RealtimeKit provides higher-level voice/video plus recording/transcription capabilities.
- Realtime media adapters can bridge WebRTC to external endpoints; PSTN/carrier termination still needs an explicit provider/gateway design.
- Realtime/recording/transcription are metered resources and must integrate with Tocyn CostPolicy.

## Cloudflare Access / Zero Trust

- Workers + Cloudflare Access: https://developers.cloudflare.com/workers/configuration/cloudflare-access/
- Validate Access JWTs: https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/validating-json/
- Identity providers: https://developers.cloudflare.com/cloudflare-one/integrations/identity-providers/
- Generic SAML: https://developers.cloudflare.com/cloudflare-one/integrations/identity-providers/generic-saml/
- Generic OIDC: https://developers.cloudflare.com/cloudflare-one/integrations/identity-providers/generic-oidc/
- Google Workspace IdP: https://developers.cloudflare.com/cloudflare-one/integrations/identity-providers/google-workspace/

Planning conclusions:

- Access can protect Workers/apps before requests reach the application.
- Tocyn must still validate the Access JWT at the application boundary.
- Cloudflare can integrate SAML/OIDC/Google and other IdPs, supporting the decision not to duplicate those protocols inside Tocyn.
