# Existing Issue Change Map

## Governing principle

`AGENTS.md` says not to silently broaden an issue because related work looks convenient. This plan therefore creates new issue ownership for new capability. Existing issues are dependencies/foundations unless a narrow cross-reference is required.

## Required existing-issue amendment

### #49 — `Track delivery of the omnichannel architecture`

**Action:** narrow documentation amendment only; do not add M8 issues as blockers to #49 and do not alter its original forecast/baseline.

Add a current-scope note above the preserved historical `<details>` section:

> Native realtime media and PSTN support are now tracked separately by the approved M8 Realtime Support Communications phase and its cross-roadmap gap tracker. They are not prerequisites for closing #49 or its existing M7 provider-adapter checklist. The preserved historical statement that audio/video was outside the earlier specifications remains historical evidence and is not to be rewritten.

**Reason:** #49's preserved historical text explicitly says audio/video remained outside those specifications. The new work must be traceable without falsifying the earlier plan.

## Existing issues to link as dependencies — no scope expansion

| Issue | Existing ownership to preserve | New consumers |
| --- | --- | --- |
| #48 `Establish shared headless primitives for standalone Tocyn` | Shared accessible headless primitives/static CSS | `PG-RT-03`, `PG-AP-01`, `PG-AP-02`, reporting UI |
| #50 `Define enforceable cost policies and resource budgets` | Generic cost contracts | all AI/media/transcription/telephony budget work |
| #68 `Add a rich conversation composer` | Rich composer/slash commands | `PG-AP-01`, `PG-RT-03` |
| #70 `Add typing awareness and private colleague collaboration` | Realtime presence/collaboration | realtime session/operator collaboration and linked work |
| #72 `Split and merge tickets without losing context` | Ticket split/merge/provenance | `PG-TK-01`, `PG-TK-02` |
| #73 `Expose SLA progress and responsible handlers` | SLA/calendar/handler state | phone queue/callback operations, live dashboard |
| #74 `Preserve conversations across verified channel changes` | verified identity continuity | PSTN identity/conversation linkage |
| #75 `Enrich intake with authorised operational context` | governed read connector contract | operator applet data sources |
| #76 `Add bounded triage and conversation summarisation` | bounded AI summaries/classification | tenant-grounded assistant and transcript summarisation |
| #77 `Expand the operator copilot with translation and runbooks` | operator suggestions/citations | `PG-KB-02`; do not rebuild RAG inside #77 |
| #78 `Author and publish governed diagnostic workflows visually` | workflow editor/version/publish/rollback | applet recipe authoring |
| #79 `Enforce granular human and agent capabilities` | resource/tool permissions and owner ceiling | all sensitive new features |
| #80 `Validate governed actions against an isolated reference API` | typed tool runtime gate | applet action buttons/recipes |
| #81 | action-bound approval contract | applet approval UX |
| #84 `Review agent interactions through auditable QA workflows` | agent-session QA | transcript/recording review integration |
| #85 `Report operational performance and quality metrics` | event-derived operational metric foundation | live dashboard and custom reports |
| #87 `Normalise provider events into reliable conversation state` | provider event identity/dedupe/order | telephony event adapter |
| #88 `Dispatch transactional outbound intents reliably` | outbox/delivery/retry | incident mass updates + telephony signalling where transactional messaging applies |
| #90 `Expose owner and tenant Cost & Capacity controls` | cost-control administration | media/telephony/transcription dimensions |
| #96 `Complete repository, architecture and privacy documentation` | completed documentation baseline | link only; do not reopen |

## Optional non-semantic cross-reference additions

After actual new issue numbers exist, it is reasonable to add a short `Related` or downstream note to #72, #77, #85 and #90. This must not change their approved acceptance, baseline effort, milestone, first-beta relevance or completion forecast.

## Existing issues that should NOT be repurposed

- Do not turn #72 into a giant ITSM issue.
- Do not turn #77 into PDF ingestion.
- Do not turn #78 into an arbitrary app marketplace.
- Do not turn #80 into a general plugin executor.
- Do not turn #85 into feedback collection plus every future report.
- Do not turn #49 into the M8 tracker.
- Do not reopen #96 just because the roadmap later changes.

## Deletions

**No existing GitHub issue should be deleted or closed as `not planned` because of this package.**

The out-of-scope decisions should be recorded in ADR-0016/product-scope documentation, not represented by destructive cleanup of historical issues.
