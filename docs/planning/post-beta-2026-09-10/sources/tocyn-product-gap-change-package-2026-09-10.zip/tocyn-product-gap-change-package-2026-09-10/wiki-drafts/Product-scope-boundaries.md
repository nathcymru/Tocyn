# Product scope boundaries

Tocyn is an open-source helpdesk. Competitive comparisons must distinguish missing helpdesk capability from adjacent CRM, marketing and marketplace products.

## In scope

- customer-support conversations and tickets;
- support-domain customer/context data;
- human collaboration and back-office support work;
- service problem/incident management;
- support-driven affected-customer updates;
- knowledge and tenant-grounded AI assistance;
- governed self-service/agent actions;
- operator applets over governed capabilities;
- support feedback (CSAT/CES);
- operational analytics/reporting;
- support communication channels including planned M8 voice/video/screen-share/phone.

## Out of scope unless a future ADR changes the boundary

- sales CRM pipelines/leads/opportunities;
- marketing/customer-engagement campaigns;
- Product Tours/marketing Tooltips/Checklists;
- marketing News/lifecycle Series/push/carousels;
- public App Store/central OAuth marketplace;
- broad vendor integration parity for its own sake;
- autonomous AI voice/Fin Voice.

A service incident update to customers linked to an affected support problem is support work and remains in scope. An arbitrary marketing audience campaign is not.
