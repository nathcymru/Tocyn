# Tenant knowledge and AI

**Status:** Existing RAG foundation plus planned M9.2 hardening/productisation.

A tenant's AI assistant is a logical retrieval/security boundary, not necessarily a separately trained model.

For every AI retrieval Tocyn must derive the verified tenant and actor permissions server-side, filter eligible knowledge, revalidate source ownership before R2 hydration and expose source/version provenance.

## Planned PDF ingestion

M9.2 adds PDF upload, asynchronous extraction, page-aware chunking, versioned Vectorize lifecycle and safe deletion. Image-only/OCR-dependent documents may fail visibly until OCR receives separate approval.

No third-party knowledge-sync catalogue is planned in M9.2.

Operator AI may use authorised internal knowledge. Service-user AI may retrieve only the material authorised for that surface. AI disabled/unavailable mode must retain deterministic knowledge/manual support.
