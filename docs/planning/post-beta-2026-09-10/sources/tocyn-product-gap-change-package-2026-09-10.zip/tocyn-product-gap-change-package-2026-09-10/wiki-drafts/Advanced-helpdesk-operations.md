# Advanced helpdesk operations

**Status:** Planned M9 capability.

M9 adds mature helpdesk operations without moving Tocyn into CRM/marketing territory.

## Linked work and problems

Customer tickets remain the customer-support history. Private back-office work and service Problems/Incidents are separate tenant-owned records with explicit links.

One Incident may link many affected tickets. An authorised incident update writes a public event/article into each bounded target conversation and uses Tocyn's reliable outbound dispatch. This is not an audience/campaign system.

## Operator applets

Tenant admins may define schema-based applets for conversation sidebar, timeline and composer recipes. Applets are data, not arbitrary JavaScript. Reads/actions are constrained by Tocyn permissions, governed connectors/tools/workflows and approvals.

## Feedback/reporting

CSAT/CES and optional comments feed service-quality metrics. Live operations and custom reports use bounded, allowlisted metric definitions; users do not receive raw SQL access.

## Workforce identity

Enterprise workforce authentication can be delegated to Cloudflare Access. Tocyn validates the Access assertion, maps the workforce identity and then applies Tocyn's own capabilities. Customer portal identity remains separate.
