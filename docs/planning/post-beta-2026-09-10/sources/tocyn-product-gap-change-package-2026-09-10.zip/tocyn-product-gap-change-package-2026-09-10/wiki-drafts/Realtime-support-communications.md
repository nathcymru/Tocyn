# Realtime support communications

**Status:** Planned M8 capability; not implemented merely because this page exists.

Tocyn will extend its canonical conversation model with tenant-scoped `SupportSession` records for browser audio/video, screen sharing and PSTN support.

## M8

- **M8.1** — Realtime communications architecture spike
- **M8.2** — Browser voice, video and screen share
- **M8.3** — Telephony and call operations
- **M8.4** — Recording and transcription

Media sessions remain linked to canonical conversations. Provider IDs, phone numbers and track IDs never become tenant/customer authority.

Cloudflare Realtime is the preferred media substrate, with the exact SFU/RealtimeKit split to be accepted through the M8.1 spike. PSTN uses a tenant-owned provider behind a Tocyn telephony gateway.

Recording is policy/consent controlled. Autonomous AI voice agents and marketing diallers are out of scope.

M8 does not hold issue #49 or M7 completion open.
