# Tocyn Product-Gap Change Design Package

**Planning snapshot:** 2026-09-10  
**Repository:** `nathcymru/Tocyn`  
**Verified `main`:** `93de1b975a45edd9d28ca70edd725b60deb6b275`  
**Package status:** **DESIGN / HANDOFF ONLY — NOTHING IN THIS PACKAGE HAS BEEN APPLIED TO THE REPOSITORY**

## Purpose

This package converts the agreed Intercom benchmark findings into a Tocyn-specific technical and delivery plan without changing Tocyn into a CRM, marketing platform, public app marketplace or autonomous voice-agent product.

It is designed to be combined with other change packages in a later conversation. The combining conversation must reconcile dependencies, ADR numbering, milestone numbering, Project 4 fields and forecast dates before any repository mutation.

## Owner-approved product direction represented by this package

| Area | Gap severity | Product decision |
| --- | --- | --- |
| Native phone + rich realtime support | **CRITICAL** | Add inbound/outbound phone, voicemail, callbacks, browser voice/video, screen sharing, recording and transcription. Explicitly exclude autonomous AI/Fin Voice. |
| Advanced ticketing operations | **HIGH** | Add linked back-office work and one-to-many problem/incident tracking with controlled affected-customer updates. |
| Tenant knowledge + AI grounding | **HIGH** | Formalise tenant-scoped AI grounding and add PDF ingestion. No third-party knowledge sync connectors at this stage. |
| Feedback + reporting | **HIGH** | Add CSAT/CES, live operations management and bounded tenant-defined reports. NPS is optional/deferred. |
| Operator applets / Canvas-like capability | **MEDIUM / STRATEGIC** | Add safe declarative applets and in-conversation recipes over existing governed tools/workflows. No arbitrary JavaScript, public App Store or central OAuth marketplace. |
| Enterprise workforce identity | **ARCHITECTURAL ALTERNATIVE** | Integrate operator/admin access with Cloudflare Access/Zero Trust and keep Tocyn authorisation authoritative. Do not build Tocyn-native SAML/OIDC/Google/SCIM endpoints for parity. |
| Outbound/proactive marketing | **NO PRODUCT GAP — OUT OF SCOPE** | Do not add campaigns, Product Tours, marketing Tooltips/Checklists, News, lifecycle Series, marketing push/carousels or comparable engagement tooling. |
| CRM/customer-data platform | **NO PRODUCT GAP — OUT OF SCOPE** | Keep support profiles/context; do not add leads, opportunities, pipelines, behavioural marketing segments or a CRM object platform. |
| Broad third-party ecosystem | **NO PRODUCT GAP — OUT OF SCOPE** | Do not pursue Intercom-scale Salesforce/HubSpot/Jira/Stripe/Shopify/App Store/mobile SDK parity. |

## Key repository conclusions

1. Current issue **#49 `Track delivery of the omnichannel architecture`** explicitly treats its preserved historical `audio/video` mention as outside the existing omnichannel specifications. Native voice/video therefore requires new approved scope; it must not be assumed already committed.
2. Existing **#72 `Split and merge tickets without losing context`** is a foundation for advanced ticket operations, but it does not own back-office work items or problem/incident tracking.
3. Existing **#85 `Report operational performance and quality metrics`** is the metric foundation. Its approved scope does not include a custom report builder, live support-management dashboard or customer feedback collection.
4. Existing **#77 `Expand the operator copilot with translation and runbooks`** explicitly excludes rebuilding RAG. PDF ingestion and the tenant-assistant grounding contract therefore need separate ownership.
5. Existing **#78/#79/#80/#81** already provide the workflow, authorisation, governed-tool and approval foundations required for safe operator applets. The applet layer must consume those contracts rather than create a second execution engine.
6. Existing **#50/#90** provide the cost-policy and Cost & Capacity foundations. Realtime media, transcription and telephony must become explicit resource dimensions under those contracts.
7. Current release governance deliberately separates architectural milestones from SemVer snapshots. The candidate `v0.4.0-beta.1` scope and 21 November 2026 forecast are **unchanged** by this package.

## Recommended roadmap structure

Do **not** reopen, renumber or delete M0–M7. Add two new architectural phases after the currently approved taxonomy:

- **M8 — Realtime Support Communications**
- **M9 — Advanced Helpdesk Operations & Enterprise Integration**

M8 and M9 may overlap in delivery where dependencies and the two bounded workstreams permit. They do not become first-private-beta blockers.

## Recommended immediate action

Apply only the **governance alignment change set** first:

- create the new cross-roadmap tracker and documentation/governance issue;
- create the proposed M8/M9 milestones and feature issues;
- add the proposed ADRs as **Proposed**;
- update roadmap/architecture/Wiki-sync documentation;
- mark stale Luminatick/single-tenant planning documents historical;
- reforecast the new scope in Project 4 **without altering existing baseline dates**.

Then return immediately to the existing M0–M7 main path. Do not start M8/M9 feature implementation merely because this planning package is accepted.

## Package map

| File | Purpose |
| --- | --- |
| `01-PRODUCT-GAP-REGISTER.md` | Gap/severity register and product boundaries. |
| `02-ROADMAP-PROJECT-MILESTONE-PLAN.md` | New phases/milestones, Project 4 changes and dependency rules. |
| `03-PROPOSED-GITHUB-ISSUES.md` | Copy-ready proposed issue scopes, acceptance and dependencies using temporary `PG-*` keys. |
| `04-EXISTING-ISSUE-CHANGE-MAP.md` | Exactly what to change or leave unchanged on existing issues. |
| `05-TECHNICAL-IMPLEMENTATION-PLAN.md` | Detailed technical architecture for each in-scope gap. |
| `06-SPRINT-RELEASE-DELIVERY-PLAN.md` | Governance sprint, M8 technical spike, release rules and effort envelope. |
| `07-DOCUMENTATION-WIKI-CHANGE-MAP.md` | Repository docs/Wiki additions, amendments and historical-document treatment. |
| `08-HANDOFF-APPLICATION-ORDER.md` | Safe order for the later combining/applying conversation. |
| `adrs/ADR-0016...ADR-0022...` | Full proposed ADR drafts. |
| `wiki-drafts/` | Draft new Wiki pages. |
| `references/` | Verified baseline and current Cloudflare technical references. |

## Collision rule for the later combined package

ADR numbers `ADR-0016`–`ADR-0022` and milestone numbers M8/M9 are correct against the verified current `main` snapshot above. If another package is merged first and consumes any number, **renumber this package before applying it** and repair every cross-reference. Never create duplicate ADR identifiers or parallel roadmap phase numbers.

## Non-authorisation statement

This package does **not** authorise feature code, deployment, Cloudflare resource provisioning, vendor registration, real telephone calls, inbound provider activation, remote migrations, paid-plan changes, release/tag creation or production operation.
