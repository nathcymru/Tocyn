# Documentation and Wiki Change Map

## 1. Add — repository ADRs

Add these proposed ADRs under `docs/adr/`:

1. `ADR-0016-helpdesk-product-boundary.md`
2. `ADR-0017-realtime-support-communications.md`
3. `ADR-0018-governed-declarative-operator-applets.md`
4. `ADR-0019-tenant-knowledge-grounding-and-document-ingestion.md`
5. `ADR-0020-cloudflare-access-workforce-identity.md`
6. `ADR-0021-linked-work-and-problem-management.md`
7. `ADR-0022-bounded-service-feedback-and-operational-reporting.md`

Update `docs/adr/README.md` to index them as **Proposed** until owner/review acceptance changes their status.

### Existing ADR treatment

Do **not** silently rewrite accepted ADR-0012–ADR-0015.

- ADR-0012: no semantic change. ADR-0017 references and extends its canonical-conversation principle to media support sessions.
- ADR-0013: no change.
- ADR-0014: no change. Its baseline/forecast/actual rule governs this roadmap extension.
- ADR-0015: no semantic change. ADR-0019/0017/0022 inherit its rule that privacy metadata is not access authority.
- Wiki ADR-0010: no change. ADR-0018 references its policy-gated-action rule.
- Wiki ADR-0011: no change. M8/M9 do not retroactively alter the accepted private-beta decision.

If desired, add only `Related` cross-links after the new ADRs are accepted.

## 2. Modify — authoritative roadmap docs

### `docs/roadmap.md`

- Change the phase summary from M0–M7 to M0–M9.
- Preserve all existing M0–M7 text and dates.
- Add:
  - M8 Realtime Support Communications;
  - M9 Advanced Helpdesk Operations & Enterprise Integration.
- State explicitly that 16 July 2027 remains the preserved forecast for the **original scoped M0–M7 plan**.
- State that the combined reforecast will establish the extended-scope forecast.
- State that `v0.4.0-beta.1` is unaffected.

### `docs/wiki-sync/Roadmap-and-releases.md`

Mirror the above phase additions and release boundary.

### `docs/wiki-sync/Omnichannel-implementation-roadmap.md`

Add a section:

- M7 remains provider messaging/support-email adapters.
- Native media/PSTN is M8 and not an M7 completion condition.
- #49 is not held open by M8.
- all support sessions still link to canonical conversations.

## 3. Modify — architecture docs

### `docs/architecture/channel-adapters.md`

Add:

- support-session/telephony adapter relationship;
- verified inbound phone routing;
- phone numbers/provider IDs are metadata, not tenant/customer authority;
- M8 relationship to #87/#88;
- media lifecycle is represented by `SupportSession`, not by forcing raw media into article records.

### `docs/architecture/canonical-conversation-contract.md`

Add a related-entity section for `SupportSession`, `BackofficeWorkItem` and `ServiceProblem`.

Keep the canonical conversation/ticket/article contract intact.

### `docs/architecture/data-and-tenant-boundaries.md`

Add tenant ownership examples for:

- support sessions;
- telephony provider mappings;
- recordings/transcripts;
- knowledge source versions/vectors;
- applet definitions;
- work/problem links;
- service feedback/report definitions.

State that derived media/vector/report artefacts never become authority.

### `docs/architecture/ai-and-autonomous-operations.md`

Add:

- logical per-tenant assistant grounding model;
- visibility-aware knowledge retrieval;
- PDF provenance;
- explicit exclusion of autonomous AI voice;
- optional transcript summarisation remains bounded AI assistance.

### `docs/architecture/system-overview.md`

Add M8/M9 blocks:

- Cloudflare Realtime media substrate;
- SupportSession coordinator;
- telephony gateway;
- R2 recording/transcript storage;
- advanced work/problem domain;
- applet runtime;
- reporting/feedback;
- Cloudflare Access workforce authentication adapter.

## 4. Add — Wiki-sync pages

Add the drafts supplied in this package:

- `docs/wiki-sync/Product-scope-boundaries.md`
- `docs/wiki-sync/Realtime-support-communications.md`
- `docs/wiki-sync/Advanced-helpdesk-operations.md`
- `docs/wiki-sync/Tenant-knowledge-and-AI.md`

Optional fifth page if the final documentation review prefers separation:

- `Service-feedback-and-reporting.md`

Update `_Sidebar.md`, `Home.md` and `Start-here.md` only as necessary to surface these pages without duplicating prose.

Update:

- `Architecture-decision-records-addendum.md`
- `Channels-and-conversation-model.md`
- `AI-and-autonomous-operations.md`
- `Architecture-and-tenant-isolation.md`
- `System-architecture.md`

to reflect the new decisions.

## 5. Mark historical/superseded — do not delete evidence

### `docs/design-and-implementation-plan.md`

Currently starts as a Luminatick single-tenant Phase 1 plan. Add a prominent historical banner and point to `docs/roadmap.md` + accepted ADRs as current authority.

Do not allow its single-tenant statements to be read as current Tocyn architecture.

### `docs/phase-1.7-rag-spec.md`

Add a historical/current-status header. Remove or supersede the statement that data isolation is “naturally handled” because the system is single-tenant.

Its PDF/R2 discussion should be labelled historical foundation; M9.2 owns current PDF vectorisation/tenant-scope acceptance.

### `docs/knowledge-enhancement-plan.md`

Mark historical implementation plan; current issue/ADR ownership supersedes it.

### `docs/kb-agent-enhancement-plan.md`

Mark historical. The text currently contains current-sounding “fully upgraded” claims and a client category-filter design. Add an explicit warning that client-supplied filters are not tenant authority and that M9.2/ADR-0019 define current retrieval security.

## 6. README changes

After the roadmap extension is accepted:

- update any “M0–M7” roadmap wording to “M0–M9”;
- add a concise statement that realtime phone/media and advanced service operations are planned, not implemented;
- retain “pre-release/no hosted service” status;
- do not market M8/M9 as shipped.

## 7. No file deletion

This package recommends **no documentation file deletion**.

Historical plans remain evidence. They should be labelled, cross-linked or moved only through a separately reviewed documentation cleanup where every incoming link is updated.

## 8. Final documentation audit commands

The applying agent should run targeted searches such as:

```bash
rg -n 'M0.?M7|M0–M7|M7\.5|16 July 2027|2027-07-16' README.md docs .agents
rg -n 'single-tenant|single tenant|naturally handled|fully upgraded' docs
rg -n 'audio/video|voice|video|screen shar|telephon|PSTN|record|transcri' docs .agents
rg -n 'SAML|SCIM|JIT|Cloudflare Access|Zero Trust' README.md docs
```

Interpret hits; do not mechanically replace historical evidence.
