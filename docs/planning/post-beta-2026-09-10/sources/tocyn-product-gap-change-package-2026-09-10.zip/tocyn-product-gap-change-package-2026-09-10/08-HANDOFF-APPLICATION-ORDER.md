# Handoff and Application Order

## Critical instruction

This is a **planning component** to be combined with other user-approved change packages. Do not apply it mechanically.

## Step 1 — refresh reality

Before creating or editing anything:

1. verify repository `main` and compare it with package baseline `93de1b975a45edd9d28ca70edd725b60deb6b275`;
2. read current `docs/roadmap.md`, `AGENTS.md` and `docs/adr/README.md`;
3. refresh open issues, milestones and Project 4;
4. check whether any other package has already allocated ADR-0016+ or M8/M9;
5. verify current Cloudflare Realtime/Access APIs before implementation, because provider APIs can change.

If `main` has materially changed, treat this package as a design input and reconcile rather than overwriting newer authority.

## Step 2 — reconcile all packages

Build one combined:

- product-gap register;
- dependency graph;
- ADR-number map;
- milestone-number map;
- issue-key → actual GitHub issue-number map;
- Project reforecast.

Resolve duplicates. Prefer one owning issue per implementation outcome.

## Step 3 — create governance ownership first

Create `PG-GOV-01` as the documentation/governance issue using the template in `03-PROPOSED-GITHUB-ISSUES.md`.

Then create `PG-GOV-00` as the cross-roadmap tracker.

Do not make feature edits under either issue.

## Step 4 — create M8/M9 milestone objects

Use the exact proposed milestone naming convention in `02-ROADMAP-PROJECT-MILESTONE-PLAN.md`, unless the combined package has an approved renumbering.

Do not alter M0–M7 baseline metadata.

## Step 5 — create the new feature issues

Create the `PG-*` issues in dependency-friendly order.

After GitHub assigns actual issue numbers:

- replace every `PG-*` dependency/reference in the issue bodies;
- add native dependency relationships if available;
- update the cross-roadmap tracker checklist;
- update #49 with only the narrow M8 cross-reference described in `04-EXISTING-ISSUE-CHANGE-MAP.md`.

Do not leave temporary planning keys in the live GitHub backlog.

## Step 6 — Project 4

Run the repository roadmap reforecast process.

For new items only:

- set status;
- establish owner-approved baseline dates once the **combined** plan is approved;
- set forecast dates;
- leave actual dates blank until work starts/completes;
- progress starts at 0%;
- calculate schedule variance only against the new approved baseline.

Preserve every existing baseline field.

## Step 7 — ADR/documentation PR

On a dedicated branch, under `PG-GOV-01`:

- add/renumber the proposed ADR files;
- index them;
- update roadmap/architecture/Wiki-sync docs;
- mark old planning docs historical;
- keep every new capability labelled planned;
- run documentation/link/build checks;
- use one coherent PR;
- use `Closes #<PG-GOV-01 actual number>` only when its acceptance is fully met.

No feature code belongs in this PR.

## Step 8 — return to main path

After the governance PR is accepted/merged and Project state is synchronized, resume the current M0–M7 critical path.

Do not start M8/M9 simply because their issues exist.

## Step 9 — later M8 execution

Start with `PG-RT-01` architecture spike. It must resolve the Cloudflare Realtime/RealtimeKit/telephony boundary before the broader implementation.

## Step 10 — release discipline

Do not create a tag/Release during gap planning.

Only create a SemVer snapshot after actual tested integrated code exists and the maintainer authorises the release action.

## Final acceptance checklist for the combined change package

- [ ] No repo history falsified.
- [ ] No existing baseline date overwritten.
- [ ] No existing accepted ADR silently rewritten.
- [ ] No M0–M7 issue broadened to hide new effort.
- [ ] M8/M9 are explicit planned capabilities.
- [ ] `v0.4.0-beta.1` remains unchanged unless unrelated combined evidence requires change.
- [ ] Phone/video/screen share/recording/transcription are explicitly owned.
- [ ] Fin Voice/autonomous AI voice explicitly excluded.
- [ ] Back-office/problem/incident work explicitly owned.
- [ ] PDF/tenant AI grounding explicitly owned.
- [ ] Applets are declarative and governed, not arbitrary plugins.
- [ ] CSAT/CES/live dashboard/custom reports explicitly owned.
- [ ] Cloudflare Access authentication is separated from Tocyn authorisation.
- [ ] Marketing/CRM/App Store parity explicitly out of scope.
- [ ] No production/provider/release operation occurred under the governance package.
