# Package Manifest

Generated: 2026-09-10
Repository baseline: `93de1b975a45edd9d28ca70edd725b60deb6b275`

**No repository changes were made while generating this package.**

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `00-OVERVIEW.md` | 7062 | `d1019c483646a2c4f89d6261d3ab9a4bee0adb60532275660f741cfb39b0efac` |
| `01-PRODUCT-GAP-REGISTER.md` | 7862 | `10aa03ddeb842e2f0eaeee5d08618de87f739c935ff8d4ba6ba872cd1b2c30c7` |
| `02-ROADMAP-PROJECT-MILESTONE-PLAN.md` | 8755 | `fd33e9e7feaf04345496b31ab1474040a1724e8fbaf711e7a3d298188679bccb` |
| `03-PROPOSED-GITHUB-ISSUES.md` | 47580 | `f6a45549a931be3de4577d03300e5a931e8198f48f9bbda29579f1826857f69c` |
| `04-EXISTING-ISSUE-CHANGE-MAP.md` | 4977 | `e330afc415f3a3b5388ca2f0caa76a431e1bd292104846154774b75fb2223779` |
| `05-TECHNICAL-IMPLEMENTATION-PLAN.md` | 19020 | `ccf7bbe8ae9c4430d92c24192b7aa6bd75a88fe614ffb3d3f5fd44409bd27a48` |
| `06-SPRINT-RELEASE-DELIVERY-PLAN.md` | 5244 | `1fbaae851f39e8a2bec58fbd64486beece8e7a205127f625868228687790be7d` |
| `07-DOCUMENTATION-WIKI-CHANGE-MAP.md` | 6677 | `9cfe4f33879906250409e6ac1f512fd0bca33c9615d423352fb3877616da9095` |
| `08-HANDOFF-APPLICATION-ORDER.md` | 4489 | `cffa38117c86d8e37834ec263211b16ea3fa240cca5a15e68dcf351ddd101cdc` |
| `adrs/ADR-0016-helpdesk-product-boundary.md` | 2679 | `31d643a7b1939fa686d6441a207c6b0ad5ab161a8fc5e2078e68fe6b1fc1fcad` |
| `adrs/ADR-0017-realtime-support-communications.md` | 2912 | `470e4716b76218fca8c7caf5d922447ecb8bf46b28a26e8ee5c11ac0f31ce669` |
| `adrs/ADR-0018-governed-declarative-operator-applets.md` | 2454 | `f5f699e9586b79cf2a752abfa10200a475aba0395d5d5082a3f5de251ba6a5c5` |
| `adrs/ADR-0019-tenant-knowledge-grounding-and-document-ingestion.md` | 2376 | `ffa7c3077ab33a0ee96be767fe8b85e0bfb5876a2bf135d31698c5d663e9d5fa` |
| `adrs/ADR-0020-cloudflare-access-workforce-identity.md` | 2302 | `13ad8d7edbd3f03bf10c5edf737db7dd922b876494f428ac7d2605a56ab2776a` |
| `adrs/ADR-0021-linked-work-and-problem-management.md` | 1928 | `15ab4bf8912c7d9e9c92e1c0631e28e40f0e9f4d9010e8ad31a9e5e518add5fa` |
| `adrs/ADR-0022-bounded-service-feedback-and-operational-reporting.md` | 1971 | `7b70f6a22f2eef92bdb6270214d1cdbda6fe261aeddd207eb71bab599266cc8c` |
| `references/EXTERNAL-TECHNICAL-REFERENCES.md` | 2986 | `cd82f277a794524f8595ce58992fad3ba4a942a5038f9c07a5c4c2dc59f4d3a2` |
| `references/REPOSITORY-BASELINE.md` | 3307 | `b6253d88f9c87525083a3b89dfdc6c2df7fae5499a50369eec78b617cd0d532f` |
| `wiki-drafts/Advanced-helpdesk-operations.md` | 1304 | `5d5444e7d5140ee53987b69f41f69bbbb4a373607271bbb33e4aae99b78052f4` |
| `wiki-drafts/Product-scope-boundaries.md` | 1244 | `e5e6cf79c0bf08089010e53221817ea6c054b7fac6ed36e8e184e06115c812eb` |
| `wiki-drafts/Realtime-support-communications.md` | 979 | `9ed7c86b7a7954b5dd1e5bab35b135ec71673b2240cc325f3296bf6d1c17c72d` |
| `wiki-drafts/Tenant-knowledge-and-AI.md` | 932 | `673204258b2d2d8bf8e8ae9eac186793fa263a3cabc7f104f86b8768fc7aa591` |

Temporary `PG-*` identifiers are planning keys and must be replaced with actual GitHub issue numbers by the final applying conversation.
