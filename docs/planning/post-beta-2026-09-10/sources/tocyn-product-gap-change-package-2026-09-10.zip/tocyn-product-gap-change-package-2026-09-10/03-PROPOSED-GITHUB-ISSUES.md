# Proposed GitHub Issues

## How to use this file

`PG-*` identifiers are **temporary planning keys**, not GitHub issue numbers. The final applying conversation must create the issues, record their real numbers, replace all `PG-*` references and add native dependency relationships.

Issue titles follow Tocyn's current imperative naming style. Milestones follow the current `M<phase>.<n>: <layer> - <Capability>` convention.

Effort values are proposals for the combined reforecast; do not write them as immutable Project baselines until the owner approves the combined package.


---

## PG-GOV-00 — Track delivery of the approved helpdesk capability extensions

**Proposed labels:** `documentation`, `enhancement`  
**Proposed milestone:** None — cross-roadmap tracker  
**Proposed effort:** 2 h baseline / 6 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Cross-roadmap tracking only. Maintain the approved M8/M9 checklist, product-scope boundary references and final reconciliation. No duplicate implementation effort.

### Scope boundary

Implementation is owned by member issues. This tracker must not hold M0–M7 milestones or the first beta open.

### Acceptance and demonstration


- [ ] List every M8/M9 member issue after actual GitHub numbers are assigned.

- [ ] Track completion without duplicating acceptance criteria.

- [ ] Link ADR-0016–ADR-0022 and the updated roadmap/Wiki pages.

- [ ] Close only when M8/M9 accepted and final documentation reconciliation is complete.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: All M8/M9 issues are downstream checklist members; no architectural prerequisite.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-GOV-01 — Record the approved helpdesk product boundaries and roadmap extension

**Proposed labels:** `documentation`, `enhancement`  
**Proposed milestone:** None — governance/documentation change  
**Proposed effort:** 8 h baseline / 24 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Apply the approved product-gap decisions to version-controlled ADRs, roadmap/architecture documents and Wiki-sync sources; create/coordinate M8/M9 issue/milestone metadata; mark stale single-tenant/Luminatick planning documents historical.

### Scope boundary

Documentation/governance only. No feature code, provider setup, deployment, release/tag creation or production claim.

### Acceptance and demonstration


- [ ] Add the approved M8/M9 phase/milestone descriptions while preserving M0–M7 baselines.

- [ ] Add and index proposed ADR-0016–ADR-0022, renumbering first if another combined package consumes an ordinal.

- [ ] Update roadmap, architecture and Wiki-sync pages listed in this package.

- [ ] Mark legacy single-tenant/current-sounding knowledge plans historical without deleting evidence.

- [ ] Keep `v0.4.0-beta.1` scope/forecast unchanged.

- [ ] Create/update Project 4 records only after the combined reforecast, preserving all existing baseline fields.

- [ ] Documentation checks pass and no planned capability is described as implemented.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: Existing documentation baseline #96; current `main`.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-RT-01 — Prove the Cloudflare Realtime support-session architecture

**Proposed labels:** `enhancement`, `security`  
**Proposed milestone:** M8.1: Platform - Realtime Communications Architecture  
**Proposed effort:** 24 h baseline / 72 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Run a bounded architecture spike for conversation-linked support sessions using Cloudflare Realtime. Decide Realtime SFU vs selective RealtimeKit/media-adapter use, signalling/session ownership, recording/transcription path, PSTN provider boundary, reconnect/failure model and cost dimensions.

### Scope boundary

No production Realtime app, live PSTN number/provider activation, real customer calls or autonomous AI voice. External sandbox/resource use still needs explicit operational authorisation.

### Acceptance and demonstration


- [ ] Define versioned `SupportSession`, participant/media and provider interfaces.

- [ ] Demonstrate/record a reproducible synthetic or specifically authorised isolated proof for 1:1 audio/video and screen-share architecture.

- [ ] Document Cloudflare credential boundary: Realtime app secrets stay server-side.

- [ ] Compare raw Realtime SFU and RealtimeKit only against Tocyn requirements; record selected boundary and fallback.

- [ ] Define provider-neutral `TelephonyProvider` selection criteria and media bridge assumptions.

- [ ] Define recording/transcription storage, consent and retention boundary.

- [ ] Add dated media/telephony resource dimensions for #50/#90 planning.

- [ ] Record browser/platform limitations, failure/reconnect behaviour and cost evidence.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: Related to #49; architectural foundations #50, #74, #79, #87, #88, #90.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-RT-02 — Model tenant-scoped realtime support sessions and media permissions

**Proposed labels:** `enhancement`, `security`  
**Proposed milestone:** M8.2: Fullstack - Voice, Video & Screen Share  
**Proposed effort:** 40 h baseline / 120 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Implement provider-independent support-session persistence/state, tenant-qualified relationships, participant/media permissions, short-lived session capability handling, per-session coordination and canonical conversation/audit events.

### Scope boundary

No browser call UI beyond minimal test harness; no PSTN provider implementation; no recording/transcription feature.

### Acceptance and demonstration


- [ ] Tenant-qualified D1 schema/repositories for support sessions, participants and media metadata.

- [ ] Verified tenant/actor scope is established before session/DO/SFU access.

- [ ] Per-session state machine covers requested/ringing/connecting/active/held/ended/failed/missed as applicable.

- [ ] Realtime provider IDs and track IDs never confer authority.

- [ ] Session coordinator reconnect/takeover/fencing tests include two colliding tenants.

- [ ] #79 capability checks govern create/join/control/end operations.

- [ ] #50 admission/resource reservations apply to session start and recovery.

- [ ] Canonical conversation timeline/audit receives deterministic lifecycle events without storing secrets.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: PG-RT-01; #50/#64, #74, #79.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-RT-03 — Add browser voice, video and screen-sharing support sessions

**Proposed labels:** `enhancement`, `security`, `accessibility`  
**Proposed milestone:** M8.2: Fullstack - Voice, Video & Screen Share  
**Proposed effort:** 48 h baseline / 144 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Add accessible operator/customer browser UX for preflight, audio-only, video, screen share, device change, mute, hold, reconnect, end and text-to-session upgrade using the accepted M8 session/media architecture.

### Scope boundary

Screen sharing only; no remote desktop control. No autonomous AI voice. No silent recording.

### Acceptance and demonstration


- [ ] Existing conversation can start/join/end a support session without losing text history.

- [ ] Pre-call mic/camera permission/device test and understandable failure states.

- [ ] Audio-only, camera on/off and explicit screen-share start/stop.

- [ ] Reconnect/network-degradation state does not create a second authorised session accidentally.

- [ ] Recording/transcription state indicator is reserved and truthful even when feature disabled.

- [ ] Keyboard/focus/screen-reader/contrast tests pass using #48 primitives/static CSS.

- [ ] Two tenant sessions can run concurrently without track/control leakage.

- [ ] Resource/bundle/browser compatibility evidence is recorded.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: PG-RT-02; #48, #68, #70, #74.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-RT-04 — Implement a tenant-owned telephony gateway for inbound and outbound calls

**Proposed labels:** `enhancement`, `security`  
**Proposed milestone:** M8.3: Fullstack - Telephony & Call Operations  
**Proposed effort:** 48 h baseline / 144 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Implement the provider-neutral telephony gateway plus the first approved tenant-owned provider/reference adapter for inbound/outbound PSTN lifecycle, verified webhooks, tenant number mapping and canonical conversation/support-session linkage.

### Scope boundary

Tocyn does not sell/provision numbers or hold a central carrier account. No marketing/predictive dialler. Live provider activation requires separate operational authorisation.

### Acceptance and demonstration


- [ ] `TelephonyProvider` interface separates canonical call operations from provider specifics.

- [ ] Inbound events are cryptographically/provider verified before tenant mapping and normalisation.

- [ ] Outbound calls require explicit operator capability, verified target and tenant provider configuration.

- [ ] Provider call/number IDs are metadata, never tenant/customer authority.

- [ ] #74 rules prevent automatic customer identity proof from phone-number text alone.

- [ ] #87-style duplicate/reordered/concurrent provider event fixtures reconcile correctly.

- [ ] #88-style durable outbound/retry semantics are used where applicable.

- [ ] Tenant-owned credentials are encrypted/masked and never sent to browser/app logs.

- [ ] Sandbox/reference failure, revocation, rate/cost and uncertain-call-state behaviour is recorded.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: PG-RT-01, PG-RT-02; #74, #79, #87, #88, #90.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-RT-05 — Add voicemail, callback, transfer and call-queue operations

**Proposed labels:** `enhancement`, `security`, `accessibility`  
**Proposed milestone:** M8.3: Fullstack - Telephony & Call Operations  
**Proposed effort:** 40 h baseline / 120 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Build helpdesk call operations over the telephony gateway: office-hours/queue routing, missed-call state, voicemail, callback requests, operator transfer, disposition and visible queue/call state.

### Scope boundary

No workforce-management suite, contact-centre sales dialler or marketing outbound queue.

### Acceptance and demonstration


- [ ] Tenant-configurable support number routes to bounded team/group/queue rules.

- [ ] #73 calendar/office-hours state is reused where applicable.

- [ ] Missed call and voicemail create/update canonical support history without duplicate tickets.

- [ ] Voicemail media is tenant-owned and follows recording/retention policy.

- [ ] Callback request is visible, assignable and idempotent; placing the callback revalidates authority/target.

- [ ] Transfer/handoff is audited and cannot expose the caller to another tenant.

- [ ] Queue states have deterministic timeout/failure/fallback behaviour.

- [ ] Operator UI remains keyboard/screen-reader operable.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: PG-RT-04; #70, #73, #79.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-RT-06 — Record and transcribe support sessions under tenant policy

**Proposed labels:** `enhancement`, `security`  
**Proposed milestone:** M8.4: Fullstack - Recording & Transcription  
**Proposed effort:** 40 h baseline / 120 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Implement policy/consent-aware recording and transcription for supported browser/PSTN sessions, tenant-scoped R2 artefacts, speaker/time provenance, retention/delete lifecycle and visible failure states.

### Scope boundary

No silent always-on recording; no autonomous voice agent; no assumption that privacy metadata itself grants/denies data access.

### Acceptance and demonstration


- [ ] Recording default/policy is explicit and snapshotted for the session.

- [ ] Consent/notification evidence and recording start/stop actor/time are represented.

- [ ] Recording files use tenant-scoped storage ownership and bounded access URLs/streams.

- [ ] Transcription has speaker/time/source correlation and explicit pending/failed/partial states.

- [ ] Deletion/retention removes recording, transcript and derived search/AI artefacts through retryable manifests.

- [ ] Unauthorised/cross-tenant playback/transcript reads fail without side effect.

- [ ] #50/#90 budgets cover recording/transcription consumption.

- [ ] Provider/API failure does not corrupt the canonical conversation or claim a transcript exists when it does not.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: PG-RT-02 plus the accepted recording path from PG-RT-01; integrates with PG-RT-03/04; #50/#90, ADR-0015.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-RT-07 — Integrate realtime support artefacts into conversations, QA and reporting

**Proposed labels:** `enhancement`, `security`, `accessibility`  
**Proposed milestone:** M8.4: Fullstack - Recording & Transcription  
**Proposed effort:** 24 h baseline / 72 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Expose authorised call/session lifecycle, recording/transcript references and derived metrics in the conversation timeline, QA workflows and reporting registry.

### Scope boundary

No hidden model reasoning, unbounded transcript prompt or automatic public transcript disclosure.

### Acceptance and demonstration


- [ ] Conversation timeline shows start/answer/end/missed/voicemail/recording/transcript state.

- [ ] Recording/transcript visibility follows actor capability and tenant policy.

- [ ] #84 QA can reference authorised session evidence without copying unnecessary media.

- [ ] #85/report registry receives defined call/session metrics with denominators and late-event rules.

- [ ] Optional transcript summary uses bounded #76/#77 AI rules and source provenance.

- [ ] Customer-visible transcript/summary is explicit, never default leakage of internal content.

- [ ] Retention/deletion updates UI/report/search state consistently.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: PG-RT-03, PG-RT-05, PG-RT-06; #76/#77, #84, #85.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-TK-01 — Create linked back-office work items without exposing customer conversations

**Proposed labels:** `enhancement`, `security`, `accessibility`  
**Proposed milestone:** M9.1: Fullstack - Linked Work & Problem Management  
**Proposed effort:** 32 h baseline / 96 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Add a tenant-scoped internal BackofficeWorkItem domain with independent status/priority/owner, private notes/evidence and explicit links to customer tickets.

### Scope boundary

No cross-tenant work transfer; no full ITSM CMDB/change-management suite; no automatic copying of private work notes into customer conversations.

### Acceptance and demonstration


- [ ] Tenant-qualified work-item and ticket-link persistence with composite ownership checks.

- [ ] Work item can be created from a ticket and owned by a different team/operator while customer ticket ownership remains independent.

- [ ] Internal notes/attachments remain private across all linked-ticket/customer views.

- [ ] Link/unlink/assign/state changes are audited.

- [ ] #79 capabilities distinguish work-item read/create/update/assign.

- [ ] #70 mentions/collaboration may be reused without treating presence as authority.

- [ ] Concurrent link/state updates have deterministic conflict handling.

- [ ] Accessible operator work queue/detail surfaces use #48 conventions.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: #70, #72, #79; current tenant repository/audit foundations.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-TK-02 — Track service problems and incidents across affected conversations

**Proposed labels:** `enhancement`, `security`, `accessibility`  
**Proposed milestone:** M9.1: Fullstack - Linked Work & Problem Management  
**Proposed effort:** 40 h baseline / 120 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Add tenant-scoped Problem/Incident records, many-ticket links, severity/status/timeline, customer-safe update content and an explicit bounded affected-customer publish action using the shared outbox.

### Scope boundary

No marketing audience builder, subscription campaign system or cross-tenant incident fan-out.

### Acceptance and demonstration


- [ ] One Problem/Incident links to many same-tenant tickets and survives ticket split/merge provenance.

- [ ] Internal diagnosis/root-cause fields are separated from customer-safe update fields.

- [ ] Affected target count/list is previewed before publish.

- [ ] Publish requires `incident_updates:publish` (or approved equivalent) and revalidates targets.

- [ ] Each target gets an idempotent customer-visible article/event plus #88 outbound intent.

- [ ] Partial provider failures can be retried without duplicate committed updates.

- [ ] Link/unlink/publish operations are fully audited.

- [ ] Fixture analytics expose incident volume/affected count without raw unbounded scans.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: PG-TK-01; #72, #79, #88; #85 for reporting integration.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-KB-01 — Ingest tenant PDF knowledge with lifecycle-safe provenance

**Proposed labels:** `enhancement`, `security`, `accessibility`  
**Proposed milestone:** M9.2: Fullstack - Tenant Knowledge & AI Grounding  
**Proposed effort:** 32 h baseline / 96 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Extend the current R2/D1/Vectorize knowledge pipeline to accept tenant PDF sources, extract text asynchronously, retain page/source/version provenance and safely promote/replace/delete vectorised versions.

### Scope boundary

No third-party knowledge sync connectors and no OCR in the first issue. Image-only PDFs fail visibly rather than consuming unapproved processing.

### Acceptance and demonstration


- [ ] Authorised tenant PDF upload validates configured type/signature/size/page bounds and writes tenant-owned R2 source.

- [ ] Workflow/Queue extraction and vectorisation is retryable and cost bounded.

- [ ] Chunks/vectors carry tenant/source/version/visibility/page provenance.

- [ ] New version is promoted atomically only after successful indexing; old vectors are cleaned retryably.

- [ ] Delete removes R2/vector/derived artefacts without losing cleanup ownership.

- [ ] Parser failure/image-only PDF produces explicit status.

- [ ] Cross-tenant colliding source IDs cannot retrieve/hydrate another tenant's object.

- [ ] Knowledge UI exposes processing/active/error/version/source state accessibly.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: Current RAG foundation; #50/#64, #79.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-KB-02 — Bind AI assistance to authorised tenant knowledge scopes

**Proposed labels:** `enhancement`, `security`  
**Proposed milestone:** M9.2: Fullstack - Tenant Knowledge & AI Grounding  
**Proposed effort:** 24 h baseline / 72 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Formalise the logical per-tenant AI assistant contract so every retrieval is constrained by verified tenant + actor visibility and produces source/version provenance across operator and service-user AI surfaces.

### Scope boundary

No per-tenant model fine-tuning requirement; no cross-tenant shared retrieval cache; no third-party knowledge sync.

### Acceptance and demonstration


- [ ] Tenant and actor knowledge scope is derived server-side; client filters cannot grant access.

- [ ] Vectorize filters plus source-manifest ownership revalidation protect hydration.

- [ ] Operator-only/internal knowledge is not available to service-user AI.

- [ ] Suggestions/answers expose authorised source/page/version citations and staleness.

- [ ] Two tenants with intentionally similar documents prove zero cross-tenant retrieval.

- [ ] AI disabled/unavailable leaves deterministic KB/manual support usable.

- [ ] Bounded context and #50 cost controls apply.

- [ ] #76/#77 consume the contract without duplicating the RAG engine.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: PG-KB-01; #76, #77, #79.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-AP-01 — Render governed operator applets from declarative schemas

**Proposed labels:** `enhancement`, `security`, `accessibility`  
**Proposed milestone:** M9.3: Fullstack - Governed Operator Applets  
**Proposed effort:** 40 h baseline / 120 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Implement AppletDefinition v1, server-resolved view models and safe rendering in conversation sidebar/timeline/composer-recipe surfaces using allowlisted #48 primitives and existing governed data/action contracts.

### Scope boundary

No arbitrary JavaScript/HTML/CSS, remote executable package, embedded secret, public App Store or central OAuth marketplace.

### Acceptance and demonstration


- [ ] Versioned schema has finite node/data/action types and rejects unknown executable content.

- [ ] Definitions are tenant-qualified; browser never receives connector credentials.

- [ ] Read bindings use canonical data or #75 authorised connector reads.

- [ ] Action buttons reference #80 typed tools and preserve #79/#81 policy/approval outcomes.

- [ ] Composer recipe launch integrates with #68 slash-command UX without bypassing policy.

- [ ] Applet state/rendering is isolated across two tenants/instances.

- [ ] Security tests cover XSS/schema abuse, stale definition, revoked capability and cross-tenant IDs.

- [ ] Accessibility/static CSS/token rules from #48 are enforced.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: #48, #68, #75, #79, #80, #81.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-AP-02 — Author, validate and publish tenant applets safely

**Proposed labels:** `enhancement`, `security`, `accessibility`  
**Proposed milestone:** M9.3: Fullstack - Governed Operator Applets  
**Proposed effort:** 32 h baseline / 96 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Add tenant-admin applet authoring with draft/validate/preview/dry-run/version/publish/retire/rollback semantics, reusing #78 governance patterns rather than creating a second workflow engine.

### Scope boundary

No code editor, npm/package upload, arbitrary URL execution or app marketplace publishing.

### Acceptance and demonstration


- [ ] Admin can compose supported applet nodes/bindings without raw executable code.

- [ ] Validation resolves referenced data sources/tools/workflows and current permissions.

- [ ] Preview/dry-run cannot perform unapproved mutations.

- [ ] Published version is immutable; active action/approval binds to exact version.

- [ ] Rollback/retire is audited and safely affects new instances.

- [ ] Revoked connector/tool/capability causes fail-closed runtime behaviour.

- [ ] One read-only and one approval-required reference applet are demonstrated end to end.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: PG-AP-01; #66, #78, #79/#80/#81.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-FB-01 — Capture tenant-scoped CSAT and CES feedback

**Proposed labels:** `enhancement`, `security`, `accessibility`  
**Proposed milestone:** M9.4: Fullstack - Service Feedback & Reporting  
**Proposed effort:** 24 h baseline / 72 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Add post-support CSAT/CES request, score/comment capture, signed/idempotent submission paths and correlation to ticket/operator/team/channel/SLA/AI state.

### Scope boundary

No generic marketing survey/campaign engine. NPS is schema-compatible future scope, not an acceptance requirement.

### Acceptance and demonstration


- [ ] Tenant can configure CSAT/CES enabled state and prompt timing within support workflows.

- [ ] Feedback request token is scoped, short-lived/idempotent and cannot submit to another tenant/conversation.

- [ ] Portal/widget and signed support-link paths are supported without exposing private ticket data.

- [ ] Score/comment and service context are tenant-owned and auditable.

- [ ] Reopen/re-resolve behaviour cannot spam unlimited feedback prompts.

- [ ] Unauthorised manipulation of operator/team/channel correlation is rejected.

- [ ] Accessible feedback UI works without AI.

- [ ] Metrics feed #85/reporting definitions with documented denominators.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: #73, #79; #88 only where an outbound feedback link is sent.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-RP-01 — Expose a live support-operations management dashboard

**Proposed labels:** `enhancement`, `security`, `accessibility`  
**Proposed milestone:** M9.4: Fullstack - Service Feedback & Reporting  
**Proposed effort:** 32 h baseline / 96 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Add a tenant-scoped live management view over bounded authoritative aggregates for queue health, assignment/capacity, SLA, response/resolution, feedback, incidents and realtime sessions when available.

### Scope boundary

No unbounded raw event/message scans or false claim that presence is perfectly reliable.

### Acceptance and demonstration


- [ ] Dashboard exposes defined queue/wait/SLA/assignment/operator availability metrics with freshness timestamps.

- [ ] CSAT/CES integrates after PG-FB-01.

- [ ] Problem/incident metrics integrate after PG-TK-02.

- [ ] Call/realtime metrics integrate after PG-RT-07 without blocking an earlier dashboard foundation.

- [ ] Metric values reconcile to #85 definitions/fixtures.

- [ ] Refresh/invalidation strategy is bounded and cost controlled.

- [ ] Authorisation prevents cross-tenant/team data exposure.

- [ ] Keyboard/screen-reader/contrast acceptance is recorded.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: #73, #85, PG-FB-01; PG-TK-02/PG-RT-07 are integration-only sequencing constraints for their metrics.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-RP-02 — Build bounded tenant-defined operational reports

**Proposed labels:** `enhancement`, `security`, `accessibility`  
**Proposed milestone:** M9.4: Fullstack - Service Feedback & Reporting  
**Proposed effort:** 40 h baseline / 120 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Implement a saved report-definition model and UI using allowlisted metric/dimension/filter/time-grouping identifiers compiled server-side to bounded tenant-scoped query plans.

### Scope boundary

No raw SQL editor, arbitrary database/table access, cross-tenant aggregate or billing guarantee.

### Acceptance and demonstration


- [ ] Metric/dimension registry has stable IDs, semantics, permissions and supported filters.

- [ ] Saved report definition is tenant-owned/versioned and contains no raw SQL.

- [ ] Server injects tenant scope and uses parameterised allowlisted query plans.

- [ ] Time range, cardinality, rows and expensive operations are bounded under #50.

- [ ] Known fixture reports reconcile with #85 canonical event totals.

- [ ] Invalid/stale metric/dimension definitions fail visibly.

- [ ] Users can create/edit/run saved reports through accessible UI.

- [ ] Definitions can later accept incident/realtime/feedback metrics without schema bypass.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: #50, #79, #85; PG-FB-01 for feedback metrics.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.

---

## PG-ID-01 — Accept verified Cloudflare Access workforce identity without weakening Tocyn authorisation

**Proposed labels:** `enhancement`, `security`  
**Proposed milestone:** M9.5: Platform - Cloudflare Access Workforce Identity  
**Proposed effort:** 32 h baseline / 96 h planning  
**First-beta relevance:** Not a first-beta blocker; later capability/governance.

### Approved implementation scope

Add a Cloudflare Access workforce-authentication adapter/mode that validates Access JWTs, maps verified identities to explicit Tocyn workforce users and then applies #79 application capabilities.

### Scope boundary

No Tocyn-native SAML/OIDC/Google/SCIM implementation and no automatic JIT user creation by default. Customer portal auth remains separate.

### Acceptance and demonstration


- [ ] Validate `Cf-Access-Jwt-Assertion` signature, issuer and configured application audience.

- [ ] Missing/invalid/expired/wrong-audience token is denied before tenant application data.

- [ ] Verified provider subject maps explicitly to a Tocyn workforce identity; unmapped identity is denied.

- [ ] Email/group claims cannot directly grant #79 capability.

- [ ] `cloudflare_access` production mode has no internet-accessible local login bypass.

- [ ] `local` mode remains available only under explicit development/bootstrap configuration.

- [ ] JWT key rotation/cache failure behaviour is fail-closed and tested.

- [ ] Documentation shows IdP/Access authentication boundary separately from Tocyn authorisation.


### Dependencies and proposed forecast

- Architectural prerequisites / relationships: #79 and existing workforce identity/session foundation.
- Integration-only sequencing constraints: resolve from the combined dependency graph.
- Baseline/forecast dates: **TBD by the combined roadmap reforecast; do not overwrite existing M0–M7 baselines.**
- Review/integration: use the repository's mandatory 3× planning convention and meaningful PR boundaries.

### Baseline and execution boundary

Planning-package baseline reviewed: `main` `93de1b975a45edd9d28ca70edd725b60deb6b275`. Existing API/portal, tenant repositories, scoped R2, canonical conversations, realtime presence and AI/RAG foundations are foundations to extend, not rebuild.

This issue is proposed future implementation. Creation of the issue does not authorise deployment, production provider setup, real customer communications, remote migrations, tags or releases. Candidate first beta remains `v0.4.0-beta.1` with the existing forecast unless independent evidence changes it.
