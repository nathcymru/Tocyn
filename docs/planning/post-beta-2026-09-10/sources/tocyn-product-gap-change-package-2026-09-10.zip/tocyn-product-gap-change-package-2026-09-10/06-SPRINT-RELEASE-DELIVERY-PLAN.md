# Sprint, Release and Delivery Plan

## 1. Do not interrupt the current feature path with new feature implementation

The recommended immediate work is a **governance-only alignment sprint**, then return to the existing M0–M7 path.

### GAS-1 — Product Gap Alignment Governance Sprint

**Owning issue:** `PG-GOV-01`  
**Nature:** documentation/governance only  
**Recommended baseline effort:** 8 hours  
**Repository planning effort using mandatory 3× allowance:** 24 hours  
**Feature code:** forbidden  
**Deployment/provider setup:** forbidden  
**Release/tag:** forbidden

Outputs:

- create `PG-GOV-00` tracker;
- create M8/M9 milestone structure;
- create all new `PG-*` feature issues with real GitHub numbers;
- apply ADR-0016–ADR-0022 (renumber first if combined packages collide);
- update roadmap/architecture/Wiki-sync documents;
- mark legacy planning documents historical/superseded;
- populate/reforecast Project 4 fields for new scope;
- record a docs/governance PR completion receipt.

After GAS-1, resume the existing critical path.

## 2. Mandatory M8 architecture spike

`PG-RT-01` is the first M8 implementation item and should behave as a bounded technical spike before media feature code expands.

It must answer:

1. Realtime SFU vs selective RealtimeKit use.
2. Signalling/session-state responsibility.
3. recording path;
4. transcription path;
5. screen-share browser support/constraints;
6. external PSTN bridge/provider abstraction;
7. cost/resource dimensions;
8. failure/reconnect model;
9. local/sandbox validation route;
10. data/retention/privacy implications.

Do not begin the full telephony/browser-media implementation without this evidence.

## 3. Proposed effort envelope

The estimates below are **planning inputs**, not approved Project baselines. They must be reconciled with the other packages in the final combined change plan.

| Key | Baseline effort | Mandatory 3× planning effort |
| --- | ---: | ---: |
| PG-RT-01 | 24 h | 72 h |
| PG-RT-02 | 40 h | 120 h |
| PG-RT-03 | 48 h | 144 h |
| PG-RT-04 | 48 h | 144 h |
| PG-RT-05 | 40 h | 120 h |
| PG-RT-06 | 40 h | 120 h |
| PG-RT-07 | 24 h | 72 h |
| PG-TK-01 | 32 h | 96 h |
| PG-TK-02 | 40 h | 120 h |
| PG-KB-01 | 32 h | 96 h |
| PG-KB-02 | 24 h | 72 h |
| PG-AP-01 | 40 h | 120 h |
| PG-AP-02 | 32 h | 96 h |
| PG-FB-01 | 24 h | 72 h |
| PG-RP-01 | 32 h | 96 h |
| PG-RP-02 | 40 h | 120 h |
| PG-ID-01 | 32 h | 96 h |
| **Feature total** | **592 h** | **1,776 h** |
| PG-GOV-01 | 8 h | 24 h |

These numbers intentionally include enough room for negative tests, tenant isolation, accessibility, cost/recovery evidence and review; they should not be compressed merely to preserve the old roadmap finish date.

## 4. Capacity interpretation

Using the repository's current planning assumption of two bounded workstreams, Monday–Saturday, eight productive hours/day per workstream:

- the mathematical lower bound for 1,776 planned hours is about **111 two-stream working days** if utilisation were perfect;
- dependency/review/provider constraints mean a real forecast will be longer;
- if this package were the only added scope and started only after the current 16 July 2027 M0–M7 scoped completion, the capacity floor lands in late November 2027 and a more credible no-holiday provisional envelope reaches into December 2027;
- **do not write those dates to Project 4 from this standalone package**, because the user explicitly intends to combine it with other packages.

The final package must run `.agents/workflows/roadmap-reforecast.md` against all combined additions.

## 5. Recommended sequencing

### Workstream family A — M8 critical communications

`PG-RT-01` → `PG-RT-02` → parallel `PG-RT-03` + `PG-RT-04` → `PG-RT-05` + `PG-RT-06` as dependencies permit → `PG-RT-07`.

### Workstream family B — M9 helpdesk operations

High-value order:

1. `PG-TK-01`
2. `PG-TK-02`
3. `PG-KB-01`
4. `PG-KB-02`
5. `PG-FB-01`
6. `PG-RP-01` / `PG-RP-02`
7. `PG-AP-01`
8. `PG-AP-02`
9. `PG-ID-01` may run in parallel once #79 is accepted.

The final scheduler may parallelise independent items; do not rewrite native dependencies merely to improve dates.

## 6. Release plan

### Existing candidate

`v0.4.0-beta.1` — **no scope or forecast change from this package**.

The new gap issues are not `beta-blocker` items.

### Future snapshots

Do not create planned version milestones such as `v0.5.0` or `v1.0` merely to hold M8/M9.

Instead define readiness sets:

- **Realtime Communications readiness:** M8.1–M8.4 accepted.
- **Advanced Helpdesk Operations readiness:** M9.1–M9.5 accepted.
- **Expanded world-class helpdesk scope readiness:** existing M0–M7 + M8 + M9 accepted.

When an actual tested commit snapshot exists, choose the appropriate SemVer prerelease/release according to the repository convention and create the tag/Release then.

## 7. Provider/production gates

M8 planning and local/synthetic tests do not authorise:

- PSTN number purchase;
- vendor billing;
- production Cloudflare Realtime apps;
- real customer calls;
- call recording of real users;
- real support-message activation.

Those remain explicit operational decisions under the repository's existing deployment/provider controls.
