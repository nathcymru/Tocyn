# Product Gap Register

## Severity model

- **CRITICAL** — a material missing support capability that prevents the intended end-state from credibly competing as a world-class helpdesk.
- **HIGH** — a major mature-helpdesk capability gap that significantly weakens enterprise/service-operations outcomes.
- **MEDIUM / STRATEGIC** — not required for basic helpdesk credibility, but creates material operator extensibility or competitive advantage.
- **ARCHITECTURAL ALTERNATIVE** — the user outcome is intentionally satisfied through the deployment architecture rather than a Tocyn-native copy of the competitor feature.
- **OUT OF SCOPE** — deliberately excluded because it belongs to CRM, marketing, sales, app-marketplace or other non-helpdesk product territory.

None of these severities make the work a first-private-beta blocker unless later evidence proves a genuine dependency.

## GAP-01 — Phone and rich realtime support

**Severity:** CRITICAL  
**Current Tocyn end-state:** Missing explicit roadmap ownership. Existing #49 historically excluded audio/video from its original specification.  
**Target:** Native support sessions covering:

- browser audio;
- browser video;
- screen sharing;
- inbound PSTN calls;
- outbound PSTN calls;
- voicemail;
- callbacks;
- transfer/queue operations;
- recording;
- transcription;
- conversation/QA/reporting linkage.

**Explicit exclusions:**

- autonomous AI/Fin Voice;
- sales diallers or marketing calls;
- Tocyn acting as a telecom carrier;
- centrally owned telephone numbers/accounts;
- remote desktop control (screen sharing only);
- always-on/ambient recording.

**Roadmap action:** Add M8.1–M8.4 and `PG-RT-01`–`PG-RT-07`.

## GAP-02 — Advanced ticketing/service-work operations

**Severity:** HIGH  
**Current foundation:** #72 split/merge; #70 internal collaboration; #79 authorisation; #88 outbound delivery.  
**Missing:** separate private back-office work and one-to-many service problem/incident management.

**Target:**

- internal linked work item with independent owner/status/priority;
- explicit links from customer tickets to back-office work;
- service Problem and Incident entities;
- one Problem/Incident linked to many affected tickets/conversations;
- incident severity/status/timeline;
- affected-customer count and target preview;
- controlled mass support update that writes a public event/article into each affected conversation and uses #88 for dispatch;
- link/unlink/publish auditing;
- same-tenant-only relationships.

**Roadmap action:** Add M9.1 and `PG-TK-01`/`PG-TK-02`.

## GAP-03 — Tenant knowledge ingestion and AI-assistant grounding

**Severity:** HIGH  
**Current foundation:** R2 + D1 knowledge metadata, Vectorize, Workers AI, asynchronous vectorisation and #76/#77.  
**Known planning hazard:** the old Phase 1.7 document says PDFs can be stored but binary formats were flagged unsupported for vectorisation; several older KB plans still contain single-tenant/current-sounding language.

**Target:**

- PDF upload and asynchronous text extraction;
- page/chunk provenance;
- version-safe vector lifecycle;
- server-derived tenant scope;
- source visibility/ACL enforcement;
- tenant-scoped retrieval;
- operator vs service-user knowledge visibility;
- citations and staleness;
- shared inference model permitted, but logical assistant context isolated per tenant;
- no per-tenant model training required;
- no third-party knowledge sync connectors initially;
- no OCR in the first PDF issue unless separately approved.

**Roadmap action:** Add M9.2 and `PG-KB-01`/`PG-KB-02`.

## GAP-04 — Feedback and operational reporting

**Severity:** HIGH  
**Current foundation:** #73 SLA and #85 event-derived operational metrics.  
**Missing:** service feedback collection, live management view and tenant-defined reporting.

**Target:**

- CSAT;
- CES;
- optional comment;
- channel/ticket/operator/team/AI/SLA correlation;
- live queue/SLA/availability/support-session/problem status dashboard;
- server allowlisted metric registry;
- tenant-defined report definitions using metric + dimensions + filters + timeframe/grouping;
- bounded query compiler, no arbitrary SQL;
- saved reports and access control.

**NPS:** keep schema extensible, but do not add an NPS/customer-success subsystem now.

**Roadmap action:** Add M9.4 and `PG-FB-01`, `PG-RP-01`, `PG-RP-02`.

## GAP-05 — Operator applets / Canvas-style extensibility

**Severity:** MEDIUM / STRATEGIC  
**Current foundations:** #48 headless primitives, #68 slash commands, #75 governed read context, #78 workflow authoring, #79 permissions, #80 typed governed actions, #81 approvals.

**Target:** tenant-admin-authored, schema-defined mini-applications rendered in:

- conversation sidebar;
- conversation timeline;
- composer recipe/slash-command entry points.

Allowed building blocks should include safe text/status/key-value/table/form/action components. Data comes from canonical context or authorised connector reads. Mutations reference typed tools and always pass the existing policy/approval gate.

**Explicit exclusions:**

- arbitrary tenant JavaScript;
- arbitrary HTML/CSS;
- remote executable packages;
- unreviewed code injection;
- public App Store;
- central OAuth marketplace/broker;
- per-applet embedded credentials.

**Roadmap action:** Add M9.3 and `PG-AP-01`/`PG-AP-02`.

## GAP-06 — Enterprise workforce identity

**Severity:** ARCHITECTURAL ALTERNATIVE, with a bounded Tocyn integration task  
**Competitor feature not copied:** Tocyn-native SAML, Google SSO, OIDC and SCIM/JIT suite.  
**Target architecture:** IdP → Cloudflare Access/Zero Trust → validated Access JWT → Tocyn workforce identity mapping → #79 application authorisation.

Tocyn must still implement the trusted Access boundary; merely documenting that Cloudflare exists is insufficient.

**Target:**

- production workforce-auth mode backed by Cloudflare Access;
- verify JWT signature, issuer and audience;
- explicit Tocyn workforce identity mapping;
- no implicit JIT user creation by default;
- Access/group claims never directly become permissions without configured mapping;
- Tocyn #79 remains authoritative for application capabilities;
- customer/service-user authentication remains separate;
- local-development/bootstrap authentication cannot become a production bypass.

**Roadmap action:** Add M9.5 and `PG-ID-01`.

## EX-01 — Outbound/proactive marketing

**Severity:** OUT OF SCOPE — NOT A PRODUCT GAP.

Exclude campaigns, Product Tours, marketing Tooltips, marketing Checklists, News, lifecycle Series, promotional mobile push/carousels and comparable engagement automation.

**Important boundary:** support-driven communication remains in scope. An incident update to customers linked to an actual support problem is helpdesk work; a campaign to market a product is not.

## EX-02 — CRM/customer-data platform

**Severity:** OUT OF SCOPE — NOT A PRODUCT GAP.

Tocyn may hold support-domain data needed to resolve service requests: identities, organisations, contact routes, entitlements/context, custom support attributes and conversation history.

Do not add:

- sales leads;
- opportunities/pipeline;
- campaign attribution;
- marketing segments/audiences;
- behavioural CDP events for targeting;
- a generic CRM/custom-object platform.

## EX-03 — Broad ecosystem/platform parity

**Severity:** OUT OF SCOPE except the safe applet capability.

Do not build parity for:

- public app marketplace;
- central public OAuth app ecosystem;
- Salesforce/HubSpot/Shopify integration catalogue;
- broad Jira/Stripe-style vendor catalogue merely for checkbox parity;
- mobile SDK ecosystem.

Provider integrations can still be approved individually where they solve a genuine helpdesk use case. That is a separate product decision, not an ecosystem parity objective.
