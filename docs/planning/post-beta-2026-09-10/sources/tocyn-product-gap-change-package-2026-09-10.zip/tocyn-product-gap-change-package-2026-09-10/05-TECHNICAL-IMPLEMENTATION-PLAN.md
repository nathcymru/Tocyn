# Technical Implementation Plan

## 1. Native realtime support communications

### 1.1 Architectural shape

Use a provider-independent `SupportSession` domain linked to the canonical Tocyn conversation. Media is not a parallel ticket model.

```mermaid
flowchart LR
  C[Canonical conversation] --> S[SupportSession]
  S --> DO[Session coordinator / Durable Object]
  S --> D1[(D1 session metadata)]
  DO --> CF[Cloudflare Realtime SFU / selected Realtime substrate]
  CF --> A[Operator browser]
  CF --> B[Customer browser]
  S --> TG[TelephonyGateway]
  TG --> PSTN[PSTN provider / tenant-owned account]
  S --> R2[(R2 recording/transcript artefacts)]
  S --> EV[Conversation + audit events]
```

### 1.2 Proposed data model

Use tenant-qualified primary/foreign keys consistent with current isolation rules.

`support_sessions`

- `tenant_id`
- `id`
- `conversation_id`
- `kind`: `webrtc_audio | webrtc_video | pstn`
- `direction`: `inbound | outbound | internal_upgrade`
- `state`: `requested | ringing | connecting | active | held | ended | failed | missed | voicemail`
- `created_by_actor_type/id`
- `provider_type`
- `provider_session_id` (nullable and never authority)
- `started_at`, `answered_at`, `ended_at`
- `recording_policy_snapshot_id`
- `recording_state`
- `transcription_state`
- cost reservation/correlation identifier

`support_session_participants`

- tenant/session composite key;
- actor/customer/external participant identity;
- role;
- provider participant/session-track identifiers;
- joined/left timestamps.

`support_session_media`

- tenant/session;
- media type;
- source participant;
- provider track identifier;
- state;
- optional R2 artefact reference;
- retention class.

Do not put secrets, Realtime app secrets or provider credentials in these rows.

### 1.3 Realtime coordinator

Create a dedicated per-session Durable Object namespace such as a stable key derived from `tenant_id + support_session_id`.

Responsibilities:

- transient participant presence;
- signalling coordination;
- reconnect fencing;
- current media-control state;
- short-lived session capability/token issuance coordination;
- fan-out of call-state events.

Non-responsibilities:

- tenant authority;
- durable canonical history;
- provider credential storage;
- billing truth;
- recording retention authority.

The Worker must derive verified tenant/user context before addressing the DO.

### 1.4 Cloudflare media boundary

Preferred bespoke architecture is Cloudflare **Realtime SFU** because it exposes raw WebRTC primitives while Tocyn owns room/session semantics, permissions and UI.

Keep the Realtime App secret server-side. The Tocyn Worker creates/manages SFU sessions and only returns the minimum client session/track material required after authorisation.

`PG-RT-01` must validate whether:

- raw Realtime SFU is used for all browser media;
- RealtimeKit is used selectively for recording/transcription;
- a provider interface is required so recording can switch between RealtimeKit and a headless/media-adapter path.

Do not make a permanent RealtimeKit UI dependency merely because its recording API is convenient.

### 1.5 Browser audio/video/screen share

Client behaviour:

- explicit device permission request;
- pre-call mic/camera test;
- audio-only mode;
- video enable/disable;
- screen sharing via browser display-media capture;
- no remote-control capability;
- device switching;
- reconnect/resume;
- degraded-network state;
- mute/hold/end;
- clear recording/transcription indicator;
- keyboard and screen-reader operability;
- state kept in canonical session controls rather than hidden browser globals.

A customer should be able to upgrade an existing text conversation to a support session and return to text without losing context.

### 1.6 Telephony gateway

Tocyn is not a carrier. Introduce a provider interface:

```ts
interface TelephonyProvider {
  verifyInboundEvent(request: Request): Promise<VerifiedTelephonyEvent>;
  startOutboundCall(input: PlaceCallInput): Promise<ProviderCallRef>;
  answerCall(input: AnswerCallInput): Promise<void>;
  endCall(input: EndCallInput): Promise<void>;
  transferCall(input: TransferCallInput): Promise<void>;
  fetchCallState(ref: ProviderCallRef): Promise<ProviderCallState>;
}
```

The first real provider is selected only after `PG-RT-01` records:

- UK/target-region number availability;
- inbound/outbound APIs;
- webhook signing;
- media bridge capability (WebRTC/SIP/media WebSocket as relevant);
- voicemail/recording support;
- sandbox/testability;
- data location/privacy terms;
- pricing and fraud controls;
- tenant-owned credential model.

Provider events go through #87-style verification/normalisation. Transactional outbound intent/retry semantics reuse #88 where appropriate.

### 1.7 Identity and phone-number safety

A telephone number can route an inbound call to the correct tenant/provider mapping, but it must **not** automatically become proof that a caller owns an existing portal/customer identity.

Use #74's verified-link model:

- stored verified channel mapping may link the call;
- otherwise create an unverified/external participant and let authorised support workflow prove/link identity;
- never merge cross-tenant customers by matching phone text.

### 1.8 Voicemail, callback and queue

Model these as support operations, not marketing.

- `callback_request` references conversation/customer/session;
- queue route uses tenant settings, team/group and office-hours/SLA context;
- missed call can create/update a canonical conversation;
- voicemail audio is a tenant-owned R2 artefact with a conversation event;
- transfer is an audited session-state change;
- callback initiation requires operator capability and target validation;
- no predictive/automated marketing dialling.

### 1.9 Recording/transcription

Default stance: **not silently always-on**.

Record:

- tenant recording policy;
- legal/consent presentation state;
- participant consent/notification evidence as applicable;
- start/stop actor and timestamp;
- storage/retention class;
- failure/partial status.

Storage:

- recording file in tenant-scoped R2;
- D1 metadata/ownership manifest;
- transcript in R2 or bounded structured storage with D1 reference;
- deletion workflow removes derived transcript/search data as well as the recording.

Cloudflare RealtimeKit currently supports composite/track recording, R2 export and Workers-AI-backed transcription. `PG-RT-01` decides whether that implementation path is accepted behind the Tocyn recording abstraction.

Do not claim end-to-end encryption merely because WebRTC is used; document the actual media/service boundary.

### 1.10 Cost dimensions

Extend the #50 resource catalogue and #90 UI with dated dimensions such as:

- `realtime_sfu_egress_bytes`
- `realtime_participant_minutes`
- `realtime_recording_minutes`
- `realtime_transcription_audio_seconds`
- `telephony_inbound_minutes`
- `telephony_outbound_minutes`

Reserve before discretionary start where feasible. Existing accepted conversations must retain bounded recovery/termination capacity even when new-session admission is stopped.

---

## 2. Linked back-office work and problem/incident management

### 2.1 Preserve ticket meaning

Do not overload the customer `tickets` table with every internal service-management concept.

Recommended model:

`backoffice_work_items`
- tenant-qualified ID;
- title/type/status/priority;
- owner team/operator;
- due/SLA metadata where configured;
- internal visibility only;
- created/resolved timestamps.

`ticket_work_item_links`
- tenant-qualified link between a ticket and work item;
- relation type;
- created by/time.

`service_problems`
- problem/incident discriminator;
- title, status, severity;
- owner;
- customer-safe status/workaround fields;
- internal diagnosis/root cause fields;
- start/resolution timestamps.

`problem_ticket_links`
- tenant-qualified problem → affected ticket relation;
- link provenance;
- linked/unlinked actor/time.

Internal notes/attachments must not become customer-visible merely because the work item is linked.

### 2.2 Incident update fan-out

An authorised “update affected customers” action should:

1. resolve the problem under verified tenant scope;
2. materialise the exact bounded target ticket list;
3. present target count + content preview;
4. require the appropriate publish capability/confirmation;
5. assign an idempotent `incident_update_batch_id`;
6. create one public conversation article/event per target ticket;
7. create the matching #88 outbound intent atomically with each customer-visible mutation;
8. record successes/failures without claiming exactly-once external delivery;
9. support safe retry of failed targets without duplicating already committed articles.

This is service communication, not an audience/campaign system.

### 2.3 Permissions

Extend #79 capability registry with explicit permissions such as:

- `work_items:read`
- `work_items:create`
- `work_items:update`
- `work_items:assign`
- `problems:read`
- `problems:create`
- `problems:update`
- `problems:link_ticket`
- `incident_updates:publish`

Large fan-out can use a stricter capability/policy threshold without creating a marketing approval engine.

---

## 3. Tenant PDF knowledge and logical tenant AI assistant

### 3.1 Knowledge source model

Introduce/normalise a tenant-qualified source manifest:

`knowledge_sources`
- `tenant_id`
- `id`
- `source_type`: `authored | pdf`
- title
- visibility: `public | internal | role/group-bounded`
- R2 object key
- content hash
- source version
- active version pointer
- processing status/error
- created/updated actor/time
- page count/extraction metadata where applicable.

### 3.2 PDF pipeline

1. Authorised upload streams to a tenant-scoped R2 path.
2. Validate content type, PDF signature, configured size/page bounds and checksum.
3. Create D1 source version in `processing`.
4. Dispatch a Workflow/Queue job.
5. Extract text with a Worker-compatible parser selected by an implementation capability test.
6. Image-only/unextractable PDFs fail visibly as `requires_ocr`/`unsupported` in v1; do not silently spend OCR/AI capacity.
7. Chunk with source/page/section boundaries.
8. Generate embeddings under #50 budget.
9. Upsert vectors with `tenant_id`, source ID/version, visibility class, page/chunk metadata and checksum.
10. Atomically promote the new active source version after successful indexing.
11. Remove superseded vectors/artefacts through retryable cleanup.

### 3.3 Retrieval safety

Vector metadata is a filtering aid, not authority.

For every retrieval:

- derive tenant from verified request/session;
- derive actor knowledge visibility from Tocyn permissions;
- construct server-side Vectorize filters;
- validate returned source IDs against tenant-owned source manifests before hydration;
- hydrate content from R2 only through tenant-scoped storage methods;
- bound context size;
- return source/page/version provenance.

Never accept `tenant_id` or a client category/source identifier as sufficient permission.

### 3.4 Logical tenant assistant

“Tenant AI assistant” means:

- one **logical** assistant configuration/security scope per tenant;
- shared Workers AI inference models may serve multiple tenants;
- tenant data is supplied only as the minimum authorised retrieval context for that request;
- no model fine-tuning/training on tenant content is required;
- tenant A retrieval can never include tenant B vectors/content;
- public/service-user assistant sees only authorised public/self-service material;
- operator assistant can see additional internal material only if the human operator is permitted to see it;
- AI-disabled mode leaves deterministic KB search/manual support usable.

### 3.5 No third-party knowledge sync now

Explicitly exclude website crawling, Zendesk, Confluence, Notion, Guru, Salesforce, Freshdesk, Box and GitHub sync from this milestone. A future connector must receive separate issue/ADR approval.

---

## 4. Governed operator applets

### 4.1 Applet definition is data, not executable code

Proposed schema:

```ts
interface AppletDefinitionV1 {
  id: string;
  tenantId: string;          // server owned
  version: number;
  title: string;
  surfaces: Array<"conversation.sidebar" | "conversation.timeline" | "composer.recipe">;
  visibility: CapabilityExpression;
  dataBindings: AppletDataBinding[];
  layout: AppletNode[];
  actions: AppletActionBinding[];
  workflowRef?: string;
  status: "draft" | "published" | "retired";
}
```

Allowed node types should be finite and versioned, for example:

- heading/text;
- status badge;
- key/value;
- bounded table/list;
- image/attachment reference already authorised by Tocyn;
- form fields from approved primitives;
- action button;
- workflow/recipe launch control.

No arbitrary JS, HTML, `<script>`, external stylesheet, runtime CSS-in-JS or embedded credential.

### 4.2 Data bindings

Read values only from:

- canonical conversation/ticket/customer-safe context;
- #75 authorised read connectors;
- explicit static configuration.

The server builds an `AppletViewModel`; the browser does not receive connector credentials or execute arbitrary integration calls.

### 4.3 Action bindings

An applet action references a typed tool/workflow. It must pass:

`#79 capability → #80 tool validation/policy gate → #81 exact approval if required → execution → result verification`

The applet cannot lower a tool's risk classification or create authority.

### 4.4 Composer recipes

#68 already provides slash-command direction. Add a recipe registry that can launch an applet/workflow such as:

- `/diagnose`
- `/refund`
- `/replacement`
- `/escalate`

The recipe gathers validated parameters and invokes the same governed workflow/tool path. It is not a macro that bypasses policy.

### 4.5 Authoring

Reuse #78's draft/validate/dry-run/version/publish/rollback concepts.

Store versioned applet definitions in D1. Publishing is an audited admin action. Runtime instances use an immutable published version for the duration of an active action so an admin edit cannot mutate an approval request mid-flight.

---

## 5. Service feedback and reporting

### 5.1 Feedback model

`service_feedback`
- tenant ID;
- conversation/ticket;
- feedback type `csat | ces`;
- score;
- optional comment;
- operator/team/channel;
- AI involvement indicator;
- SLA outcome;
- resolution/reopen correlation;
- submission route;
- signed request token hash/correlation;
- submitted timestamp.

Use one idempotent feedback request per defined resolution event. Reopen/re-resolve behaviour must be specified rather than generating unlimited prompts.

### 5.2 Feedback delivery

Supported first paths:

- portal/widget inline;
- signed short-lived feedback link in a legitimate support reply.

Do not create a customer marketing audience/subscription system.

### 5.3 Live support-management dashboard

Back it with bounded derived metrics, not repeated raw history scans.

Core tiles/views:

- open/unassigned conversations;
- current queue depth;
- oldest waiting;
- SLA approaching/breached;
- active/available operators where reliable;
- current assignments/capacity;
- median response/resolution;
- CSAT/CES;
- active Problems/Incidents;
- active calls/realtime sessions once M8 lands;
- AI resolution/handoff metrics only where definitions are auditable.

Realtime UI can receive invalidation/state hints; metric values should come from authoritative bounded aggregates/snapshots.

### 5.4 Custom report model

Provide an allowlisted metric registry, for example:

```ts
interface ReportDefinitionV1 {
  metric: MetricId;
  dimensions: DimensionId[];
  filters: ReportFilter[];
  timeRange: TimeRangeSpec;
  grouping?: TimeBucket;
}
```

Compiler rules:

- no raw SQL field;
- no arbitrary table/column names;
- server maps each metric/dimension to approved query plans;
- parameterised filters only;
- bounded date range/cardinality/result count;
- tenant predicate is injected by server and cannot be removed;
- cost budget checked before expensive work;
- permissions decide available metrics/dimensions;
- definitions are versioned/saved per tenant.

### 5.5 #85 relationship

#85 remains the foundation for metric semantics, denominators, time windows and late-event handling. `PG-RP-01/02` consume those definitions and add user-facing management/report authoring.

---

## 6. Cloudflare Access workforce identity

### 6.1 Authentication/authorisation split

```mermaid
flowchart LR
  IDP[Customer/deployer IdP] --> ACCESS[Cloudflare Access]
  ACCESS --> JWT[CF Access JWT]
  JWT --> VERIFY[Tocyn Access authenticator]
  VERIFY --> MAP[Explicit Tocyn workforce mapping]
  MAP --> AUTHZ[#79 Tocyn capabilities]
  AUTHZ --> APP[Tocyn operator/admin application]
```

Cloudflare can integrate SAML/OIDC/Google/etc. Tocyn therefore does not need to duplicate those protocols merely for parity.

### 6.2 JWT verification

For protected Workers/origins:

- consume `Cf-Access-Jwt-Assertion`;
- validate signature against the Access account JWKS;
- validate issuer;
- validate the application audience (`AUD`);
- reject missing/invalid tokens before application data access;
- cache/rotate JWK material safely.

Never trust a caller-supplied email or copied Access header without cryptographic validation.

### 6.3 Workforce mapping

Create an explicit mapping such as:

`workforce_identities(tenant_id, user_id, provider, provider_subject, provider_email_snapshot, enabled, created_at, updated_at)`

Rules:

- no implicit user creation from a valid Access token by default;
- a verified Access identity must map to a Tocyn workforce user;
- email is not the stable primary authority when a provider subject is available;
- Access group/claim information can be used only through explicit configured mappings;
- #79 remains the permission source.

### 6.4 Auth modes

Support explicit deployment configuration:

- `local` — local development/bootstrap/test mode;
- `cloudflare_access` — production workforce mode.

When `cloudflare_access` is selected, local workforce login endpoints must not create an internet-accessible bypass. Customer portal/service-user auth remains independent.

---

## 7. Cross-cutting security, privacy and accessibility

Every new issue inherits existing Tocyn rules:

- verified tenant scope before tenant data;
- composite tenant ownership in D1 relationships;
- tenant-scoped R2 references;
- derived Vectorize/media/transcript artefacts remain attributable to tenant/source;
- audit deterministic security/action evidence, not hidden model reasoning;
- no tenant data in developer/agent tooling;
- static CSS/`--tocyn-*` tokens; no runtime CSS-in-JS;
- keyboard/focus/screen-reader/contrast acceptance for new UI;
- local/synthetic providers by default until an issue explicitly authorises an isolated external environment;
- resource consumption and failure/recovery evidence recorded for every substantive implementation.
