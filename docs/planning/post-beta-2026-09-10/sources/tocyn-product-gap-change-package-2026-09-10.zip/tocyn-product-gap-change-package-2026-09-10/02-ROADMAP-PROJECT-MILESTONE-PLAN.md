# Roadmap, Project and Milestone Change Plan

## 1. Preserve the existing authority model

The current roadmap separates:

1. **architecture/capability** — GitHub architectural milestones;
2. **implementation work** — GitHub issues and native dependency edges;
3. **readiness** — cross-cutting labels such as `beta-blocker`;
4. **releases** — tested SemVer Git tags/GitHub Releases.

This package must preserve that model.

### Do not change

- M0–M7 numbering or existing milestone identity.
- Existing baseline start/target fields.
- Existing issue baseline history.
- Candidate first beta `v0.4.0-beta.1`.
- Current 21 November 2026 first-beta forecast solely because these end-state gaps were identified.
- Historical `v0.1.0`–`v0.4.0` version-milestone evidence.
- Existing issue scope merely to make new work appear already approved.

## 2. Add new architectural phases

### M8 — Realtime Support Communications

**Purpose:** native customer/operator media and phone support attached to canonical Tocyn conversations without introducing a separate helpdesk model.

#### M8.1: Platform - Realtime Communications Architecture

**Member issue:** `PG-RT-01`  
**Outcome:** tested architecture for tenant-scoped support sessions, Cloudflare Realtime integration boundaries, recording/transcription options, telephony gateway contract and cost model.  
**Exclusions:** production provider activation, real customer calls, AI voice agent.  
**Dependencies:** current canonical conversation/tenant/cost foundations, especially #50, #74, #79, #87/#88.  
**Demonstration checkpoint:** a reproducible architecture proof with synthetic/local test clients and an evidence-backed provider choice/abstraction.

#### M8.2: Fullstack - Voice, Video & Screen Share

**Member issues:** `PG-RT-02`, `PG-RT-03`  
**Outcome:** authenticated tenant-scoped support sessions with browser audio/video/screen-share, preflight, reconnect, operator controls and conversation linkage.  
**Dependencies:** M8.1; #48, #68, #70, #74, #79.  
**Demonstration checkpoint:** two isolated tenants concurrently exercise supported media paths with no cross-tenant session/track access.

#### M8.3: Fullstack - Telephony & Call Operations

**Member issues:** `PG-RT-04`, `PG-RT-05`  
**Outcome:** provider-neutral tenant-owned PSTN integration covering inbound/outbound calls, queueing, transfer, voicemail and callback.  
**Dependencies:** M8.1/M8.2 session core; #73, #74, #79, #87, #88, #90.  
**Demonstration checkpoint:** an isolated provider/sandbox or approved reference adapter exercises inbound and outbound call lifecycle plus failure/retry paths.

#### M8.4: Fullstack - Recording & Transcription

**Member issues:** `PG-RT-06`, `PG-RT-07`  
**Outcome:** policy/consent-aware recording and transcription stored under tenant/retention boundaries and integrated into conversation, QA and analytics.  
**Dependencies:** M8.2/M8.3; #50/#90, #84, #85.  
**Demonstration checkpoint:** recorded and non-recorded sessions, consent denial, retention cleanup, transcript failure, authorised playback/read and cross-tenant denial.

### M9 — Advanced Helpdesk Operations & Enterprise Integration

#### M9.1: Fullstack - Linked Work & Problem Management

**Member issues:** `PG-TK-01`, `PG-TK-02`  
**Outcome:** private back-office work and one-to-many service problem/incident tracking with safe affected-customer updates.  
**Dependencies:** #70, #72, #79, #88; reporting integration later consumes #85.  
**Demonstration checkpoint:** multiple customer tickets link to one incident; internal work remains private; one authorised update writes/dispatches correctly to the bounded affected set.

#### M9.2: Fullstack - Tenant Knowledge & AI Grounding

**Member issues:** `PG-KB-01`, `PG-KB-02`  
**Outcome:** PDF-backed tenant knowledge with source/version/visibility provenance and AI retrieval constrained by verified tenant + actor permissions.  
**Dependencies:** current RAG foundation; #50/#64, #76, #77, #79.  
**Demonstration checkpoint:** two tenants upload similarly named PDFs; each assistant can cite only its authorised source/version; service users cannot retrieve operator-only material.

#### M9.3: Fullstack - Governed Operator Applets

**Member issues:** `PG-AP-01`, `PG-AP-02`  
**Outcome:** declarative applet surfaces and admin authoring/version/publish/rollback over existing governed reads/tools/workflows.  
**Dependencies:** #48, #66, #68, #75, #78, #79, #80, #81.  
**Demonstration checkpoint:** one read-only applet and one approval-required action recipe render in multiple surfaces, respect capability changes and execute no arbitrary tenant code.

#### M9.4: Fullstack - Service Feedback & Reporting

**Member issues:** `PG-FB-01`, `PG-RP-01`, `PG-RP-02`  
**Outcome:** CSAT/CES, live operations management and bounded tenant-defined reporting using canonical/event-derived metrics.  
**Dependencies:** #73, #79, #85; problem/realtime metrics integrate when their owning issues complete.  
**Demonstration checkpoint:** fixture totals reconcile to canonical events, customer feedback, incidents and realtime sessions; custom report definitions cannot execute arbitrary SQL or cross tenant boundaries.

#### M9.5: Platform - Cloudflare Access Workforce Identity

**Member issue:** `PG-ID-01`  
**Outcome:** optional/production-configurable Cloudflare Access workforce authentication adapter with validated JWTs and explicit Tocyn identity mapping; Tocyn authorisation remains #79.  
**Dependencies:** existing identity/session foundation and #79.  
**Demonstration checkpoint:** valid/invalid issuer, audience, signature and user mapping cases; production Access mode has no local-auth bypass; customer portal remains independent.

## 3. Cross-roadmap tracker

Create `PG-GOV-00` **Track delivery of the approved helpdesk capability extensions**.

- No architectural milestone.
- Mirrors #49's tracker-only pattern.
- Holds a checklist for M8/M9 member issues.
- Does not own implementation.
- Does not hold M0–M7 milestones open.
- Closes only after M8/M9 acceptance and final documentation reconciliation.

## 4. Project 4 field treatment

The repository identifies GitHub issues + **Project 4** as operational schedule truth. This package could not inspect the live Project custom-field values directly; the applying conversation must refresh them before any write.

For every **new** issue, populate the established fields only after the combined package is owner-approved:

- `Status`
- `Baseline start`
- `Baseline target`
- `Forecast start`
- `Forecast target`
- `Actual start`
- `Actual completion`
- `Progress %`
- `Schedule variance`

### New-scope baseline rule

Do not invent back-dated baselines. On final owner approval:

1. preserve all existing M0–M7 baseline fields unchanged;
2. calculate new M8/M9 baseline candidates from the combined package dependency graph and capacity model;
3. only then write the approved baseline dates for new items;
4. use forecast fields for later evidence-based movement;
5. preserve the current 16 July 2027 value as the historical **original M0–M7 scoped-roadmap completion forecast**, not as the completion date of the newly expanded M0–M9 end-state.

## 5. Dependency graph

```mermaid
flowchart TD
  BASE[M0-M7 foundations] --> RT1[M8.1 PG-RT-01]
  RT1 --> RT2[M8.2 session core]
  RT2 --> RTV[Browser voice/video/screen]
  RT2 --> TEL[M8.3 telephony]
  RTV --> REC[M8.4 recording/transcription]
  TEL --> REC

  BASE --> TK[M9.1 linked work/problem]
  BASE --> KB[M9.2 tenant knowledge]
  BASE --> APP[M9.3 applets]
  BASE --> FB[M9.4 feedback/reporting]
  BASE --> ID[M9.5 Access workforce identity]

  TK --> FB
  REC -. integration .-> FB
  KB -. knowledge context .-> APP
```

M8/M9 phase numbering is taxonomy, not a rule that every M9 issue must wait for every M8 issue. Native dependency edges govern scheduling.

## 6. Milestone date handling

Do **not** put arbitrary final dates into the GitHub milestones from this package alone. Other change packages are expected to be combined later.

This package supplies effort envelopes and dependency order in `06-SPRINT-RELEASE-DELIVERY-PLAN.md`. The combined package should run the repository's roadmap reforecast workflow and then set milestone target forecasts.

## 7. Release treatment

No version-number milestone is added.

- `v0.4.0-beta.1`: unchanged.
- M8 complete: eligible to be included in the next tested SemVer snapshot; no version assigned now.
- M9 complete: same rule.
- M0–M9 world-class-helpdesk target: readiness is demonstrated through issue/milestone acceptance; release number is assigned only to an actual tested snapshot.

No tag or GitHub Release should be created as part of the roadmap/ADR change PR.
