# ADR-0021 — Customer tickets, back-office work and service problems are distinct linked records

- **Status:** Proposed
- **Date:** 10 September 2026

## Context

Tocyn's ticket model is customer-support oriented. Mature helpdesks also need private back-office work and one-to-many tracking of a service problem/incident affecting many customer conversations.

Overloading every concept into the existing customer ticket row would blur visibility, ownership and lifecycle semantics.

## Decision

Keep the canonical customer `ticket/conversation` as the unit of customer support history.

Add separate tenant-owned domains:

- **BackofficeWorkItem** — internal work with its own owner/status/priority and private discussion/evidence;
- **ServiceProblem** — a problem/incident with severity/status/timeline, internal diagnosis and customer-safe update fields.

Use explicit tenant-qualified link tables:

- ticket ↔ back-office work;
- problem/incident ↔ affected ticket.

Linking does not copy internal notes into a customer conversation.

Publishing an affected-customer incident update is an explicit authorised action. It resolves a bounded target set, writes a customer-visible article/event into each target conversation and uses the shared transactional outbound mechanism for delivery. It is not a marketing audience/campaign feature.

## Consequences

- Back-office teams can own work without taking ownership of the customer conversation.
- One incident can correlate hundreds of support cases while preserving each customer's history.
- Internal/private and customer-visible content have explicit boundaries.
- #72 split/merge remains ticket-level provenance and is not repurposed.
- Bulk incident updates need idempotent batch/target receipts and cost/rate controls.
- The model is not a full ITSM CMDB/change-management system.

## Related

- issues #70, #72, #79, #88
- proposed ADR-0016
- proposed M9.1
