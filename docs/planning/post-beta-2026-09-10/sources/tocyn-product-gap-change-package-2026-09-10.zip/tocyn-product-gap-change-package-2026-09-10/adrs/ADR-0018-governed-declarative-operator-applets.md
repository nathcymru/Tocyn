# ADR-0018 — Operator applets are declarative views over governed Tocyn capabilities

- **Status:** Proposed
- **Date:** 10 September 2026

## Context

Operators benefit from small context-specific tools inside a support conversation: account status, order detail, diagnostic state, guided escalation, replacement/refund forms and similar workflows.

A conventional plugin marketplace with arbitrary JavaScript, embedded secrets and per-app OAuth would materially increase supply-chain, tenant-isolation, CSP and governance risk. Tocyn already plans headless UI primitives, governed context reads, typed actions, policy gates, action-bound approvals and visual workflow administration.

## Decision

Tocyn will provide a versioned **declarative operator applet** format.

An applet definition is data, not executable tenant code. It may compose an allowlisted set of Tocyn UI nodes and bind them to:

- canonical conversation/ticket context;
- authorised read connectors;
- typed governed tools;
- published governed workflows.

Supported presentation surfaces may include:

- conversation sidebar;
- conversation timeline;
- composer recipe/slash-command entry.

Every mutating action continues through the existing capability, policy, approval, execution and result-verification path. An applet cannot lower a tool risk class, supply hidden credentials or grant permission.

The runtime will not accept arbitrary JavaScript, arbitrary HTML/CSS, external executable packages or embedded integration secrets.

Applet definitions are tenant-scoped, schema validated, versioned and moved through draft/published/retired states. Publishing and rollback are audited.

No public App Store or central OAuth marketplace is created by this decision.

## Consequences

- Tocyn gains Canvas-like operator extensibility without a second execution engine.
- #78 workflow authoring and #80/#81 action governance remain authoritative.
- #48 primitives and `--tocyn-*` tokens remain the presentation foundation.
- Applet schema versions become public compatibility contracts and need migration rules.
- Connectors/credentials are configured through Tocyn's controlled integration layer and referenced by ID, not embedded in applet definitions.
- CSP and tenant isolation are materially simpler than arbitrary plugin execution.

## Related

- ADR-0010 — Policy-gated actions and reference validation
- issue #48
- issues #68, #75, #78, #79, #80, #81
- proposed M9.3
