# ADR-0022 — Service feedback and reporting are bounded, event-derived support operations

- **Status:** Proposed
- **Date:** 10 September 2026

## Context

Tocyn's approved #85 scope defines operational metrics but does not provide customer feedback collection, a live support-management dashboard or a custom report builder.

A naïve custom-report feature that exposes SQL/raw tables would weaken tenant isolation and cost controls. Generic survey/campaign functionality would also cross the approved helpdesk product boundary.

## Decision

Tocyn will add support-service feedback and bounded operational reporting.

Core feedback types are:

- CSAT;
- CES;
- optional free-text service comment.

NPS is not a core milestone requirement. The schema may be extensible for a later approved feedback type, but Tocyn will not build a marketing survey platform.

Operational reporting will use:

- canonical/audit/event-derived metric definitions;
- an allowlisted server-side metric/dimension registry;
- tenant-scoped aggregate/query plans;
- parameterised filters;
- bounded timeframe/cardinality/result limits;
- permission and CostPolicy enforcement.

Tenant-defined report definitions contain metric/dimension/filter/time-grouping identifiers, never raw SQL.

The live support-management dashboard consumes bounded authoritative aggregates/snapshots rather than repeatedly scanning unbounded ticket/message history.

## Consequences

- #85 remains the semantic metric foundation.
- CSAT/CES can correlate to channel, SLA, operator/team, AI handoff and problem/realtime-session context.
- Reporting UX can grow without exposing database implementation details.
- Incident/realtime metrics can join the registry as their owning milestones land.
- Feedback prompts remain support-transactional and cannot be repurposed as arbitrary campaigns without a new product decision.

## Related

- issue #73
- issue #85
- proposed ADR-0016
- proposed ADR-0021
- proposed M9.4
